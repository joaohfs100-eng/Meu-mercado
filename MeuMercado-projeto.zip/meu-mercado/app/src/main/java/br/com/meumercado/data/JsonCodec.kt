package br.com.meumercado.data

import br.com.meumercado.domain.*
import org.json.JSONArray
import org.json.JSONObject

internal object JsonCodec {
    fun strings(values: Collection<String>) = JSONArray(values.toList()).toString()
    fun stringSet(json: String): Set<String> = JSONArray(json).let { array ->
        (0 until array.length()).map { array.getString(it) }.toSet()
    }

    fun settings(value: AISettings): JSONObject = JSONObject().apply {
        put("mode", value.mode.name)
        put("favoriteBrands", JSONObject().apply { value.favoriteBrands.forEach { (key, names) -> put(key, JSONArray(names.toList())) } })
        put("onlineConsent", value.onlineConsent)
        put("gatewayUrl", value.gatewayUrl)
        put("theme", value.theme.name)
        put("activeListId", value.activeListId ?: JSONObject.NULL)
        put("notificationsEnabled", value.notificationsEnabled)
        put("learnedPreferencesEnabled", value.learnedPreferencesEnabled)
    }

    fun settings(json: JSONObject): AISettings {
        val favorites = json.getJSONObject("favoriteBrands")
        return AISettings(
            mode = RecommendationMode.valueOf(json.getString("mode")),
            favoriteBrands = favorites.keys().asSequence().associateWith { category ->
                val values = favorites.getJSONArray(category)
                (0 until values.length()).map { values.getString(it) }.toSet()
            },
            onlineConsent = json.getBoolean("onlineConsent"), gatewayUrl = json.getString("gatewayUrl"),
            theme = ThemeChoice.valueOf(json.getString("theme")),
            activeListId = if (json.isNull("activeListId")) null else json.getLong("activeListId"),
            notificationsEnabled = json.getBoolean("notificationsEnabled"),
            learnedPreferencesEnabled = json.getBoolean("learnedPreferencesEnabled")
        )
    }

    fun item(value: ShoppingListItem): JSONObject = JSONObject().apply {
        put("id", value.id); put("listId", value.listId); put("productId", value.productId)
        put("quantity", value.quantity); put("estimatedPriceCents", value.estimatedPriceCents)
        put("actualPriceCents", value.actualPriceCents ?: JSONObject.NULL); put("discountCents", value.discountCents)
        put("status", value.status.name); put("priority", value.priority); put("notes", value.notes); put("position", value.position)
    }

    fun item(json: JSONObject) = ShoppingListItem(
        id = json.getLong("id"), listId = json.getLong("listId"), productId = json.getLong("productId"),
        quantity = json.getString("quantity"), estimatedPriceCents = json.getLong("estimatedPriceCents"),
        actualPriceCents = if (json.isNull("actualPriceCents")) null else json.getLong("actualPriceCents"),
        discountCents = json.getLong("discountCents"), status = ItemStatus.valueOf(json.getString("status")),
        priority = json.getInt("priority"), notes = json.getString("notes"), position = json.getInt("position")
    )
}
