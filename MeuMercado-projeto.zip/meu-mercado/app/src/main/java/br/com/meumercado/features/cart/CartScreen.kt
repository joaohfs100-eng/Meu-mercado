package br.com.meumercado.features.cart

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.features.home.BudgetDialog
import br.com.meumercado.features.shoppinglist.ShoppingItems
import br.com.meumercado.ui.*

@Composable fun CartScreen(state: MarketUiState, vm: MarketViewModel, onScan: () -> Unit, onLists: () -> Unit, onHistory: () -> Unit) {
    var confirm by rememberSaveable { mutableStateOf(false) }
    var budget by rememberSaveable { mutableStateOf(false) }
    var onlyCart by rememberSaveable { mutableStateOf(false) }
    val list = state.activeList
    val summary = state.summary
    val missingRealPrice = state.activeItems.any { it.status == ItemStatus.IN_CART && it.actualPriceCents == null }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Carrinho inteligente", style = MaterialTheme.typography.headlineSmall)
        if (list == null) EmptyState("Nenhuma compra selecionada", "Selecione uma lista para acompanhar a compra.", "Minhas listas", onLists) else {
            Text(list.name, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SectionCard("Seu orçamento agora") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Metric("No carrinho", Money.format(summary.cartCents), Modifier.weight(1f))
                    Metric("Ainda pode gastar", Money.format(summary.remainingCents), Modifier.weight(1f), warning = summary.remainingCents < 0)
                }
                Text("Pendentes: ${Money.format(summary.pendingCents)} • Projeção inteira: ${Money.format(summary.projectedCents)}")
                Text("Limite: ${Money.format(summary.operationalLimitCents)} • ${summary.usedPercent.setScale(0, java.math.RoundingMode.DOWN).toPlainString()}% utilizado")
                LinearProgressIndicator(progress = { (summary.usedPercent.toFloat() / 100).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
                if (summary.remainingCents < 0) Text("⚠ Orçamento ultrapassado", color = MaterialTheme.colorScheme.error)
                else if (summary.alert != null) Text("⚠ Atenção: ${summary.alert}% do limite utilizado.")
                TextButton(onClick = { budget = true }) { Text("Alterar orçamento e alertas") }
            }
            if (missingRealPrice) Text("⚠ Confirme o preço encontrado de todos os itens no carrinho antes de finalizar.", color = MaterialTheme.colorScheme.error)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = vm::undo, Modifier.weight(1f)) { Icon(Icons.Default.Undo, null); Spacer(Modifier.width(4.dp)); Text("Desfazer") }
                Button(onClick = { confirm = true }, Modifier.weight(1f), enabled = summary.cartCount > 0 && !missingRealPrice) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(4.dp)); Text("Finalizar") }
            }
            Row { Switch(onlyCart, { onlyCart = it }); Text("Mostrar só o carrinho", Modifier.padding(start = 8.dp, top = 12.dp)) }
            ShoppingItems(state, vm, state.activeItems.filter { !onlyCart || it.status == ItemStatus.IN_CART }, onScan)
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Finalizar compra?") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Total: ${Money.format(summary.cartCents)} • ${summary.cartCount} produtos")
            Text("Somente os itens no carrinho serão registrados no histórico. ${summary.pendingCount} itens pendentes não serão cobrados.")
            if (missingRealPrice) Text("⚠ Há itens sem preço encontrado. Edite e confirme todos os preços antes de finalizar.")
            Text("O histórico guarda os valores desta compra mesmo que o cadastro dos produtos mude.")
        }
    }, confirmButton = { TextButton(enabled = !missingRealPrice && summary.cartCount > 0, onClick = { state.activeList?.let { vm.finishPurchase(it.id) }; confirm = false; onHistory() }) { Text("Confirmar compra") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Voltar") } })
    if (budget) BudgetDialog(state.activeBudget, onDismiss = { budget = false }) { vm.saveBudget(it); budget = false }
}
