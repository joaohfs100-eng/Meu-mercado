package br.com.meumercado.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import br.com.meumercado.domain.ThemeChoice

private val DayColors = lightColorScheme(
    primary = Color(0xFF125B3F), onPrimary = Color.White,
    primaryContainer = Color(0xFFD3EEDD), onPrimaryContainer = Color(0xFF063622),
    secondary = Color(0xFF437655), onSecondary = Color.White,
    secondaryContainer = Color(0xFFE4F3CD), onSecondaryContainer = Color(0xFF25431A),
    tertiary = Color(0xFF765C00), tertiaryContainer = Color(0xFFFFE498),
    background = Color(0xFFF6F8F5), surface = Color(0xFFF6F8F5),
    surfaceVariant = Color(0xFFE0E7DF), onSurface = Color(0xFF18241D),
    error = Color(0xFFBA1A1A), errorContainer = Color(0xFFFFDAD6)
)
private val NightColors = darkColorScheme(
    primary = Color(0xFF8FD6A8), onPrimary = Color(0xFF003822),
    primaryContainer = Color(0xFF165137), onPrimaryContainer = Color(0xFFB1F3C8),
    secondary = Color(0xFFB2D092), onSecondary = Color(0xFF223713),
    secondaryContainer = Color(0xFF384E28), onSecondaryContainer = Color(0xFFD5EDB5),
    tertiary = Color(0xFFEAC34A), tertiaryContainer = Color(0xFF564300),
    background = Color(0xFF101813), surface = Color(0xFF101813),
    surfaceVariant = Color(0xFF3D4940), onSurface = Color(0xFFE0E9E1),
    error = Color(0xFFFFB4AB), errorContainer = Color(0xFF93000A)
)

@Composable
fun MarketTheme(choice: ThemeChoice = ThemeChoice.SYSTEM, content: @Composable () -> Unit) {
    val dark = when (choice) {
        ThemeChoice.SYSTEM -> isSystemInDarkTheme()
        ThemeChoice.DARK -> true
        ThemeChoice.LIGHT -> false
    }
    val view = LocalView.current
    if (!view.isInEditMode) SideEffect {
        view.context.activity()?.let { activity ->
            val controller = WindowCompat.getInsetsController(activity.window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = if (dark) NightColors else DayColors,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(6.dp), small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(28.dp)
        ), content = content
    )
}

private tailrec fun Context.activity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> if (baseContext === this) null else baseContext.activity()
    else -> null
}
