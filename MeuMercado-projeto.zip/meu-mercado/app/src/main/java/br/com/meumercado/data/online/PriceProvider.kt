package br.com.meumercado.data.online

import br.com.meumercado.domain.MeasurementUnit
import br.com.meumercado.domain.Money
import br.com.meumercado.domain.PriceSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Retrofit
import java.io.IOException
import java.math.BigDecimal

/** Contrato para fontes autorizadas. Dados não confirmados nunca viram preços atuais locais automaticamente. */
data class ExternalPrice(
    val productName: String,
    val barcode: String?,
    val storeName: String,
    val priceCents: Long,
    val quantity: String,
    val unit: MeasurementUnit,
    val observedAt: Long,
    val sourceUrl: String,
    val sourceName: String,
    val kind: PriceSource,
    val promotionConditions: String = ""
)

sealed interface PriceProviderResult {
    data class Found(val prices: List<ExternalPrice>, val rejectedCount: Int = 0) : PriceProviderResult
    data class Unavailable(val reason: String) : PriceProviderResult
    data class Error(val reason: String) : PriceProviderResult
}

interface PriceProvider {
    val name: String
    suspend fun search(query: String, barcode: String? = null): PriceProviderResult
}

class LocalOnlyPriceProvider : PriceProvider {
    override val name = "Catálogo e histórico locais"
    override suspend fun search(query: String, barcode: String?): PriceProviderResult =
        PriceProviderResult.Unavailable("Nenhuma fonte externa de preços foi configurada. Consulte os registros locais; preços históricos não garantem disponibilidade atual.")
}

/** Integração real somente quando o usuário configura um gateway autorizado e concede consentimento. */
class GatewayPriceProvider(private val url: String, private val consent: Boolean) : PriceProvider {
    override val name = "Gateway configurado pelo usuário"
    private val service: GatewayService by lazy {
        Retrofit.Builder().baseUrl("https://localhost/").client(secureHttpClient()).build().create(GatewayService::class.java)
    }

    override suspend fun search(query: String, barcode: String?): PriceProviderResult {
        if (!consent) return PriceProviderResult.Unavailable("A consulta externa exige consentimento. Use o catálogo local.")
        val endpoint = GatewayConfiguration.endpoint(url, "prices") ?: return PriceProviderResult.Unavailable("Nenhum gateway HTTPS de preços está configurado.")
        if (query.isBlank() && barcode.isNullOrBlank()) return PriceProviderResult.Error("Informe um produto ou código para pesquisar.")
        if (query.length > 500 || (barcode?.length ?: 0) > 128) return PriceProviderResult.Error("A consulta informada é muito longa.")
        return withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject().put("query", query).put("barcode", barcode ?: JSONObject.NULL).put("locale", "pt-BR")
                val response = service.prices(endpoint, payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                if (!response.isSuccessful) {
                    response.errorBody()?.close()
                    return@withContext PriceProviderResult.Error("A fonte de preços respondeu com erro HTTP ${response.code()}.")
                }
                val body = response.body() ?: return@withContext PriceProviderResult.Error("A fonte de preços não retornou dados.")
                val text = body.use { readLimitedBody(it) } ?: return@withContext PriceProviderResult.Error("A resposta de preços é muito grande.")
                val values = JSONObject(text).optJSONArray("prices") ?: return@withContext PriceProviderResult.Error("Resposta inválida: prices deve ser uma lista.")
                if (values.length() > 100) return@withContext PriceProviderResult.Error("A fonte retornou mais de 100 preços; refine a pesquisa.")
                val accepted = mutableListOf<ExternalPrice>()
                var rejected = 0
                for (index in 0 until values.length()) {
                    val quote = runCatching {
                        GatewayPriceParser.quote(values.getJSONObject(index))
                    }.getOrNull()
                    if (quote != null) accepted += quote else rejected++
                }
                PriceProviderResult.Found(accepted, rejected)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: GatewayResponseTooLargeException) {
                PriceProviderResult.Error("A fonte retornou uma resposta de preços grande demais. Nenhum preço foi salvo.")
            } catch (_: IOException) {
                PriceProviderResult.Unavailable("Não foi possível conectar à fonte de preços. Use o catálogo e o histórico locais.")
            } catch (_: Exception) {
                PriceProviderResult.Error("A fonte retornou dados de preço inválidos. Nenhum preço foi salvo.")
            }
        }
    }
}

internal object GatewayPriceParser {
    fun quote(data: JSONObject, now: Long = System.currentTimeMillis()): ExternalPrice? = runCatching {
        ExternalPrice(
            productName = requiredString(data, "productName"), barcode = optionalString(data, "barcode").ifBlank { null },
            storeName = requiredString(data, "storeName"), priceCents = requiredLong(data, "priceCents"),
            quantity = requiredString(data, "quantity"), unit = MeasurementUnit.valueOf(requiredString(data, "unit")),
            observedAt = requiredLong(data, "observedAt"), sourceUrl = requiredString(data, "sourceUrl"), sourceName = requiredString(data, "sourceName"),
            kind = PriceSource.valueOf(requiredString(data, "kind")), promotionConditions = optionalString(data, "promotionConditions")
        ).takeIf { ExternalPriceValidator.isValid(it, now) }
    }.getOrNull()

    private fun requiredString(data: JSONObject, field: String): String =
        (data.get(field) as? String)?.trim() ?: error("O campo deve ser texto.")

    private fun optionalString(data: JSONObject, field: String): String =
        if (!data.has(field) || data.isNull(field)) "" else requiredString(data, field)

    private fun requiredLong(data: JSONObject, field: String): Long = when (val value = data.get(field)) {
        is Int -> value.toLong()
        is Long -> value
        else -> error("O campo deve ser um número inteiro exato.")
    }
}

object ExternalPriceValidator {
    fun isValid(price: ExternalPrice, now: Long = System.currentTimeMillis()): Boolean {
        if (price.sourceUrl.length > 4096) return false
        val source = price.sourceUrl.toHttpUrlOrNull() ?: return false
        val quantity = runCatching { Money.parseQuantity(price.quantity) }.getOrNull() ?: return false
        return source.scheme == "https" && source.username.isEmpty() && source.password.isEmpty() &&
            price.productName.isNotBlank() && price.productName.length <= 250 && price.storeName.isNotBlank() && price.storeName.length <= 250 &&
            price.sourceName.isNotBlank() && price.sourceName.length <= 250 && price.priceCents in 0..100_000_000_00L &&
            listOf(price.productName, price.storeName, price.sourceName).all { it.none(Char::isISOControl) } &&
            quantity > BigDecimal.ZERO && quantity <= BigDecimal("1000000") &&
            price.observedAt > 0 && price.observedAt <= now + 5 * 60_000 && price.promotionConditions.length <= 1000 &&
            (price.barcode == null || (price.barcode.length in 1..128 && price.barcode.none(Char::isISOControl)))
    }
}
