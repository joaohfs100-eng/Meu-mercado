package br.com.meumercado.data

import br.com.meumercado.database.*
import br.com.meumercado.domain.*
import org.json.JSONArray

internal fun ItemEntity.model() = ShoppingListItem(id, listId, productId, quantity, estimatedPriceCents, actualPriceCents, discountCents, ItemStatus.valueOf(status), priority, notes, position)
internal fun ShoppingListItem.entity() = ItemEntity(id, listId, productId, quantity, estimatedPriceCents, actualPriceCents, discountCents, status.name, priority, notes, position)
internal fun StoreEntity.model() = Store(id, name, address, neighborhood, city, notes, distanceKm, favorite)
internal fun Store.entity() = StoreEntity(id, name.trim(), address, neighborhood, city, notes, distanceKm, favorite)
internal fun ListEntity.model() = ShoppingList(id, name, storeId, favorite, archived, template, cadence, createdAt)
internal fun ShoppingList.entity() = ListEntity(id, name.trim(), storeId, favorite, archived, template, cadence, createdAt)
internal fun BudgetEntity.model() = BudgetSettings(listId, totalCents, safetyCents, safetyPercent, maximumCents, JSONArray(alertThresholds).let { values -> (0 until values.length()).map { values.getInt(it) }.toSet() })
internal fun BudgetSettings.entity() = BudgetEntity(listId, totalCents, safetyCents, safetyPercent, maximumCents, JSONArray(alertThresholds.sorted()).toString())
internal fun PriceEntity.model() = PriceObservation(id, productId, storeId, priceCents, observedAt, PriceSource.valueOf(source), sourceName, promotion, validUntil)
internal fun PriceObservation.entity() = PriceEntity(id, productId, storeId, priceCents, observedAt, source.name, sourceName, promotion, validUntil)
internal fun TaxEntity.model() = TaxRecord(id, historyId, amountCents, documented, includedInPrice, source)
internal fun TaxRecord.entity() = TaxEntity(id, historyId, amountCents, documented, includedInPrice, source)
internal fun DecisionEntity.model() = RecommendationDecision(id, itemId, oldProductId, newProductId, acceptedAt, savingsCents)
internal fun HistoryItemEntity.model() = HistoryItem(productName, brand, category, productId, quantity, MeasurementUnit.valueOf(unit), unitPriceCents, discountCents, totalCents, estimatedTotalCents, substituted)
internal fun HistoryItem.entity(historyId: Long) = HistoryItemEntity(historyId = historyId, productId = productId, productName = productName, brand = brand, category = category, quantity = quantity, unit = unit.name, unitPriceCents = unitPriceCents, discountCents = discountCents, totalCents = totalCents, estimatedTotalCents = estimatedTotalCents, substituted = substituted)
internal fun HistoryItem.sessionEntity(sessionId: Long) = SessionItemEntity(sessionId = sessionId, productId = productId, productName = productName, brand = brand, category = category, quantity = quantity, unit = unit.name, unitPriceCents = unitPriceCents, discountCents = discountCents, totalCents = totalCents, estimatedTotalCents = estimatedTotalCents, substituted = substituted)
