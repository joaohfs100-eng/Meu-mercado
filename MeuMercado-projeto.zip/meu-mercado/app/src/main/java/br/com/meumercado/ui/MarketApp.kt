package br.com.meumercado.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import br.com.meumercado.domain.*
import br.com.meumercado.features.*
import br.com.meumercado.features.ai.AiScreen
import br.com.meumercado.features.cart.CartScreen
import br.com.meumercado.features.budget.BudgetNotificationEffect
import br.com.meumercado.features.home.HomeScreen
import br.com.meumercado.features.products.ProductEditor
import br.com.meumercado.features.scanner.ScannerScreen
import br.com.meumercado.features.shoppinglist.ListsScreen
import br.com.meumercado.navigation.mainDestinations
import kotlinx.coroutines.launch

@Composable fun MarketApp() {
    val vm: MarketViewModel = hiltViewModel()
    MarketContent(vm)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MarketContent(vm: MarketViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    BudgetNotificationEffect(state)
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var scannerDraft by rememberSaveable(stateSaver = DraftSaver) { mutableStateOf<OcrDraft?>(null) }
    fun mainNavigate(destination: String) {
        nav.navigate(destination) { popUpTo(nav.graph.findStartDestination().id) { saveState = true }; launchSingleTop = true; restoreState = true }
    }
    fun openScanner() {
        if (state.activeList == null) scope.launch { snackbar.showSnackbar("Crie e selecione uma lista antes de escanear um produto.") }
        else nav.navigate("scanner") { launchSingleTop = true }
    }
    LaunchedEffect(state.error) { state.error?.let { snackbar.showSnackbar(it); vm.clearError() } }
    MarketTheme(choice = state.settings.theme) {
        Scaffold(
            topBar = {
                TopAppBar(title = { Column { Text(if (mainDestinations.any { it.route == route }) "Meu Mercado" else when (route) { "stores" -> "Supermercados"; "settings" -> "Configurações"; "reports" -> "Relatórios"; "scanner" -> "Scanner"; else -> "Meu Mercado" }); if (route == "home") Text("Compras inteligentes", style = MaterialTheme.typography.labelSmall) } },
                    navigationIcon = { if (mainDestinations.none { it.route == route }) IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") } },
                    actions = {
                        if (route != "scanner") IconButton(onClick = ::openScanner) { Icon(Icons.Default.CameraAlt, "Escanear produto") }
                        IconButton(onClick = { nav.navigate("stores") { launchSingleTop = true } }) { Icon(Icons.Default.Store, "Supermercados") }
                        IconButton(onClick = { nav.navigate("settings") { launchSingleTop = true } }) { Icon(Icons.Default.Settings, "Configurações") }
                    })
            },
            bottomBar = {
                if (route != "scanner") NavigationBar {
                    mainDestinations.forEach { destination -> NavigationBarItem(modifier = Modifier.testTag("nav_${destination.route}"), selected = route == destination.route, onClick = { mainNavigate(destination.route) }, icon = { Icon(destination.icon, null) }, label = { Text(destination.title, maxLines = 1) }) }
                }
            }, snackbarHost = { SnackbarHost(snackbar) }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).imePadding()) {
                NavHost(nav, startDestination = "home") {
                    composable("home") { HomeScreen(state, vm, onLists = { mainNavigate("lists") }, onScan = ::openScanner, onStores = { nav.navigate("stores") }, onReports = { nav.navigate("reports") }, onAi = { mainNavigate("ai") }) }
                    composable("lists") { ListsScreen(state, vm, onScan = ::openScanner, onAi = { mainNavigate("ai") }) }
                    composable("cart") { CartScreen(state, vm, onScan = ::openScanner, onLists = { mainNavigate("lists") }, onHistory = { mainNavigate("history") }) }
                    composable("history") { HistoryScreen(state, vm) }
                    composable("ai") { AiScreen(state, vm, onSettings = { nav.navigate("settings") }) }
                    composable("settings") { SettingsScreen(state, vm) }
                    composable("stores") { StoresScreen(state, vm) }
                    composable("reports") { ReportsScreen(state) }
                    composable("scanner") { ScannerScreen(onConfirm = { scannerDraft = it; nav.popBackStack() }, onBack = { nav.popBackStack() }) }
                }
                if (state.loading) CircularProgressIndicator(Modifier.padding(24.dp))
            }
        }
        scannerDraft?.let { draft ->
            val existing = draft.barcode?.let { code -> state.snapshot.products.firstOrNull { it.barcode == code } }
            ProductEditor(product = existing, draft = draft, canObservePrice = state.activeList?.storeId != null, initialObserved = draft.priceCents != null, onDismiss = { scannerDraft = null }) { product, qty, price, _, observed ->
                vm.addProductToActiveList(product, qty, price, observed = observed)
                scannerDraft = null
            }
        }
    }
}

private val DraftSaver = Saver<OcrDraft?, List<Any>>(
    save = { draft -> draft?.let { listOf(it.name, it.priceCents ?: -1L, it.unit.name, it.packageQuantity, it.packageUnit.name, it.barcode ?: "", it.promotion, it.rawText, it.warnings.joinToString("\n")) } },
    restore = { values -> OcrDraft(name = values[0] as String, priceCents = (values[1] as Long).takeIf { it >= 0 }, unit = MeasurementUnit.valueOf(values[2] as String), packageQuantity = values[3] as String, packageUnit = MeasurementUnit.valueOf(values[4] as String), barcode = (values[5] as String).takeIf { it.isNotBlank() }, promotion = values[6] as String, rawText = values[7] as String, warnings = (values[8] as String).split('\n').filter(String::isNotBlank)) }
)
