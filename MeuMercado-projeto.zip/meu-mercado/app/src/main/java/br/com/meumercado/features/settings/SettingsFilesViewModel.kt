package br.com.meumercado.features.settings

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.meumercado.domain.AppSnapshot
import br.com.meumercado.ui.MarketViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class FileOperationState(val busy: Boolean = false, val message: String? = null)

/** Mantém operações de arquivos em execução durante mudanças de orientação. */
class SettingsFilesViewModel : ViewModel() {
    private val mutableState = MutableStateFlow(FileOperationState())
    val state: StateFlow<FileOperationState> = mutableState.asStateFlow()

    fun exportJson(resolver: ContentResolver, uri: Uri, market: MarketViewModel) = runOperation {
        val json = market.exportBackup()
        write(resolver, uri, json)
        "Backup JSON exportado. Guarde o arquivo em local seguro: ele contém seus dados de compras."
    }

    fun exportCsv(resolver: ContentResolver, uri: Uri, snapshot: AppSnapshot) = runOperation {
        val csv = withContext(Dispatchers.Default) { HistoryCsvExporter.export(snapshot) }
        write(resolver, uri, csv)
        "Histórico CSV exportado."
    }

    fun restore(resolver: ContentResolver, uri: Uri, market: MarketViewModel) = runOperation {
        val json = read(resolver, uri)
        market.restoreBackup(json)
        "Backup restaurado com sucesso."
    }

    private fun runOperation(operation: suspend () -> String) {
        if (mutableState.value.busy) return
        mutableState.value = FileOperationState(busy = true)
        viewModelScope.launch {
            try {
                mutableState.value = FileOperationState(message = operation())
            } catch (cancelled: CancellationException) {
                mutableState.value = FileOperationState(message = "Operação interrompida. Se necessário, selecione o arquivo novamente.")
                throw cancelled
            } catch (_: SecurityException) {
                mutableState.value = FileOperationState(message = "O acesso ao arquivo não foi autorizado ou expirou. Selecione o arquivo novamente pelo seletor do Android.")
            } catch (error: Exception) {
                mutableState.value = FileOperationState(message = error.message ?: "Não foi possível concluir a operação de arquivo.")
            }
        }
    }

    private suspend fun write(resolver: ContentResolver, uri: Uri, text: String) = withContext(Dispatchers.IO) {
        resolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
            ?: error("Não foi possível abrir o arquivo para escrita.")
    }

    private suspend fun read(resolver: ContentResolver, uri: Uri): String = withContext(Dispatchers.IO) {
        resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(8192)
            val output = java.io.ByteArrayOutputStream()
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                require(output.size() + count <= 16 * 1024 * 1024) { "Backup excede o limite de 16 MB." }
                output.write(buffer, 0, count)
            }
            output.toString(Charsets.UTF_8.name())
        } ?: error("Não foi possível ler o arquivo.")
    }
}
