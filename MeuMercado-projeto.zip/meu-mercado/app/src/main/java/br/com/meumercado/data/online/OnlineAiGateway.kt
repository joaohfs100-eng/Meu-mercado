package br.com.meumercado.data.online

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okio.Buffer
import okio.ForwardingSource
import okio.buffer
import org.json.JSONObject
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Url
import retrofit2.http.Streaming
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed interface OnlineAiResult {
    data class Success(val answer: String, val source: String) : OnlineAiResult
    data class Unavailable(val reason: String) : OnlineAiResult
    data class Error(val reason: String) : OnlineAiResult
}

/** O backend é configurado pelo usuário. Nenhuma chave privada fica no aplicativo. */
class OnlineAiGateway {
    private val service: GatewayService by lazy {
        Retrofit.Builder().baseUrl("https://localhost/").client(secureHttpClient()).build().create(GatewayService::class.java)
    }

    suspend fun ask(url: String, query: String, consent: Boolean): OnlineAiResult {
        if (!consent) return OnlineAiResult.Unavailable("A IA online está desativada. Autorize o envio desta pergunta nas configurações; as recomendações locais continuam disponíveis.")
        val endpoint = GatewayConfiguration.endpoint(url, "chat")
            ?: return OnlineAiResult.Unavailable("Configure a URL HTTPS de um backend de IA confiável. Nenhum serviço online está conectado.")
        if (query.isBlank() || query.length > 4000) return OnlineAiResult.Error("Escreva uma pergunta de até 4.000 caracteres.")
        return withContext(Dispatchers.IO) {
            try {
                // Somente a pergunta é enviada; catálogo, histórico, notas e preferências permanecem locais.
                val payload = JSONObject().put("query", query).put("locale", "pt-BR").toString()
                val response = service.chat(endpoint, payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
                if (!response.isSuccessful) {
                    response.errorBody()?.close()
                    return@withContext OnlineAiResult.Error("O backend de IA respondeu com erro HTTP ${response.code()}. Use o assistente local enquanto isso.")
                }
                val body = response.body() ?: return@withContext OnlineAiResult.Error("O backend não retornou uma resposta.")
                val raw = body.use { readLimitedBody(it) } ?: return@withContext OnlineAiResult.Error("A resposta recebida excedeu o limite permitido.")
                val answer = GatewayResponseParser.answer(raw)
                    ?: return@withContext OnlineAiResult.Error("A resposta do backend não contém um texto válido no campo answer.")
                OnlineAiResult.Success(answer, endpoint.toHttpUrlOrNull()!!.host)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: GatewayResponseTooLargeException) {
                OnlineAiResult.Error("A resposta do backend excedeu o limite permitido. Nenhuma alteração foi aplicada.")
            } catch (_: IOException) {
                OnlineAiResult.Unavailable("Sem conexão com o backend de IA. O assistente e as recomendações locais continuam funcionando.")
            } catch (_: Exception) {
                OnlineAiResult.Error("A resposta do backend de IA é inválida. Nenhuma alteração foi aplicada aos seus dados.")
            }
        }
    }
}

internal interface GatewayService {
    @POST
    @Streaming
    suspend fun chat(@Url endpoint: String, @Body payload: RequestBody): Response<ResponseBody>

    @POST
    @Streaming
    suspend fun prices(@Url endpoint: String, @Body payload: RequestBody): Response<ResponseBody>
}

object GatewayConfiguration {
    fun endpoint(base: String, route: String): String? {
        if (base.isBlank() || base.length > 2048 || route !in setOf("chat", "prices")) return null
        val parsed = base.trim().toHttpUrlOrNull() ?: return null
        if (parsed.scheme != "https" || parsed.username.isNotEmpty() || parsed.password.isNotEmpty() || parsed.query != null || parsed.fragment != null) return null
        val normalized = parsed.newBuilder().encodedPath(parsed.encodedPath.trimEnd('/').ifBlank { "/" }).build()
        return when (normalized.pathSegments.lastOrNull()) {
            route -> normalized.toString()
            "chat", "prices" -> normalized.newBuilder().setPathSegment(normalized.pathSegments.lastIndex, route).build().toString()
            else -> normalized.newBuilder().addPathSegment(route).build().toString()
        }
    }
}

internal object GatewayResponseParser {
    fun answer(raw: String): String? = runCatching {
        (JSONObject(raw).opt("answer") as? String)?.trim()?.takeIf { it.isNotBlank() && it.length <= 20_000 }
    }.getOrNull()
}

internal fun secureHttpClient(): OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(25, TimeUnit.SECONDS)
    .callTimeout(35, TimeUnit.SECONDS)
    .retryOnConnectionFailure(false)
    .followRedirects(false)
    .followSslRedirects(false)
    .addInterceptor { chain ->
        val response = chain.proceed(chain.request())
        val body = response.body ?: return@addInterceptor response
        if (body.contentLength() > MAX_RESPONSE_BYTES) {
            body.close()
            throw GatewayResponseTooLargeException()
        }
        // Também limita respostas de erro, que o Retrofit normalmente tenta carregar inteiras.
        val boundedSource = object : ForwardingSource(body.source()) {
            private var bytesRead = 0L
            override fun read(sink: Buffer, byteCount: Long): Long {
                val count = super.read(sink, minOf(byteCount, MAX_RESPONSE_BYTES + 1 - bytesRead))
                if (count > 0) bytesRead += count
                if (bytesRead > MAX_RESPONSE_BYTES) throw GatewayResponseTooLargeException()
                return count
            }
        }.buffer()
        val boundedBody = object : ResponseBody() {
            override fun contentType() = body.contentType()
            override fun contentLength() = body.contentLength()
            override fun source() = boundedSource
        }
        response.newBuilder().body(boundedBody).build()
    }
    .build()

internal const val MAX_RESPONSE_BYTES = 128 * 1024L
internal class GatewayResponseTooLargeException : IOException("Resposta excede o limite permitido.")

internal fun readLimitedBody(body: ResponseBody): String? {
    if (body.contentLength() > MAX_RESPONSE_BYTES) return null
    val source = body.source()
    source.request(MAX_RESPONSE_BYTES + 1)
    if (source.buffer.size > MAX_RESPONSE_BYTES) return null
    return source.readUtf8()
}
