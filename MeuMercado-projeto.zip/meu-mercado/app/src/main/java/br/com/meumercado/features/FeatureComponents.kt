package br.com.meumercado.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

internal val brazilDate: DateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")
internal fun dateLabel(timestamp: Long): String = Instant.ofEpochMilli(timestamp)
    .atZone(ZoneId.systemDefault()).toLocalDate().format(brazilDate)

private fun parsePeriodDate(value: String): LocalDate? {
    val format = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)
    return runCatching { LocalDate.parse(value.trim(), format) }.getOrNull()
        ?: runCatching { LocalDate.parse(value.trim()) }.getOrNull()
}

internal data class PeriodSelection(val kind: String = "Mês", val start: String = "", val end: String = "") {
    fun accepts(timestamp: Long): Boolean {
        val date = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate()
        val today = LocalDate.now()
        return when (kind) {
            "Dia" -> date == today
            "Semana" -> date >= today.minusDays(6) && date <= today
            "Mês" -> date.year == today.year && date.month == today.month
            "Ano" -> date.year == today.year
            "Personalizado" -> {
                val from = parsePeriodDate(start)
                val until = parsePeriodDate(end)
                from != null && until != null && from <= until && date >= from && date <= until
            }
            else -> true
        }
    }
    fun error(): String? {
        if (kind != "Personalizado") return null
        val from = parsePeriodDate(start)
        val until = parsePeriodDate(end)
        return when {
            from == null || until == null -> "Informe datas válidas no formato DD/MM/AAAA."
            from > until -> "A data inicial deve vir antes da final."
            else -> null
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun PeriodFilter(value: PeriodSelection, onChange: (PeriodSelection) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Dia", "Semana", "Mês", "Ano", "Tudo", "Personalizado").forEach { period ->
                FilterChip(selected = value.kind == period, onClick = { onChange(value.copy(kind = period)) }, label = { Text(period) })
            }
        }
        if (value.kind == "Personalizado") {
            OutlinedTextField(value.start, { onChange(value.copy(start = it)) }, label = { Text("Início · DD/MM/AAAA") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value.end, { onChange(value.copy(end = it)) }, label = { Text("Fim · DD/MM/AAAA") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            value.error()?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
internal fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ChoiceChips(choices: List<String>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        choices.forEach { choice -> FilterChip(selected = selected == choice, onClick = { onSelect(choice) }, label = { Text(choice) }) }
    }
}

@Composable
internal fun rememberPeriod(): Pair<PeriodSelection, (PeriodSelection) -> Unit> {
    var kind by rememberSaveable { mutableStateOf("Mês") }
    var start by rememberSaveable { mutableStateOf("") }
    var end by rememberSaveable { mutableStateOf("") }
    return PeriodSelection(kind, start, end) to { value: PeriodSelection -> kind = value.kind; start = value.start; end = value.end }
}
