package br.com.meumercado.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [CategoryEntity::class, BrandEntity::class, TagEntity::class, ProductEntity::class,
        ProductTagEntity::class, FavoriteBrandEntity::class, StoreEntity::class, ListEntity::class,
        ItemEntity::class, BudgetEntity::class, PriceEntity::class, SessionEntity::class,
        SessionItemEntity::class, HistoryEntity::class, HistoryItemEntity::class, TaxEntity::class,
        ReceiptEntity::class, DecisionEntity::class, ProductAlternativeEntity::class,
        RecommendationEntity::class, AiSettingsEntity::class, UserPreferenceEntity::class,
        SearchEntity::class, UndoEntity::class],
    version = 2, exportSchema = true
)
abstract class MarketDatabase : RoomDatabase() {
    abstract fun dao(): MarketDao

    companion object {
        /** Version 1 had the same schema except the explicit, locally learned acceptance flag. */
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE products ADD COLUMN accepted INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** Parent tables first. Backup restoration follows this order; erasure reverses it. */
        val TABLES = listOf("product_categories", "brands", "tags", "stores", "products", "product_tags",
            "favorite_brands", "shopping_lists", "shopping_list_items", "budget_settings",
            "price_observations", "shopping_sessions", "session_items", "shopping_history",
            "history_items", "tax_records", "receipts", "recommendation_decisions",
            "product_alternatives", "recommendations", "ai_settings", "user_preferences",
            "search_history", "undo_records")
    }
}
