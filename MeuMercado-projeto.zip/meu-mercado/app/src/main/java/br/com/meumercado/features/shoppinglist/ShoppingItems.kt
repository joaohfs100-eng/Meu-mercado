package br.com.meumercado.features.shoppinglist

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.features.ai.AlternativesDialog
import br.com.meumercado.features.cart.CartEntryDialog
import br.com.meumercado.features.products.*
import br.com.meumercado.ui.*

@Composable fun ShoppingItems(state: MarketUiState, vm: MarketViewModel, items: List<ShoppingListItem>, onScan: () -> Unit) {
    var adding by rememberSaveable { mutableStateOf(false) }
    var catalog by rememberSaveable { mutableStateOf(false) }
    var selectedProductId by rememberSaveable { mutableStateOf<Long?>(null) }
    var editingItemId by rememberSaveable { mutableStateOf<Long?>(null) }
    var placingItemId by rememberSaveable { mutableStateOf<Long?>(null) }
    var alternativeItemId by rememberSaveable { mutableStateOf<Long?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf("category") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { catalog = true }, Modifier.weight(1f)) { Text("Adicionar produto") }
            OutlinedButton(onScan, Modifier.weight(1f)) { Text("Escanear") }
        }
        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Pesquisar nesta lista") }, singleLine = true)
        ChoiceField("Organizar por", when (sort) { "name" -> "Nome"; "priority" -> "Prioridade"; "position" -> "Ordem de inclusão"; else -> "Categoria" }, listOf("Categoria" to "category", "Nome" to "name", "Prioridade" to "priority", "Ordem de inclusão" to "position")) { sort = it }
        val products = state.snapshot.products.associateBy { it.id }
        val filtered = items.filter { item -> products[item.productId]?.let { (it.name + " " + it.brand + " " + it.tags.joinToString(" ") + " " + it.barcode.orEmpty()).contains(search, ignoreCase = true) } == true }
            .sortedWith(when (sort) {
                "name" -> compareBy { products[it.productId]?.name }
                "priority" -> compareBy { it.priority }
                "position" -> compareBy { it.position }
                else -> compareBy<ShoppingListItem> { products[it.productId]?.category }.thenBy { products[it.productId]?.name }
            })
        filtered.forEach { item ->
            products[item.productId]?.let { product ->
                key(item.id) {
                    ShoppingItemCard(item, product, onEdit = { editingItemId = item.id }, onStatus = { if (it == ItemStatus.IN_CART) placingItemId = item.id else vm.setItemStatus(item.id, it) }, onFindCheaper = { alternativeItemId = item.id })
                }
            }
        }
        if (filtered.isEmpty()) Text(if (items.isEmpty()) "Sua lista está vazia. Adicione o primeiro produto." else "Nenhum produto corresponde à busca.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (catalog) ProductCatalogDialog(state, vm, onDismiss = { catalog = false }, onSelect = { catalog = false; selectedProductId = it.id; adding = true }, onNew = { catalog = false; selectedProductId = null; adding = true })
    if (adding) {
        val product = state.snapshot.products.firstOrNull { it.id == selectedProductId }
        val latestPrice = product?.let { chosen -> state.snapshot.prices.filter { it.productId == chosen.id && it.storeId == state.activeList?.storeId }.maxByOrNull { it.observedAt } }
        val priceDraft = latestPrice?.let { OcrDraft(priceCents = it.priceCents, warnings = listOf("Referência registrada em ${dateText(it.observedAt)}. Use como estimativa; confirme o preço atual.")) }
        key(selectedProductId) { ProductEditor(product = product, draft = priceDraft, canObservePrice = state.activeList?.storeId != null, onDismiss = { adding = false }) { saved, qty, price, _, observed -> vm.addProductToActiveList(saved, qty, price, observed); adding = false } }
    }
    editingItemId?.let { id ->
        state.snapshot.items.firstOrNull { it.id == id }?.let { item ->
            key(id) { ProductEditor(product = state.snapshot.products.firstOrNull { it.id == item.productId }, item = item, onDismiss = { editingItemId = null }) { product, _, _, changed, _ -> changed?.let { vm.updateProductAndItem(product, it) }; editingItemId = null } }
        }
    }
    placingItemId?.let { id ->
        state.snapshot.items.firstOrNull { it.id == id }?.let { item ->
            state.snapshot.products.firstOrNull { it.id == item.productId }?.let { product ->
                CartEntryDialog(item, product, onDismiss = { placingItemId = null }) { qty, price, discount ->
                    vm.placeInCart(id, qty, price, discount)
                    placingItemId = null
                }
            }
        }
    }
    alternativeItemId?.let { id -> state.snapshot.items.firstOrNull { it.id == id }?.let { item -> AlternativesDialog(state, vm, item, onDismiss = { alternativeItemId = null }) } }
}
