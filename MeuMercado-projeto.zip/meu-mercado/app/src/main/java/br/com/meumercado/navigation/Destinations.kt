package br.com.meumercado.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.ui.graphics.vector.ImageVector

data class MainDestination(val route: String, val title: String, val icon: ImageVector)
val mainDestinations = listOf(
    MainDestination("home", "Início", Icons.Default.Home),
    MainDestination("lists", "Listas", Icons.Default.ListAlt),
    MainDestination("cart", "Carrinho", Icons.Default.ShoppingCart),
    MainDestination("history", "Histórico", Icons.Default.History),
    MainDestination("ai", "Assistente IA", Icons.Default.AutoAwesome)
)
