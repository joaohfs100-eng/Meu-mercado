package br.com.meumercado.features.ai

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*
import java.math.BigDecimal
import java.math.RoundingMode

@Composable fun OptimizerPanel(state: MarketUiState, vm: MarketViewModel) {
    var analyze by rememberSaveable { mutableStateOf(false) }
    var otherStores by rememberSaveable { mutableStateOf(false) }
    var approved by rememberSaveable { mutableStateOf(listOf<Long>()) }
    var confirmAll by rememberSaveable { mutableStateOf(false) }
    var alternativeId by rememberSaveable { mutableStateOf<Long?>(null) }
    val optimization = remember(state.snapshot, state.settings, otherStores) { RecommendationEngine().optimize(state.activeItems, state.snapshot.products, state.snapshot.prices, state.settings, state.activeList?.storeId, otherStores) }
    LaunchedEffect(state.settings.mode, otherStores) { approved = emptyList() }
    SectionCard("Otimizar minha lista com IA") {
        Text("Sugestões com equivalências e preços registrados. Itens no carrinho só mudam mediante confirmação específica.", style = MaterialTheme.typography.bodySmall)
        Row { Checkbox(otherStores, { otherStores = it }); Text("Comparar também outros mercados", Modifier.padding(top = 12.dp)) }
        if (otherStores) Text("Valores de outros mercados servem como comparação. Verifique os preços no mercado ativo antes de aplicar; compras em outro local precisam de listas/sessões separadas.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Button(onClick = { analyze = true }, Modifier.fillMaxWidth(), enabled = state.activeList != null) { Text("Otimizar minha lista com IA") }
        if (analyze) {
            val saving = (optimization.originalCents - optimization.optimizedCents).coerceAtLeast(0)
            val percent = if (optimization.originalCents == 0L) "0" else BigDecimal(saving).multiply(BigDecimal(100)).divide(BigDecimal(optimization.originalCents), 1, RoundingMode.HALF_UP).toPlainString().replace('.', ',')
            Text("Estimativa original: ${Money.format(optimization.originalCents)}")
            Text("Estimativa otimizada: ${Money.format(optimization.optimizedCents)}")
            Text("Economia potencial: ${Money.format(saving)} ($percent%)", color = MaterialTheme.colorScheme.primary)
            if (optimization.missingPrices > 0) Text("⚠ ${optimization.missingPrices} itens sem preço. Os totais conhecidos não representam a compra completa.")
            if (optimization.duplicates.isNotEmpty()) Text("Produtos duplicados: ${optimization.duplicates.joinToString(", ")}. Revise as quantidades na lista.")
            val protected = state.activeItems.filter { item -> state.snapshot.products.firstOrNull { it.id == item.productId }?.neverSubstitute == true }
            if (protected.isNotEmpty()) Text("${protected.size} produtos protegidos serão mantidos.")
            if (optimization.suggestions.isEmpty()) Text("Nenhuma economia verificável nos dados disponíveis. Registre preços e grupos de equivalência para comparar.")
            optimization.suggestions.forEach { suggestion ->
                val best = suggestion.alternatives.firstOrNull { !it.optionalOutsideFavorites } ?: suggestion.alternatives.first()
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${suggestion.original.name} → ${best.product.name}", style = MaterialTheme.typography.titleSmall)
                        AlternativeDetails(best, state)
                        Row { Checkbox(suggestion.item.id in approved, { checked -> approved = if (checked) approved + suggestion.item.id else approved - suggestion.item.id }); Text("Aprovo esta troca", Modifier.padding(top = 12.dp)) }
                        TextButton(onClick = { alternativeId = suggestion.item.id }) { Text("Ver opções e aplicar individualmente") }
                    }
                }
            }
            Button(onClick = { confirmAll = true }, enabled = approved.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Aplicar todas as substituições aprovadas (${approved.size})") }
            OutlinedButton(onClick = vm::undo, Modifier.fillMaxWidth()) { Text("Desfazer última alteração") }
        }
    }
    alternativeId?.let { id -> state.activeItems.firstOrNull { it.id == id }?.let { AlternativesDialog(state, vm, it, onDismiss = { alternativeId = null }) } }
    val changes = optimization.suggestions.filter { it.item.id in approved }.map { it.item.id to (it.alternatives.firstOrNull { option -> !option.optionalOutsideFavorites } ?: it.alternatives.first()) }
    if (confirmAll) AlertDialog(onDismissRequest = { confirmAll = false }, title = { Text("Confirmar ${changes.size} substituições?") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Só os itens marcados como aprovados serão alterados. Produtos já no carrinho permanecem iguais.")
            if (changes.any { it.second.observation.storeId != state.activeList?.storeId }) Text("⚠ Há preços de outros mercados. Confirme apenas se você verificou os mesmos valores no mercado desta lista. Para comprar em outro local, crie ou selecione uma lista daquele estabelecimento.", color = MaterialTheme.colorScheme.error)
            if (changes.any { it.second.optionalOutsideFavorites }) Text("⚠ Há marcas fora das suas favoritas selecionadas por você.")
            Text("Economia das trocas aprovadas: ${Money.format(changes.sumOf { it.second.savingsCents })}")
        }
    }, confirmButton = { TextButton(onClick = { vm.applySubstitutions(changes); approved = emptyList(); confirmAll = false }) { Text("Confirmar e aplicar") } }, dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancelar") } })
}
