package br.com.meumercado.features.shoppinglist

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.features.home.BudgetDialog
import br.com.meumercado.features.products.ChoiceField
import br.com.meumercado.ui.*

@Composable fun ListsScreen(state: MarketUiState, vm: MarketViewModel, onScan: () -> Unit, onAi: () -> Unit) {
    var create by rememberSaveable { mutableStateOf(false) }
    var editId by rememberSaveable { mutableStateOf<Long?>(null) }
    var deleteId by rememberSaveable { mutableStateOf<Long?>(null) }
    var archived by rememberSaveable { mutableStateOf(false) }
    var budget by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Minhas listas", style = MaterialTheme.typography.headlineSmall)
            Button(onClick = { create = true }) { Text("Nova lista") }
        }
        Row { Switch(archived, { archived = it }); Text("Mostrar arquivadas", Modifier.padding(start = 8.dp, top = 12.dp)) }
        state.snapshot.lists.filter { it.archived == archived }.sortedWith(compareByDescending<ShoppingList> { it.favorite }.thenByDescending { it.createdAt }).forEach { list ->
            var menu by remember(list.id) { mutableStateOf(false) }
            OutlinedCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp).fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text(list.name, style = MaterialTheme.typography.titleMedium)
                        Text("${list.cadence}${if (list.template) " • Modelo reutilizável" else ""}${if (list.favorite) " • Favorita" else ""}", style = MaterialTheme.typography.bodySmall)
                        Text(state.snapshot.stores.firstOrNull { it.id == list.storeId }?.name ?: "Sem mercado", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { vm.activateList(list.id) }) { Text(if (list.id == state.activeList?.id) "Lista ativa ✓" else if (list.template) "Selecionar modelo" else "Usar esta lista") }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Ações de ${list.name}") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text("Editar / renomear") }, onClick = { menu = false; editId = list.id })
                            DropdownMenuItem(text = { Text("Duplicar / reutilizar") }, onClick = { menu = false; vm.duplicateList(list.id) })
                            DropdownMenuItem(text = { Text(if (list.favorite) "Remover dos favoritos" else "Favoritar") }, onClick = { menu = false; vm.saveList(list.copy(favorite = !list.favorite)) })
                            DropdownMenuItem(text = { Text(if (list.template) "Deixar de ser modelo" else "Salvar como modelo") }, onClick = { menu = false; vm.saveList(list.copy(template = !list.template)) })
                            DropdownMenuItem(text = { Text(if (list.archived) "Desarquivar" else "Arquivar") }, onClick = { menu = false; vm.saveList(list.copy(archived = !list.archived)) })
                            DropdownMenuItem(text = { Text("Compartilhar texto") }, onClick = {
                                menu = false
                                val text = buildString { appendLine("Meu Mercado — ${list.name}"); state.snapshot.items.filter { it.listId == list.id && it.status != ItemStatus.REMOVED }.forEach { item -> state.snapshot.products.firstOrNull { it.id == item.productId }?.let { product -> appendLine("• ${product.name} (${product.brand}) — ${item.quantity} ${product.saleUnit.label} — ${item.status.portuguese()}") } } }
                                context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartilhar lista"))
                            })
                            DropdownMenuItem(text = { Text("Excluir lista") }, onClick = { menu = false; deleteId = list.id })
                        }
                    }
                }
            }
        }
        if (state.snapshot.lists.none { it.archived == archived }) EmptyState("Nenhuma lista aqui", "Crie listas semanais, mensais ou modelos para reutilizar.")
        state.activeList?.let { list ->
            SectionCard("Produtos • ${list.name}") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { budget = true }, Modifier.weight(1f)) { Text("Orçamento") }
                    OutlinedButton(onAi, Modifier.weight(1f)) { Text("Otimizar com IA") }
                }
                ShoppingItems(state, vm, state.activeItems, onScan)
            }
        }
    }
    if (create || editId != null) {
        val editing = state.snapshot.lists.firstOrNull { it.id == editId }
        key(editId) { ListDialog(editing, state.snapshot.stores, onDismiss = { create = false; editId = null }) { vm.saveList(it); create = false; editId = null } }
    }
    deleteId?.let { id -> AlertDialog(onDismissRequest = { deleteId = null }, title = { Text("Excluir lista?") }, text = { Text("A lista e seus itens serão excluídos. Compras finalizadas continuam no histórico.") }, confirmButton = { TextButton(onClick = { vm.deleteList(id); deleteId = null }) { Text("Excluir") } }, dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } }) }
    if (budget) BudgetDialog(state.activeBudget, onDismiss = { budget = false }) { vm.saveBudget(it); budget = false }
}

@Composable private fun ListDialog(list: ShoppingList?, stores: List<Store>, onDismiss: () -> Unit, onSave: (ShoppingList) -> Unit) {
    var name by rememberSaveable { mutableStateOf(list?.name ?: "") }
    var storeId by rememberSaveable { mutableStateOf(list?.storeId) }
    var cadence by rememberSaveable { mutableStateOf(list?.cadence ?: "Avulsa") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (list == null) "Nova lista" else "Editar lista") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nome da lista") }, singleLine = true)
            ChoiceField("Supermercado", stores.firstOrNull { it.id == storeId }?.name ?: "Selecionar depois", listOf("Selecionar depois" to "") + stores.map { it.name to it.id.toString() }) { storeId = it.toLongOrNull() }
            ChoiceField("Frequência", cadence, listOf("Avulsa", "Semanal", "Mensal").map { it to it }) { cadence = it }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = { if (name.isBlank()) error = "Informe o nome da lista." else onSave((list ?: ShoppingList(name = name)).copy(name = name.trim(), storeId = storeId, cadence = cadence)) }) { Text("Salvar") } }, dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
}
