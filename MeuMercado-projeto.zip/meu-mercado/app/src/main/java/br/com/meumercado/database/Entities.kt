package br.com.meumercado.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "product_categories", indices = [Index(value = ["name"], unique = true)])
data class CategoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "brands", indices = [Index(value = ["name"], unique = true)])
data class BrandEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "tags", indices = [Index(value = ["name"], unique = true)])
data class TagEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "products", foreignKeys = [
    ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.RESTRICT),
    ForeignKey(entity = BrandEntity::class, parentColumns = ["id"], childColumns = ["brandId"], onDelete = ForeignKey.RESTRICT)
], indices = [Index("categoryId"), Index("brandId"), Index(value = ["barcode"], unique = true), Index("name")])
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String,
    val brandId: Long?, val categoryId: Long, val barcode: String?, val photoUri: String?,
    val saleUnit: String, val packageQuantity: String, val packageUnit: String,
    val equivalenceKey: String, val characteristics: String, val restrictions: String,
    val favorite: Boolean, val neverSubstitute: Boolean,
    @ColumnInfo(defaultValue = "0") val accepted: Boolean = false, val notes: String
)

@Entity(tableName = "product_tags", primaryKeys = ["productId", "tagId"], foreignKeys = [
    ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = TagEntity::class, parentColumns = ["id"], childColumns = ["tagId"], onDelete = ForeignKey.CASCADE)
], indices = [Index("tagId")])
data class ProductTagEntity(val productId: Long, val tagId: Long)

@Entity(tableName = "favorite_brands", primaryKeys = ["categoryId", "brandId"], foreignKeys = [
    ForeignKey(entity = CategoryEntity::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = BrandEntity::class, parentColumns = ["id"], childColumns = ["brandId"], onDelete = ForeignKey.CASCADE)
], indices = [Index("brandId")])
data class FavoriteBrandEntity(val categoryId: Long, val brandId: Long)

@Entity(tableName = "stores", indices = [Index("name")])
data class StoreEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val address: String, val neighborhood: String, val city: String, val notes: String, val distanceKm: String?, val favorite: Boolean)

@Entity(tableName = "shopping_lists", foreignKeys = [ForeignKey(entity = StoreEntity::class, parentColumns = ["id"], childColumns = ["storeId"], onDelete = ForeignKey.SET_NULL)], indices = [Index("storeId")])
data class ListEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val storeId: Long?, val favorite: Boolean, val archived: Boolean, val template: Boolean, val cadence: String, val createdAt: Long)

@Entity(tableName = "shopping_list_items", foreignKeys = [
    ForeignKey(entity = ListEntity::class, parentColumns = ["id"], childColumns = ["listId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.RESTRICT)
], indices = [Index("listId"), Index("productId")])
data class ItemEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val listId: Long, val productId: Long, val quantity: String, val estimatedPriceCents: Long, val actualPriceCents: Long?, val discountCents: Long, val status: String, val priority: Int, val notes: String, val position: Int)

@Entity(tableName = "budget_settings", foreignKeys = [ForeignKey(entity = ListEntity::class, parentColumns = ["id"], childColumns = ["listId"], onDelete = ForeignKey.CASCADE)])
data class BudgetEntity(@PrimaryKey val listId: Long, val totalCents: Long, val safetyCents: Long, val safetyPercent: String, val maximumCents: Long?, val alertThresholds: String)

@Entity(tableName = "price_observations", foreignKeys = [
    ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = StoreEntity::class, parentColumns = ["id"], childColumns = ["storeId"], onDelete = ForeignKey.CASCADE)
], indices = [Index(value = ["productId", "storeId", "observedAt"]), Index("storeId")])
data class PriceEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val productId: Long, val storeId: Long, val priceCents: Long, val observedAt: Long, val source: String, val sourceName: String, val promotion: String, val validUntil: Long?)

@Entity(tableName = "shopping_sessions", foreignKeys = [
    ForeignKey(entity = ListEntity::class, parentColumns = ["id"], childColumns = ["listId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = StoreEntity::class, parentColumns = ["id"], childColumns = ["storeId"], onDelete = ForeignKey.SET_NULL)
], indices = [Index("listId"), Index("storeId")])
data class SessionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val listId: Long, val storeId: Long?, val startedAt: Long, val completedAt: Long? = null)

/** Snapshot of the product as it was bought; deliberately independent of mutable catalogue. */
@Entity(tableName = "session_items", foreignKeys = [ForeignKey(entity = SessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)], indices = [Index("sessionId")])
data class SessionItemEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val sessionId: Long, val productId: Long, val productName: String, val brand: String, val category: String, val quantity: String, val unit: String, val unitPriceCents: Long, val discountCents: Long, val totalCents: Long, val estimatedTotalCents: Long, val substituted: Boolean)

@Entity(tableName = "shopping_history", indices = [Index("completedAt"), Index("storeId")])
data class HistoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val listName: String, val storeId: Long?, val storeName: String, val completedAt: Long, val totalCents: Long, val budgetCents: Long, val estimatedCents: Long, val sessionId: Long?)

@Entity(tableName = "history_items", foreignKeys = [ForeignKey(entity = HistoryEntity::class, parentColumns = ["id"], childColumns = ["historyId"], onDelete = ForeignKey.CASCADE)], indices = [Index("historyId")])
data class HistoryItemEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val historyId: Long, val productId: Long, val productName: String, val brand: String, val category: String, val quantity: String, val unit: String, val unitPriceCents: Long, val discountCents: Long, val totalCents: Long, val estimatedTotalCents: Long, val substituted: Boolean)

@Entity(tableName = "tax_records", foreignKeys = [ForeignKey(entity = HistoryEntity::class, parentColumns = ["id"], childColumns = ["historyId"], onDelete = ForeignKey.CASCADE)], indices = [Index("historyId")])
data class TaxEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val historyId: Long, val amountCents: Long, val documented: Boolean, val includedInPrice: Boolean, val source: String)

@Entity(tableName = "receipts", foreignKeys = [ForeignKey(entity = HistoryEntity::class, parentColumns = ["id"], childColumns = ["historyId"], onDelete = ForeignKey.CASCADE)], indices = [Index(value = ["historyId"], unique = true)])
data class ReceiptEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val historyId: Long, val uri: String, val createdAt: Long)

@Entity(tableName = "recommendation_decisions", indices = [Index("itemId"), Index("acceptedAt")])
data class DecisionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val itemId: Long, val oldProductId: Long, val newProductId: Long, val acceptedAt: Long, val savingsCents: Long)

@Entity(tableName = "product_alternatives", primaryKeys = ["productId", "alternativeId"], foreignKeys = [
    ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["alternativeId"], onDelete = ForeignKey.CASCADE)
], indices = [Index("alternativeId")])
data class ProductAlternativeEntity(val productId: Long, val alternativeId: Long, val reason: String)

@Entity(tableName = "recommendations", foreignKeys = [
    ForeignKey(entity = ItemEntity::class, parentColumns = ["id"], childColumns = ["itemId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["alternativeProductId"], onDelete = ForeignKey.CASCADE)
], indices = [Index("itemId"), Index("alternativeProductId")])
data class RecommendationEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val itemId: Long, val alternativeProductId: Long, val mode: String, val explanation: String, val createdAt: Long)

@Entity(tableName = "ai_settings")
data class AiSettingsEntity(@PrimaryKey val id: Int = 1, val mode: String, val onlineConsent: Boolean, val gatewayUrl: String)

@Entity(tableName = "user_preferences", indices = [Index(value = ["kind", "value"], unique = true)])
data class UserPreferenceEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val kind: String, val value: String, val count: Long, val updatedAt: Long)

@Entity(tableName = "search_history", indices = [Index(value = ["query"], unique = true)])
data class SearchEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val query: String, val searchedAt: Long)

@Entity(tableName = "undo_records")
data class UndoEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val itemId: Long, val previousItemJson: String?, val observationId: Long?, val decisionId: Long?, val createdAt: Long)
