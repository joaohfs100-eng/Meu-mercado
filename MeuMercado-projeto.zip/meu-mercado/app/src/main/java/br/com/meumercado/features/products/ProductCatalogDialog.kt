package br.com.meumercado.features.products

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*
import java.text.Normalizer

@Composable fun ProductCatalogDialog(state: MarketUiState, vm: MarketViewModel, onDismiss: () -> Unit, onSelect: (Product) -> Unit, onNew: () -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    var favorites by rememberSaveable { mutableStateOf(false) }
    var historyOnly by rememberSaveable { mutableStateOf(false) }
    var category by rememberSaveable { mutableStateOf("") }
    val prices = state.snapshot.prices
    val boughtProductIds = state.snapshot.history.flatMap { it.items }.map { it.productId }.toSet()
    val products = state.snapshot.products.filter { product ->
        (!historyOnly || product.id in boughtProductIds) && (!favorites || product.favorite) && (category.isBlank() || product.category == category) &&
            normalize(listOf(product.name, product.brand, product.category, product.barcode.orEmpty(), product.tags.joinToString(" "), product.essentialCharacteristics.joinToString(" "), product.notes).joinToString(" ")).contains(normalize(search))
    }.sortedWith(compareBy<Product> {
        when (state.settings.mode) {
            RecommendationMode.FAVORITE_BRANDS -> if (state.settings.favoriteBrands[it.category]?.contains(it.brand) == true) 0 else 1
            RecommendationMode.BEST_VALUE -> if (it.accepted || it.favorite) 0 else 1
            RecommendationMode.MAXIMUM_SAVINGS -> 0
        }
    }.thenBy { if (state.settings.mode == RecommendationMode.MAXIMUM_SAVINGS) prices.filter { p -> p.productId == it.id }.maxByOrNull { it.observedAt }?.let { price -> UnitNormalizer.pricePerStandardUnit(price.priceCents, it) } ?: java.math.BigDecimal("999999999999") else java.math.BigDecimal.ZERO }.thenBy { it.name })
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Pesquisar produtos") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(search, { search = it }, label = { Text("Nome, marca, etiqueta ou código") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
            ChoiceField("Categoria", category.ifBlank { "Todas" }, listOf("Todas" to "") + state.snapshot.products.map { it.category }.distinct().sorted().map { it to it }) { category = it }
            Row { Checkbox(favorites, { favorites = it }); Text("Somente favoritos", Modifier.padding(top = 12.dp)) }
            Row { Checkbox(historyOnly, { historyOnly = it }); Text("Produtos do histórico de compras", Modifier.padding(top = 12.dp)) }
            Text("Ordenação: ${state.settings.mode.portuguese()}", style = MaterialTheme.typography.bodySmall)
            if (search.isBlank() && state.snapshot.searchHistory.isNotEmpty()) Text("Buscas recentes: ${state.snapshot.searchHistory.take(4).joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(products, key = { it.id }) { product ->
                    OutlinedCard(onClick = { vm.rememberSearch(search.ifBlank { product.name }); onSelect(product) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(product.name, style = MaterialTheme.typography.titleSmall)
                            Text("${product.brand.ifBlank { "Sem marca" }} • ${product.category} • ${product.packageQuantity} ${product.packageUnit.label}", style = MaterialTheme.typography.bodySmall)
                            val latest = prices.filter { it.productId == product.id }.maxByOrNull { it.observedAt }
                            latest?.let { Text("${Money.format(it.priceCents)} • ${dateText(it.observedAt)}", style = MaterialTheme.typography.bodySmall); Text(it.source.portuguese(), style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
                if (products.isEmpty()) item { Text("Nenhum produto encontrado. Cadastre um produto ou escaneie uma embalagem.") }
            }
        }
    }, confirmButton = { TextButton(onNew) { Text("Novo produto") } }, dismissButton = { TextButton(onDismiss) { Text("Fechar") } })
}
private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
