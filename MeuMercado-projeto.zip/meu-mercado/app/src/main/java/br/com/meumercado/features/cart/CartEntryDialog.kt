package br.com.meumercado.features.cart

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*

@Composable fun CartEntryDialog(item: ShoppingListItem, product: Product, onDismiss: () -> Unit, onConfirm: (String, Long, Long) -> Unit) {
    var quantity by rememberSaveable(item.id) { mutableStateOf(item.quantity.replace('.', ',')) }
    var price by rememberSaveable(item.id) { mutableStateOf(moneyInput(item.actualPriceCents ?: item.estimatedPriceCents)) }
    var discount by rememberSaveable(item.id) { mutableStateOf(moneyInput(item.discountCents)) }
    var error by rememberSaveable(item.id) { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Colocar no carrinho") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("${product.name} • ${product.brand.ifBlank { "Sem marca" }}")
            Text("Confira o preço neste supermercado. O valor sugerido é uma referência da lista e pode ter mudado.", style = MaterialTheme.typography.bodySmall)
            if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            DecimalField(quantity, { quantity = it }, "Quantidade (${product.saleUnit.label})")
            DecimalField(price, { price = it }, "Preço encontrado por ${product.saleUnit.label} (R$)")
            DecimalField(discount, { discount = it }, "Desconto total do item (R$)")
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        try {
            val qty = Money.parseQuantity(quantity).toPlainString()
            val actual = Money.parseCents(price)
            val discounted = Money.parseCents(discount)
            require(discounted <= Money.subtotal(actual, qty)) { "O desconto não pode superar o subtotal." }
            onConfirm(qty, actual, discounted)
        } catch (failure: IllegalArgumentException) { error = failure.message ?: "Revise os valores informados." }
    }) { Text("Confirmar preço e adicionar") } }, dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
}
