package br.com.meumercado.data

import android.content.Context
import androidx.room.Room
import br.com.meumercado.database.MarketDatabase
import br.com.meumercado.domain.MarketRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun database(@ApplicationContext context: Context): MarketDatabase = Room.databaseBuilder(
        context, MarketDatabase::class.java, "meu_mercado.db"
    ).addMigrations(MarketDatabase.MIGRATION_1_2).build()

    @Provides @Singleton
    fun repository(implementation: RoomMarketRepository): MarketRepository = implementation
}
