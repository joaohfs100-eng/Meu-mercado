package br.com.meumercado.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface MarketDao {
    // All observable tables are named in this query, so edits with unchanged row counts also invalidate it.
    @Query("""SELECT (SELECT COUNT(*) FROM products) + (SELECT COUNT(*) FROM product_categories)
        + (SELECT COUNT(*) FROM brands) + (SELECT COUNT(*) FROM tags) + (SELECT COUNT(*) FROM product_tags)
        + (SELECT COUNT(*) FROM stores) + (SELECT COUNT(*) FROM shopping_lists)
        + (SELECT COUNT(*) FROM shopping_list_items) + (SELECT COUNT(*) FROM budget_settings)
        + (SELECT COUNT(*) FROM price_observations) + (SELECT COUNT(*) FROM shopping_history)
        + (SELECT COUNT(*) FROM history_items) + (SELECT COUNT(*) FROM tax_records)
        + (SELECT COUNT(*) FROM receipts) + (SELECT COUNT(*) FROM recommendation_decisions)
        + (SELECT COUNT(*) FROM search_history) AS revision""")
    fun observeChanges(): Flow<Long>

    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE") suspend fun products(): List<ProductEntity>
    @Query("SELECT * FROM product_categories") suspend fun categories(): List<CategoryEntity>
    @Query("SELECT * FROM brands") suspend fun brands(): List<BrandEntity>
    @Query("SELECT * FROM tags") suspend fun tags(): List<TagEntity>
    @Query("SELECT * FROM product_tags") suspend fun productTags(): List<ProductTagEntity>
    @Query("SELECT * FROM stores ORDER BY name COLLATE NOCASE") suspend fun stores(): List<StoreEntity>
    @Query("SELECT * FROM shopping_lists ORDER BY createdAt DESC") suspend fun lists(): List<ListEntity>
    @Query("SELECT * FROM shopping_list_items ORDER BY position, id") suspend fun items(): List<ItemEntity>
    @Query("SELECT * FROM budget_settings") suspend fun budgets(): List<BudgetEntity>
    @Query("SELECT * FROM price_observations ORDER BY observedAt DESC") suspend fun prices(): List<PriceEntity>
    @Query("SELECT * FROM shopping_history ORDER BY completedAt DESC") suspend fun history(): List<HistoryEntity>
    @Query("SELECT * FROM history_items ORDER BY id") suspend fun historyItems(): List<HistoryItemEntity>
    @Query("SELECT * FROM tax_records") suspend fun taxes(): List<TaxEntity>
    @Query("SELECT * FROM receipts") suspend fun receipts(): List<ReceiptEntity>
    @Query("SELECT * FROM recommendation_decisions ORDER BY acceptedAt DESC") suspend fun decisions(): List<DecisionEntity>
    @Query("SELECT * FROM search_history ORDER BY searchedAt DESC LIMIT 30") suspend fun searches(): List<SearchEntity>
    @Query("SELECT * FROM products WHERE id = :id") suspend fun product(id: Long): ProductEntity?
    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1") suspend fun productByBarcode(barcode: String): ProductEntity?
    @Query("SELECT * FROM product_categories WHERE name = :name COLLATE NOCASE LIMIT 1") suspend fun categoryByName(name: String): CategoryEntity?
    @Query("SELECT * FROM brands WHERE name = :name COLLATE NOCASE LIMIT 1") suspend fun brandByName(name: String): BrandEntity?
    @Query("SELECT * FROM tags WHERE name = :name COLLATE NOCASE LIMIT 1") suspend fun tagByName(name: String): TagEntity?
    @Query("SELECT * FROM stores WHERE id = :id") suspend fun store(id: Long): StoreEntity?
    @Query("SELECT * FROM shopping_lists WHERE id = :id") suspend fun list(id: Long): ListEntity?
    @Query("SELECT * FROM shopping_list_items WHERE id = :id") suspend fun item(id: Long): ItemEntity?
    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId ORDER BY position, id") suspend fun listItems(listId: Long): List<ItemEntity>
    @Query("SELECT * FROM budget_settings WHERE listId = :listId") suspend fun budget(listId: Long): BudgetEntity?
    @Query("SELECT * FROM shopping_history WHERE id = :id") suspend fun historyById(id: Long): HistoryEntity?
    @Query("SELECT * FROM receipts WHERE historyId = :historyId LIMIT 1") suspend fun receipt(historyId: Long): ReceiptEntity?
    @Query("SELECT * FROM shopping_sessions WHERE listId = :listId AND completedAt IS NULL ORDER BY id DESC LIMIT 1") suspend fun openSession(listId: Long): SessionEntity?
    @Query("SELECT * FROM undo_records ORDER BY id DESC LIMIT 1") suspend fun latestUndo(): UndoEntity?
    @Query("SELECT * FROM user_preferences WHERE kind = :kind AND value = :value LIMIT 1") suspend fun preference(kind: String, value: String): UserPreferenceEntity?
    @Query("SELECT * FROM search_history WHERE query = :query LIMIT 1") suspend fun search(query: String): SearchEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertCategory(entity: CategoryEntity): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertBrand(entity: BrandEntity): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertTag(entity: TagEntity): Long
    @Upsert suspend fun putProduct(entity: ProductEntity): Long
    @Upsert suspend fun putStore(entity: StoreEntity): Long
    @Upsert suspend fun putList(entity: ListEntity): Long
    @Upsert suspend fun putItem(entity: ItemEntity): Long
    @Upsert suspend fun putBudget(entity: BudgetEntity)
    @Upsert suspend fun putPrice(entity: PriceEntity): Long
    @Upsert suspend fun putSession(entity: SessionEntity): Long
    @Insert suspend fun insertSessionItem(entity: SessionItemEntity): Long
    @Insert suspend fun insertHistory(entity: HistoryEntity): Long
    @Insert suspend fun insertHistoryItem(entity: HistoryItemEntity): Long
    @Upsert suspend fun putTax(entity: TaxEntity): Long
    @Upsert suspend fun putReceipt(entity: ReceiptEntity): Long
    @Insert suspend fun insertDecision(entity: DecisionEntity): Long
    @Insert suspend fun insertUndo(entity: UndoEntity): Long
    @Upsert suspend fun putSearch(entity: SearchEntity): Long
    @Upsert suspend fun putPreference(entity: UserPreferenceEntity): Long
    @Upsert suspend fun putAiSettings(entity: AiSettingsEntity)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putProductTag(entity: ProductTagEntity)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putFavoriteBrand(entity: FavoriteBrandEntity)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putAlternative(entity: ProductAlternativeEntity)
    @Insert suspend fun insertRecommendation(entity: RecommendationEntity): Long

    @Query("DELETE FROM product_tags WHERE productId = :id") suspend fun clearProductTags(id: Long)
    @Query("DELETE FROM favorite_brands") suspend fun clearFavoriteBrands()
    @Query("DELETE FROM shopping_lists WHERE id = :id") suspend fun deleteList(id: Long)
    @Query("DELETE FROM stores WHERE id = :id") suspend fun deleteStore(id: Long)
    @Query("UPDATE shopping_history SET storeId = NULL WHERE storeId = :storeId") suspend fun detachHistoryStore(storeId: Long)
    @Query("DELETE FROM shopping_list_items WHERE id = :id") suspend fun deleteItem(id: Long)
    @Query("DELETE FROM price_observations WHERE id = :id") suspend fun deletePrice(id: Long)
    @Query("DELETE FROM recommendation_decisions WHERE id = :id") suspend fun deleteDecision(id: Long)
    @Query("DELETE FROM undo_records WHERE id = :id") suspend fun deleteUndo(id: Long)
    @Query("DELETE FROM undo_records") suspend fun clearUndo()
    @Query("DELETE FROM user_preferences") suspend fun clearPreferences()
    @Query("UPDATE products SET accepted = 0") suspend fun resetLearnedAcceptance()
    @Query("DELETE FROM search_history WHERE id NOT IN (SELECT id FROM search_history ORDER BY searchedAt DESC LIMIT 30)") suspend fun trimSearches()
}
