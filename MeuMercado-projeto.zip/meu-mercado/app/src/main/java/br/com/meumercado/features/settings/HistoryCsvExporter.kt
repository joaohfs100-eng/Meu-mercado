package br.com.meumercado.features.settings

import br.com.meumercado.domain.AppSnapshot
import java.math.BigDecimal
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** CSV em UTF-8 com BOM; todo texto é escapado e fórmulas de planilha são neutralizadas. */
internal object HistoryCsvExporter {
    fun export(snapshot: AppSnapshot): String = buildString {
        append('\uFEFF')
        append("compra;data;mercado;lista;produto;marca;categoria;quantidade;unidade;preco_unitario_rs;desconto_rs;subtotal_rs;total_compra_rs;orcamento_rs;tributos_documentados_rs;tributos_estimados_rs\n")
        val dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        snapshot.history.sortedByDescending { it.completedAt }.forEach { purchase ->
            val taxes = snapshot.taxes.filter { it.historyId == purchase.id }
            val date = Instant.ofEpochMilli(purchase.completedAt).atZone(ZoneId.systemDefault()).toLocalDate().format(dateFormat)
            purchase.items.forEach { item ->
                append(listOf(purchase.id.toString(), date, purchase.storeName, purchase.listName, item.productName,
                    item.brand, item.category, item.quantity, item.unit.label, money(item.unitPriceCents), money(item.discountCents), money(item.totalCents),
                    money(purchase.totalCents), money(purchase.budgetCents), money(taxes.filter { it.documented }.sumOf { it.amountCents }), money(taxes.filterNot { it.documented }.sumOf { it.amountCents })).joinToString(";", transform = ::cell))
                append('\n')
            }
        }
    }

    private fun money(cents: Long): String = BigDecimal(cents).movePointLeft(2).toPlainString()
    private fun cell(value: String): String {
        val safe = if (value.trimStart().firstOrNull() in setOf('=', '+', '-', '@', '\t', '\r')) "'$value" else value
        return "\"${safe.replace("\"", "\"\"")}\""
    }
}
