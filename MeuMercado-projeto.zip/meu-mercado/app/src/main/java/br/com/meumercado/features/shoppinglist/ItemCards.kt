package br.com.meumercado.features.shoppinglist

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RemoveShoppingCart
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*

@Composable fun ShoppingItemCard(item: ShoppingListItem, product: Product, onEdit: () -> Unit, onStatus: (ItemStatus) -> Unit, onFindCheaper: () -> Unit) {
    OutlinedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(product.name, style = MaterialTheme.typography.titleMedium)
                    Text("${product.brand.ifBlank { "Sem marca" }} • ${product.category}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onEdit) { Icon(Icons.Default.Edit, "Editar ${product.name}") }
            }
            val price = if (item.status == ItemStatus.IN_CART) item.actualPriceCents ?: item.estimatedPriceCents else item.estimatedPriceCents
            Text("${item.quantity.replace('.', ',')} ${product.saleUnit.label} × ${Money.format(price)} = ${Money.format(Money.subtotal(price, item.quantity, item.discountCents))}", style = MaterialTheme.typography.titleSmall)
            Text("${item.status.portuguese()} • ${if (item.status == ItemStatus.IN_CART && item.actualPriceCents != null) "preço encontrado" else "estimativa"}${if (item.priority == 0) " • essencial" else ""}", style = MaterialTheme.typography.labelMedium)
            if (item.discountCents > 0) Text("Desconto: ${Money.format(item.discountCents)}", style = MaterialTheme.typography.bodySmall)
            if (item.notes.isNotBlank()) Text(item.notes, style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (item.status == ItemStatus.IN_CART) {
                    OutlinedButton(onClick = { onStatus(ItemStatus.PENDING) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.RemoveShoppingCart, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Retirar") }
                } else if (item.status != ItemStatus.REMOVED) {
                    Button(onClick = { onStatus(ItemStatus.IN_CART) }, modifier = Modifier.weight(1f).testTag("cart_toggle_${item.id}")) { Icon(Icons.Default.ShoppingCart, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Carrinho") }
                }
                TextButton(onFindCheaper, Modifier.weight(1f)) { Text("Encontrar mais barato") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (item.status != ItemStatus.IN_CART) TextButton(onClick = { onStatus(if (item.status == ItemStatus.UNAVAILABLE) ItemStatus.PENDING else ItemStatus.UNAVAILABLE) }) { Text(if (item.status == ItemStatus.UNAVAILABLE) "Voltar a pendente" else "Indisponível") }
                if (item.status != ItemStatus.REMOVED) TextButton(onClick = { onStatus(ItemStatus.REMOVED) }) { Text("Remover") } else TextButton(onClick = { onStatus(ItemStatus.PENDING) }) { Text("Restaurar") }
            }
        }
    }
}
