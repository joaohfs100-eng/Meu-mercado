package br.com.meumercado.features.products

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*

@Composable fun ProductEditor(
    product: Product? = null, item: ShoppingListItem? = null, draft: OcrDraft? = null,
    canObservePrice: Boolean = false, initialObserved: Boolean = false,
    onDismiss: () -> Unit, onSave: (Product, String, Long, ShoppingListItem?, Boolean) -> Unit
) {
    val context = LocalContext.current
    var photoUri by rememberSaveable { mutableStateOf(product?.photoUri) }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photoUri = uri.toString()
        }
    }
    var name by rememberSaveable { mutableStateOf(product?.name ?: draft?.name ?: "") }
    var brand by rememberSaveable { mutableStateOf(product?.brand ?: "") }
    var category by rememberSaveable { mutableStateOf(product?.category ?: "Alimentação") }
    var tags by rememberSaveable { mutableStateOf(product?.tags?.joinToString(", ") ?: "") }
    var barcode by rememberSaveable { mutableStateOf(product?.barcode ?: draft?.barcode ?: "") }
    var quantity by rememberSaveable { mutableStateOf(item?.quantity?.replace('.', ',') ?: "1") }
    var estimate by rememberSaveable { mutableStateOf(moneyInput(item?.estimatedPriceCents ?: draft?.priceCents ?: 0)) }
    var actual by rememberSaveable { mutableStateOf(item?.actualPriceCents?.let(::moneyInput) ?: "") }
    var discount by rememberSaveable { mutableStateOf(moneyInput(item?.discountCents ?: 0)) }
    var saleUnit by rememberSaveable { mutableStateOf((product?.saleUnit ?: draft?.unit ?: MeasurementUnit.UNIT).name) }
    var packageQuantity by rememberSaveable { mutableStateOf(product?.packageQuantity ?: draft?.packageQuantity ?: "1") }
    var packageUnit by rememberSaveable { mutableStateOf((product?.packageUnit ?: draft?.packageUnit ?: MeasurementUnit.UNIT).name) }
    var equivalence by rememberSaveable { mutableStateOf(product?.equivalenceKey ?: "") }
    var essential by rememberSaveable { mutableStateOf(product?.essentialCharacteristics?.joinToString(", ") ?: "") }
    var restrictions by rememberSaveable { mutableStateOf(product?.restrictions?.joinToString(", ") ?: "") }
    var favorite by rememberSaveable { mutableStateOf(product?.favorite ?: false) }
    var protected by rememberSaveable { mutableStateOf(product?.neverSubstitute ?: false) }
    var accepted by rememberSaveable { mutableStateOf(product?.accepted ?: false) }
    var notes by rememberSaveable { mutableStateOf(listOfNotNull(item?.notes ?: product?.notes, draft?.promotion?.takeIf { it.isNotBlank() }?.let { "Promoção reconhecida: $it. Confira as condições." }).filter { it.isNotBlank() }.joinToString("\n")) }
    var recordObserved by rememberSaveable { mutableStateOf(initialObserved && canObservePrice) }
    var priority by rememberSaveable { mutableStateOf(item?.priority ?: 1) }
    var status by rememberSaveable { mutableStateOf((item?.status ?: ItemStatus.PENDING).name) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (item == null) "Adicionar produto" else "Editar produto e valores") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            draft?.warnings?.forEach { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            if (draft != null) Text("Confira nome, embalagem e preço antes de salvar.", style = MaterialTheme.typography.bodySmall)
            if (product != null && draft?.priceCents != null && (draft.packageQuantity != product.packageQuantity || draft.packageUnit != product.packageUnit || draft.unit != product.saleUnit)) {
                Text("A etiqueta informa ${draft.packageQuantity} ${draft.packageUnit.label}, venda por ${draft.unit.label}. O cadastro local possui outra medida. Revise os campos abaixo: valores padrão do OCR podem representar informação ausente.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedTextField(name, { name = it }, label = { Text("Nome do produto *") }, singleLine = true)
            OutlinedTextField(brand, { brand = it }, label = { Text("Marca") }, singleLine = true)
            OutlinedTextField(category, { category = it }, label = { Text("Categoria") }, singleLine = true)
            OutlinedTextField(tags, { tags = it }, label = { Text("Etiquetas separadas por vírgula") })
            OutlinedTextField(barcode, { barcode = it }, label = { Text("Código de barras (opcional)") }, singleLine = true)
            OutlinedButton(onClick = { pickPhoto.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (photoUri == null) "Selecionar foto (opcional)" else "Alterar foto do produto") }
            if (photoUri != null) TextButton(onClick = { photoUri = null }) { Text("Remover foto selecionada") }
            DecimalField(quantity, { quantity = it }, "Quantidade a comprar *")
            ChoiceField("Unidade de venda", MeasurementUnit.valueOf(saleUnit).label, MeasurementUnit.entries.map { it.label to it.name }) { saleUnit = it }
            DecimalField(estimate, { estimate = it }, "Preço estimado por unidade de venda (R$)")
            if (item == null && canObservePrice) Row {
                Checkbox(recordObserved, { recordObserved = it })
                Text("Confirmo que observei este preço no mercado da lista", Modifier.padding(top = 12.dp))
            }
            if (item == null && !canObservePrice) Text("Selecione o mercado da lista para registrar preços observados.", style = MaterialTheme.typography.bodySmall)
            if (item != null) {
                DecimalField(actual, { actual = it }, "Preço encontrado (R$), opcional")
                DecimalField(discount, { discount = it }, "Desconto total deste item (R$)")
                ChoiceField("Estado", ItemStatus.valueOf(status).portuguese(), ItemStatus.entries.map { it.portuguese() to it.name }) { status = it }
            }
            Text("Dados para comparar embalagens", style = MaterialTheme.typography.titleSmall)
            DecimalField(packageQuantity, { packageQuantity = it }, "Conteúdo da embalagem")
            ChoiceField("Unidade do conteúdo", MeasurementUnit.valueOf(packageUnit).label, MeasurementUnit.entries.map { it.label to it.name }) { packageUnit = it }
            OutlinedTextField(equivalence, { equivalence = it }, label = { Text("Grupo de equivalência (ex.: arroz branco)") })
            Text("Use o mesmo grupo apenas para produtos seguros e equivalentes.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(essential, { essential = it }, label = { Text("Características essenciais, separadas por vírgula") })
            OutlinedTextField(restrictions, { restrictions = it }, label = { Text("Restrições / dieta, separadas por vírgula") })
            Row { Checkbox(favorite, { favorite = it }); Text("Produto favorito", Modifier.padding(top = 12.dp)) }
            Row { Checkbox(protected, { protected = it }); Text("Não substituir este produto", Modifier.padding(top = 12.dp)) }
            Row { Checkbox(accepted, { accepted = it }); Text("Marca/produto já aceito por mim", Modifier.padding(top = 12.dp)) }
            ChoiceField("Prioridade", when (priority) { 0 -> "Essencial"; 2 -> "Baixa"; else -> "Normal" }, listOf("Essencial" to "0", "Normal" to "1", "Baixa" to "2")) { priority = it.toInt() }
            OutlinedTextField(notes, { notes = it }, label = { Text("Observações") })
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        try {
            require(name.isNotBlank()) { "Informe o nome do produto." }
            require(category.isNotBlank()) { "Informe uma categoria." }
            val qty = Money.parseQuantity(quantity).toPlainString()
            val pack = Money.parseQuantity(packageQuantity).toPlainString()
            val price = Money.parseCents(estimate)
            val real = actual.takeIf { it.isNotBlank() }?.let(Money::parseCents)
            val discountCents = Money.parseCents(discount)
            val selectedStatus = ItemStatus.valueOf(status)
            if (item != null && selectedStatus == ItemStatus.IN_CART) require(real != null) { "Informe e confirme o preço encontrado para colocar o item no carrinho." }
            val sale = MeasurementUnit.valueOf(saleUnit)
            val packUnit = MeasurementUnit.valueOf(packageUnit)
            val updated = (product ?: Product(name = name.trim())).copy(name = name.trim(), brand = brand.trim(), category = category.trim(), tags = splitSet(tags), photoUri = photoUri, barcode = barcode.trim().takeIf { it.isNotBlank() }, saleUnit = sale, packageQuantity = pack, packageUnit = packUnit,
                equivalenceKey = equivalence.trim(), essentialCharacteristics = splitSet(essential), restrictions = splitSet(restrictions), favorite = favorite, neverSubstitute = protected, accepted = accepted, notes = notes)
            val updatedItem = item?.copy(quantity = qty, estimatedPriceCents = price, actualPriceCents = real, discountCents = discountCents, status = selectedStatus, priority = priority, notes = notes)
            val linePrice = if (selectedStatus == ItemStatus.IN_CART) real ?: price else price
            require(discountCents <= Money.subtotal(linePrice, qty)) { "O desconto não pode superar o subtotal." }
            onSave(updated, qty, price, updatedItem, recordObserved && canObservePrice)
        } catch (e: Exception) { error = e.message ?: "Revise os dados do produto." }
    }) { Text("Salvar") } }, dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
}

private fun splitSet(text: String): Set<String> = text.split(',').map(String::trim).filter(String::isNotBlank).toSet()

@Composable fun ChoiceField(label: String, value: String, choices: List<Pair<String, String>>, onChoice: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(value) }
            DropdownMenu(expanded, onDismissRequest = { expanded = false }) {
                choices.forEach { (display, key) -> DropdownMenuItem(text = { Text(display) }, onClick = { expanded = false; onChoice(key) }) }
            }
        }
    }
}
