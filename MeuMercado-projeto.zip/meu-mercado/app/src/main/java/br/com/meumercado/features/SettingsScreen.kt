package br.com.meumercado.features

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import br.com.meumercado.domain.RecommendationMode
import br.com.meumercado.domain.ThemeChoice
import br.com.meumercado.data.online.GatewayConfiguration
import br.com.meumercado.features.settings.ShoppingReminderWorker
import br.com.meumercado.features.settings.SettingsFilesViewModel
import br.com.meumercado.ui.MarketUiState
import br.com.meumercado.ui.MarketViewModel
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(state: MarketUiState, vm: MarketViewModel) {
    val context = LocalContext.current
    val files: SettingsFilesViewModel = viewModel()
    val fileState by files.state.collectAsStateWithLifecycle()
    val resolver = context.applicationContext.contentResolver
    var status by rememberSaveable { mutableStateOf<String?>(null) }
    val busy = fileState.busy
    var favoriteCategory by rememberSaveable { mutableStateOf("") }
    var favoriteBrand by rememberSaveable { mutableStateOf("") }
    var gateway by rememberSaveable(state.settings.gatewayUrl) { mutableStateOf(state.settings.gatewayUrl) }
    var confirmAction by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingBackupUri by rememberSaveable { mutableStateOf<String?>(null) }
    var consentDialog by rememberSaveable { mutableStateOf(false) }
    var reminderHours by rememberSaveable { mutableStateOf("24") }
    var permissionAction by rememberSaveable { mutableStateOf("reminder") }

    fun scheduleReminder() {
        val hours = reminderHours.toLongOrNull()
        if (hours == null || hours !in 1..8760) { status = "Informe entre 1 e 8760 horas."; return }
        val work = OneTimeWorkRequestBuilder<ShoppingReminderWorker>().setInitialDelay(hours, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniqueWork(ShoppingReminderWorker.UNIQUE_NAME, ExistingWorkPolicy.REPLACE, work)
        status = "Lembrete agendado para daqui a $hours horas. O Android pode ajustar o horário para economizar bateria."
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (permissionAction == "budget") {
                vm.updateSettings { current -> current.copy(notificationsEnabled = true) }
                status = "Avisos de orçamento ativados."
            } else scheduleReminder()
        } else status = "Notificações não autorizadas. Você pode permitir nas configurações do Android."
    }
    val exportJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) { status = null; files.exportJson(resolver, uri, vm) }
    }
    val exportCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) { status = null; files.exportCsv(resolver, uri, state.snapshot) }
    }
    val importJson = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            // A URI é pequena e salva no estado; o JSON nunca vai para o Bundle da Activity.
            pendingBackupUri = uri.toString()
            runCatching { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                .onFailure { status = "O provedor não concedeu acesso persistente. Se necessário, selecione o arquivo novamente." }
            confirmAction = "restore"
        }
    }

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Configurações", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp)) }
        status?.let { message -> item { Text(message, style = MaterialTheme.typography.bodyMedium) } }
        fileState.message?.let { message -> item { Text(message, style = MaterialTheme.typography.bodyMedium) } }
        if (busy) item { Text("Processando arquivo…") }
        item {
            SectionCard("Inteligência Artificial") {
                Text("Como você prefere economizar?", style = MaterialTheme.typography.titleMedium)
                Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChoice("Máxima Economia", "Prioriza menor custo para a quantidade necessária e respeita características essenciais.", RecommendationMode.MAXIMUM_SAVINGS, state, vm)
                    ModeChoice("Melhor Custo-Benefício", "Equilibra custo por unidade, embalagens e preferências registradas. Sem notas de qualidade inventadas.", RecommendationMode.BEST_VALUE, state, vm)
                    ModeChoice("Minhas Marcas Favoritas", "Prioriza suas marcas por categoria. Outras marcas aparecem como alternativas opcionais.", RecommendationMode.FAVORITE_BRANDS, state, vm)
                }
                Text("A mudança atualiza buscas, recomendações e otimização com os dados locais. Toda substituição exige sua confirmação.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Marcas favoritas por categoria") {
                OutlinedTextField(favoriteCategory, { favoriteCategory = it }, label = { Text("Categoria") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (state.snapshot.products.isNotEmpty()) ChoiceChips(state.snapshot.products.map { it.category }.distinct(), favoriteCategory) { favoriteCategory = it }
                OutlinedTextField(favoriteBrand, { favoriteBrand = it }, label = { Text("Marca favorita") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val category = favoriteCategory.trim()
                    val brand = favoriteBrand.trim()
                    if (category.isBlank() || brand.isBlank()) status = "Informe a categoria e a marca."
                    else {
                        vm.updateSettings { current ->
                            val brands = current.favoriteBrands.toMutableMap()
                            val categoryKey = brands.keys.firstOrNull { it.equals(category, true) } ?: category
                            val existing = brands[categoryKey].orEmpty()
                            brands[categoryKey] = if (existing.any { it.equals(brand, true) }) existing else existing + brand
                            current.copy(favoriteBrands = brands)
                        }
                        favoriteBrand = ""
                        status = "Marca favorita salva."
                    }
                }) { Text("Adicionar marca") }
                state.settings.favoriteBrands.forEach { (category, brands) ->
                    Text(category, style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        brands.forEach { brand ->
                            InputChip(selected = true, onClick = {
                                vm.updateSettings { current ->
                                    val map = current.favoriteBrands.toMutableMap()
                                    val remaining = map[category].orEmpty() - brand
                                    if (remaining.isEmpty()) map.remove(category) else map[category] = remaining
                                    current.copy(favoriteBrands = map)
                                }
                            }, label = { Text("$brand · remover") })
                        }
                    }
                }
                Text("Em cada produto, ative “Não substituir” para proteger especificações ou preferências individuais.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Aparência") {
                ChoiceChips(listOf("Sistema", "Claro", "Escuro"), when (state.settings.theme) { ThemeChoice.SYSTEM -> "Sistema"; ThemeChoice.LIGHT -> "Claro"; ThemeChoice.DARK -> "Escuro" }) {
                    vm.updateSettings { current -> current.copy(theme = when (it) { "Claro" -> ThemeChoice.LIGHT; "Escuro" -> ThemeChoice.DARK; else -> ThemeChoice.SYSTEM }) }
                }
                Text("O tamanho da fonte acompanha a configuração de acessibilidade do Android.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("IA online opcional") {
                Text("Sem gateway configurado, o assistente e as recomendações continuam disponíveis localmente.")
                OutlinedTextField(gateway, { gateway = it }, label = { Text("Gateway HTTPS (opcional)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                OutlinedButton(onClick = {
                    val value = gateway.trim()
                    if (value.isNotEmpty() && GatewayConfiguration.endpoint(value, "chat") == null) status = "Use um gateway HTTPS válido, sem credenciais, parâmetros de consulta ou fragmentos no endereço."
                    else { vm.updateSettings { current -> current.copy(gatewayUrl = value, onlineConsent = if (value.isBlank()) false else current.onlineConsent) }; status = "Configuração do gateway salva. As credenciais do provedor ficam no servidor." }
                }) { Text("Salvar gateway") }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Switch(state.settings.onlineConsent, modifier = Modifier.semantics { contentDescription = "Autorizar processamento externo de perguntas" }, onCheckedChange = { enabled ->
                        if (enabled) consentDialog = true else vm.updateSettings { current -> current.copy(onlineConsent = false) }
                    })
                    Text("Autorizar processamento externo de perguntas", modifier = Modifier.padding(top = 8.dp))
                }
                Text("Nenhuma chave privada é incluída no aplicativo. O gateway escolhido responde pelos recursos online e por sua política de privacidade.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Preferências locais") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Switch(state.settings.learnedPreferencesEnabled, { vm.updateSettings { current -> current.copy(learnedPreferencesEnabled = it) } }, modifier = Modifier.semantics { contentDescription = "Usar preferências aprendidas no aparelho" })
                    Text("Usar preferências aprendidas no aparelho", modifier = Modifier.padding(top = 8.dp))
                }
                OutlinedButton(onClick = { confirmAction = "preferences" }) { Text("Redefinir preferências aprendidas") }
            }
        }
        item {
            SectionCard("Avisos de orçamento e lembretes") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Switch(state.settings.notificationsEnabled, { enabled ->
                        if (!enabled) vm.updateSettings { current -> current.copy(notificationsEnabled = false) }
                        else if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            permissionAction = "budget"
                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else vm.updateSettings { current -> current.copy(notificationsEnabled = true) }
                    })
                    Text("Receber avisos do orçamento", modifier = Modifier.padding(top = 8.dp))
                }
                Text("Notificações locais nas faixas definidas no orçamento. Textos e indicadores continuam disponíveis mesmo sem esta permissão.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(reminderHours, { reminderHours = it }, label = { Text("Lembrar de comprar daqui a (horas)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    if (reminderHours.toLongOrNull()?.let { it in 1L..8760L } != true) status = "Informe entre 1 e 8760 horas."
                    else if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        permissionAction = "reminder"
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else scheduleReminder()
                }) { Text("Agendar lembrete") }
                OutlinedButton(onClick = {
                    WorkManager.getInstance(context).cancelUniqueWork(ShoppingReminderWorker.UNIQUE_NAME)
                    status = "Lembrete cancelado. Os avisos do orçamento mantêm a configuração acima."
                }) { Text("Cancelar lembrete") }
            }
        }
        item {
            SectionCard("Meus dados") {
                Text("Armazenados no aparelho, sem cadastro obrigatório. Escolha onde guardar os arquivos pelo seletor do Android.")
                Button(enabled = !busy, onClick = { exportJson.launch("meu-mercado-backup.json") }) { Text("Exportar backup JSON") }
                OutlinedButton(enabled = !busy, onClick = { importJson.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }) { Text("Restaurar backup local") }
                OutlinedButton(enabled = !busy, onClick = { exportCsv.launch("meu-mercado-historico.csv") }) { Text("Exportar histórico CSV") }
                TextButton(enabled = !busy, onClick = { confirmAction = "erase" }) { Text("Excluir todos os meus dados", color = MaterialTheme.colorScheme.error) }
                Text("O aplicativo não vende nem compartilha seu histórico. Exportações feitas por você podem conter informações pessoais.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item { Text("Meu Mercado — Compras Inteligentes", modifier = Modifier.padding(bottom = 16.dp), style = MaterialTheme.typography.bodySmall) }
    }
    if (consentDialog) AlertDialog(onDismissRequest = { consentDialog = false }, title = { Text("Autorizar IA online?") }, text = {
        Text("Suas perguntas digitadas serão enviadas ao gateway HTTPS configurado. Evite incluir dados pessoais. O assistente local continua funcionando se você não autorizar. Você pode revogar esta opção a qualquer momento.")
    }, confirmButton = { TextButton(onClick = {
        if (GatewayConfiguration.endpoint(state.settings.gatewayUrl, "chat") != null) { vm.updateSettings { current -> current.copy(onlineConsent = true) }; consentDialog = false }
        else { status = "Salve primeiro um gateway HTTPS válido."; consentDialog = false }
    }) { Text("Autorizar") } }, dismissButton = { TextButton(onClick = { consentDialog = false }) { Text("Manter local") } })
    confirmAction?.let { action ->
        AlertDialog(onDismissRequest = { confirmAction = null; pendingBackupUri = null }, title = { Text(when (action) { "restore" -> "Restaurar backup?"; "preferences" -> "Redefinir preferências?"; else -> "Excluir todos os dados?" }) }, text = {
            Text(when (action) {
                "restore" -> "O arquivo será validado e substituirá os registros locais. Exporte um backup antes se quiser guardar os dados atuais. Um arquivo inválido não deve alterar seu banco."
                "preferences" -> "As preferências aprendidas serão redefinidas. Seu histórico de compras será preservado."
                else -> "Produtos, listas, mercados, compras e configurações serão apagados. Esta ação não pode ser desfeita. Exporte um backup antes para preservar uma cópia."
            })
        }, confirmButton = { TextButton(onClick = {
            confirmAction = null
            when (action) {
                "restore" -> {
                    val uri = pendingBackupUri
                    pendingBackupUri = null
                    if (uri != null) { status = null; files.restore(resolver, Uri.parse(uri), vm) }
                    else status = "Selecione novamente o arquivo de backup."
                }
                "preferences" -> { vm.clearLearnedPreferences(); status = "Redefinição solicitada." }
                else -> { WorkManager.getInstance(context).cancelUniqueWork(ShoppingReminderWorker.UNIQUE_NAME); vm.eraseAll(); status = "Exclusão solicitada." }
            }
        }) { Text("Confirmar", color = if (action == "erase") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) } }, dismissButton = { TextButton(onClick = { confirmAction = null; pendingBackupUri = null }) { Text("Cancelar") } })
    }
}

@Composable
private fun ModeChoice(title: String, description: String, mode: RecommendationMode, state: MarketUiState, vm: MarketViewModel) {
    Row(Modifier.fillMaxWidth().selectable(selected = state.settings.mode == mode, role = Role.RadioButton,
        onClick = { vm.updateSettings { current -> current.copy(mode = mode) } }), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        RadioButton(selected = state.settings.mode == mode, onClick = null)
        Column(Modifier.padding(top = 8.dp)) { Text(title, style = MaterialTheme.typography.titleSmall); Text(description, style = MaterialTheme.typography.bodySmall) }
    }
}

