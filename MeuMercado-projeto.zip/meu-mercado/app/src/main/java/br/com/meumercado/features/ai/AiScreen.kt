package br.com.meumercado.features.ai

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.data.online.OnlineAiGateway
import br.com.meumercado.data.online.OnlineAiResult
import br.com.meumercado.domain.*
import br.com.meumercado.features.products.ChoiceField
import br.com.meumercado.ui.*
import kotlinx.coroutines.launch

@Composable fun AiScreen(state: MarketUiState, vm: MarketViewModel, onSettings: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var messages by rememberSaveable { mutableStateOf(listOf<String>()) }
    var recommendationIds by rememberSaveable { mutableStateOf(listOf<Long>()) }
    var selectedId by rememberSaveable { mutableStateOf<Long?>(null) }
    var sending by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun send(online: Boolean) {
        if (query.isBlank() || sending) return
        val submitted = query.trim()
        query = ""
        messages = (messages + "Você: $submitted").takeLast(12)
        vm.rememberSearch(submitted)
        if (!online) {
            val reply = LocalAssistant().reply(submitted, state.snapshot, state.settings)
            messages = (messages + "Meu Mercado IA (local): ${reply.text}").takeLast(12)
            recommendationIds = reply.recommendations.map { it.item.id }
        } else {
            sending = true
            scope.launch {
                try {
                val result = OnlineAiGateway().ask(state.settings.gatewayUrl, submitted, state.settings.onlineConsent)
                val answer = when (result) {
                    is OnlineAiResult.Success -> "IA online (${result.source}): ${result.answer}\nResposta externa; confirme informações antes de tomar decisões."
                    is OnlineAiResult.Unavailable -> "IA online indisponível: ${result.reason}"
                    is OnlineAiResult.Error -> "IA online: ${result.reason}"
                }
                messages = (messages + answer).takeLast(12)
                } finally { sending = false }
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Meu Mercado IA", style = MaterialTheme.typography.headlineSmall)
        Text("Seu assistente de economia, com dados reais do aparelho.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        SectionCard("Como você prefere economizar?") {
            ChoiceField("Modo de recomendação", state.settings.mode.portuguese(), RecommendationMode.entries.map { it.portuguese() to it.name }) { vm.updateSettings { current -> current.copy(mode = RecommendationMode.valueOf(it)) } }
            TextButton(onSettings) { Text("Configurar marcas favoritas e IA online") }
            Text(if (state.settings.onlineConsent && state.settings.gatewayUrl.isNotBlank()) "IA online configurada. Apenas perguntas enviadas pelo botão online saem do aparelho." else "IA online não disponível/configurada. O assistente local funciona sem internet.", style = MaterialTheme.typography.bodySmall)
        }
        OptimizerPanel(state, vm)
        StoreComparisonPanel(state)
        SectionCard("Converse com o assistente") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Quanto ainda posso gastar?", "Quais produtos ainda faltam?", "Qual produto está mais caro?", "Quanto gastei no último mês?").forEach { prompt ->
                    SuggestionChip(onClick = { query = prompt }, label = { Text(prompt) })
                }
            }
            if (messages.isEmpty()) Text("Pergunte sobre saldo, produtos pendentes, alternativas ou gastos. Respostas locais citam os dados disponíveis.")
            messages.takeLast(30).forEach { message ->
                Surface(color = if (message.startsWith("Você:")) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.medium) {
                    Text(message, Modifier.fillMaxWidth().padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
            recommendationIds.forEach { id -> state.activeItems.firstOrNull { it.id == id }?.let { item ->
                TextButton(onClick = { selectedId = item.id }) { Text("Revisar alternativas: ${state.snapshot.products.firstOrNull { it.id == item.productId }?.name}") }
            } }
            if (sending) LinearProgressIndicator(Modifier.fillMaxWidth())
            OutlinedTextField(query, { query = it.take(4000) }, Modifier.fillMaxWidth(), label = { Text("Escreva sua pergunta") }, minLines = 2, maxLines = 5)
            Button(onClick = { send(false) }, enabled = query.isNotBlank() && !sending, modifier = Modifier.fillMaxWidth()) { Text("Perguntar ao assistente local") }
            OutlinedButton(onClick = { send(true) }, enabled = query.isNotBlank() && !sending, modifier = Modifier.fillMaxWidth()) { Text("Enviar pergunta à IA online") }
            Text("O chat não altera listas nem orçamentos. Toda troca exige sua confirmação.", style = MaterialTheme.typography.bodySmall)
            if (messages.isNotEmpty()) TextButton(onClick = { messages = emptyList(); recommendationIds = emptyList() }) { Text("Limpar conversa") }
        }
    }
    selectedId?.let { id -> state.activeItems.firstOrNull { it.id == id }?.let { AlternativesDialog(state, vm, it, onDismiss = { selectedId = null }) } }
}

@Composable private fun StoreComparisonPanel(state: MarketUiState) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    var sort by rememberSaveable { mutableStateOf("coverage") }
    val comparisons = remember(state.snapshot, state.activeList) { RecommendationEngine().compareStores(state.activeItems, state.snapshot.products, state.snapshot.prices, state.snapshot.stores) }
    SectionCard("Comparar supermercados") {
        OutlinedButton(onClick = { expanded = !expanded }, Modifier.fillMaxWidth()) { Text(if (expanded) "Ocultar comparação" else "Comparar minha lista entre mercados") }
        if (expanded) {
            ChoiceField("Ordenar", when (sort) { "price" -> "Total conhecido"; "distance" -> "Distância informada"; "favorite" -> "Preferência"; else -> "Cobertura de preços" }, listOf("Cobertura de preços" to "coverage", "Total conhecido" to "price", "Distância informada" to "distance", "Preferência" to "favorite")) { sort = it }
            val sorted = when (sort) {
                "price" -> comparisons.sortedBy { it.knownTotalCents }
                "distance" -> comparisons.sortedBy { it.store.distanceKm?.replace(',', '.')?.toBigDecimalOrNull() ?: java.math.BigDecimal("999999") }
                "favorite" -> comparisons.sortedByDescending { it.store.favorite }
                else -> comparisons.sortedByDescending { it.comparableCount }
            }
            if (sorted.isEmpty()) Text("Cadastre mercados e registre preços para comparar.")
            sorted.forEach { comparison ->
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(comparison.store.name, style = MaterialTheme.typography.titleSmall)
                        Text("Total conhecido: ${Money.format(comparison.knownTotalCents)}")
                        Text("${comparison.comparableCount} produtos comparáveis • ${comparison.missingCount} sem preço")
                        val total = comparison.comparableCount + comparison.missingCount
                        Text("Cobertura: ${if (total == 0) 0 else comparison.comparableCount * 100 / total}%", style = MaterialTheme.typography.bodySmall)
                        comparison.latestObservation?.let { Text("Último registro: ${dateText(it)}", style = MaterialTheme.typography.bodySmall) }
                        comparison.oldestObservation?.let { Text("Registro mais antigo: ${dateText(it)}", style = MaterialTheme.typography.bodySmall) }
                        if (comparison.missingCount > 0) Text("Comparação parcial; não permite declarar o menor total definitivo.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        else if (total > 0) Text("Todos os itens têm preço registrado; confirme valores e disponibilidade atuais.", style = MaterialTheme.typography.bodySmall)
                        comparison.store.distanceKm?.let { Text("Distância informada: $it km (custo de deslocamento não incluído)", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}
