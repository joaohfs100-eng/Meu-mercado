package br.com.meumercado.features.scanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import br.com.meumercado.domain.MeasurementUnit
import br.com.meumercado.domain.Money
import br.com.meumercado.domain.OcrDraft
import java.math.BigDecimal
import java.util.concurrent.Executors

@Composable
fun ScannerScreen(onConfirm: (OcrDraft) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var permissionGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var requested by rememberSaveable { mutableStateOf(false) }
    var mode by rememberSaveable { mutableStateOf(ScannerMode.BARCODE) }
    var error by remember { mutableStateOf<String?>(null) }
    var draft by rememberSaveable(stateSaver = OcrDraftSaver) { mutableStateOf<OcrDraft?>(null) }
    var fiscalUrl by rememberSaveable { mutableStateOf<String?>(null) }
    var manualFiscalEntry by rememberSaveable { mutableStateOf(false) }
    var manualFiscalUrl by rememberSaveable { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permissionGranted = it }
    val hasCamera = remember { context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY) }
    BackHandler(onBack = onBack)
    LaunchedEffect(Unit) {
        if (!permissionGranted && !requested && hasCamera) {
            requested = true
            permission.launch(Manifest.permission.CAMERA)
        }
    }
    val analyzer = remember(mode) {
        CameraScanner(mode, onDraft = { draft = it; error = null }, onFiscalUrl = { fiscalUrl = it; error = null }, onError = { error = it })
    }
    LaunchedEffect(draft, fiscalUrl, manualFiscalEntry) { analyzer.paused.set(draft != null || fiscalUrl != null || manualFiscalEntry) }
    DisposableEffect(analyzer) { onDispose { analyzer.close() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Scanner", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onBack) { Text("Voltar") }
        }
        Text("Leitura no aparelho. Revise todos os dados antes de salvar.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ScannerMode.entries.forEach { option ->
                FilterChip(selected = mode == option, onClick = { mode = option; error = null }, label = { Text(option.label) })
            }
        }
        if (permissionGranted && hasCamera) {
            CameraPreview(analyzer, onError = { error = it }, Modifier.fillMaxWidth().height(300.dp))
            Text(when (mode) {
                ScannerMode.BARCODE -> "Enquadre o código do produto, com boa iluminação."
                ScannerMode.LABEL -> "Enquadre somente a etiqueta de um produto. Preços e promoções ambíguos exigem preenchimento manual."
                ScannerMode.RECEIPT -> "Enquadre o QR Code da NFC-e. A consulta oficial pode exigir confirmação, autenticação ou CAPTCHA no navegador."
            }, style = MaterialTheme.typography.bodyMedium)
        } else {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (hasCamera) "A câmera precisa de sua permissão para escanear." else "Este aparelho não possui câmera disponível.")
                    Text(if (mode == ScannerMode.RECEIPT) "Você pode digitar a URL oficial da nota ou registrar os tributos manualmente no histórico." else "Você pode continuar pelo cadastro manual.")
                    if (hasCamera) Button(onClick = { permission.launch(Manifest.permission.CAMERA) }) { Text("Permitir câmera") }
                }
            }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        OutlinedButton(onClick = {
            analyzer.paused.set(true)
            if (mode == ScannerMode.RECEIPT) manualFiscalEntry = true
            else draft = OcrDraft(warnings = listOf("Dados preenchidos manualmente; confirme o produto e o preço."))
        }, modifier = Modifier.fillMaxWidth()) { Text(if (mode == ScannerMode.RECEIPT) "Digitar URL da consulta fiscal" else "Cadastrar manualmente") }
        if (mode == ScannerMode.RECEIPT) Text("A leitura do QR não garante acesso a dados fiscais estruturados. Se não houver valores confiáveis, registre os tributos manualmente no histórico.")
    }

    draft?.let { current ->
        DraftReviewDialog(current, onDismiss = { draft = null }, onConfirm = { value ->
            draft = null
            onConfirm(value)
        })
    }
    if (manualFiscalEntry) AlertDialog(
        onDismissRequest = { manualFiscalEntry = false },
        title = { Text("Consulta oficial da NFC-e") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Cole o endereço HTTPS de domínio .gov.br impresso ou consultado na nota. Tributos podem ser registrados manualmente no histórico.")
            OutlinedTextField(manualFiscalUrl, { manualFiscalUrl = it }, label = { Text("URL oficial") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { TextButton(onClick = {
            val approved = FiscalQrValidator.approvedUrl(manualFiscalUrl)
            if (approved == null) error = "Informe uma URL HTTPS válida de domínio oficial .gov.br."
            else { fiscalUrl = approved; manualFiscalEntry = false; error = null }
        }) { Text("Revisar consulta") } },
        dismissButton = { TextButton(onClick = { manualFiscalEntry = false; error = null }) { Text("Cancelar") } }
    )
    fiscalUrl?.let { url ->
        AlertDialog(
            onDismissRequest = { fiscalUrl = null },
            title = { Text("Abrir consulta fiscal oficial?") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("O navegador abrirá ${Uri.parse(url).host}. Nenhum valor será salvo automaticamente.")
                Text("Confira a nota no portal e registre apenas os tributos documentados. Impostos já incluídos não são somados novamente à compra.")
            } },
            confirmButton = { TextButton(onClick = {
                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                    .onFailure { error = "Não há aplicativo disponível para abrir a consulta. Registre os tributos manualmente." }
                fiscalUrl = null
            }) { Text("Abrir consulta") } },
            dismissButton = { TextButton(onClick = { fiscalUrl = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun CameraPreview(analyzer: CameraScanner, onError: (String) -> Unit, modifier: Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE } }
    AndroidView(factory = { previewView }, modifier = modifier)
    DisposableEffect(lifecycleOwner, analyzer) {
        val executor = Executors.newSingleThreadExecutor()
        val future = ProcessCameraProvider.getInstance(context)
        var disposed = false
        var boundProvider: ProcessCameraProvider? = null
        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
        analysis.setAnalyzer(executor, analyzer)
        future.addListener({
            if (!disposed) runCatching {
                val provider = future.get()
                boundProvider = provider
                val selector = if (provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                provider.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
            }.onFailure { onError("Não foi possível iniciar a câmera. Você pode cadastrar o produto manualmente.") }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            disposed = true
            analysis.clearAnalyzer()
            boundProvider?.unbind(preview, analysis)
            executor.shutdown()
        }
    }
}

@Composable
private fun DraftReviewDialog(initial: OcrDraft, onDismiss: () -> Unit, onConfirm: (OcrDraft) -> Unit) {
    var name by rememberSaveable(initial) { mutableStateOf(initial.name) }
    var price by rememberSaveable(initial) { mutableStateOf(initial.priceCents?.let { BigDecimal.valueOf(it, 2).toPlainString().replace('.', ',') } ?: "") }
    var barcode by rememberSaveable(initial) { mutableStateOf(initial.barcode.orEmpty()) }
    var quantity by rememberSaveable(initial) { mutableStateOf(initial.packageQuantity) }
    var unit by rememberSaveable(initial) { mutableStateOf(initial.unit) }
    var packageUnit by rememberSaveable(initial) { mutableStateOf(initial.packageUnit) }
    var promotion by rememberSaveable(initial) { mutableStateOf(initial.promotion) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Revise o produto e o preço") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            initial.warnings.forEach { Text("Aviso: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            OutlinedTextField(name, { name = it }, label = { Text("Nome do produto") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(price, { price = it }, label = { Text("Preço observado (R$)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            Text("Unidade do preço")
            UnitChoices(unit, onChange = { unit = it })
            OutlinedTextField(quantity, { quantity = it }, label = { Text("Conteúdo da embalagem") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            Text("Unidade da embalagem")
            UnitChoices(packageUnit, onChange = { packageUnit = it })
            OutlinedTextField(barcode, { barcode = it }, label = { Text("Código de barras (opcional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(promotion, { promotion = it }, label = { Text("Condições de promoção") }, modifier = Modifier.fillMaxWidth())
            if (initial.rawText.isNotBlank()) Text("Texto lido: ${initial.rawText.take(2000)}", style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { TextButton(onClick = {
            runCatching {
                require(name.isNotBlank() || barcode.isNotBlank()) { "Informe o nome ou o código do produto." }
                val cents = if (price.isBlank()) null else Money.parseCents(price)
                val normalizedQuantity = Money.parseQuantity(quantity).toPlainString()
                require(barcode.length <= 128 && barcode.none { it.isISOControl() }) { "O código de barras é inválido." }
                initial.copy(name = name.trim(), priceCents = cents, unit = unit, packageQuantity = normalizedQuantity, packageUnit = packageUnit,
                    barcode = barcode.trim().ifBlank { null }, promotion = promotion.trim())
            }.onSuccess(onConfirm).onFailure { error = it.message ?: "Confira os valores informados." }
        }) { Text("Confirmar dados") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Ler novamente") } }
    )
}

@Composable
private fun UnitChoices(selected: MeasurementUnit, onChange: (MeasurementUnit) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        MeasurementUnit.entries.forEach { value ->
            FilterChip(selected = value == selected, onClick = { onChange(value) }, label = { Text(value.label) })
        }
    }
}

private val OcrDraftSaver = listSaver<OcrDraft?, Any>(
    save = { value -> value?.let {
        listOf(it.name, it.priceCents ?: -1L, it.unit.name, it.packageQuantity, it.packageUnit.name,
            it.barcode.orEmpty(), it.promotion, it.rawText) + it.warnings
    } ?: emptyList() },
    restore = { value -> if (value.size < 8) null else OcrDraft(
        name = value[0] as String, priceCents = (value[1] as Long).takeIf { it >= 0 },
        unit = MeasurementUnit.valueOf(value[2] as String), packageQuantity = value[3] as String,
        packageUnit = MeasurementUnit.valueOf(value[4] as String), barcode = (value[5] as String).ifBlank { null },
        promotion = value[6] as String, rawText = value[7] as String, warnings = value.drop(8).map { it as String }
    ) }
)
