package br.com.meumercado.features.scanner

import android.os.SystemClock
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import br.com.meumercado.domain.BarcodeValidator
import br.com.meumercado.domain.LabelParser
import br.com.meumercado.domain.OcrDraft
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

/** ML Kit embarcado: leitura e reconhecimento funcionam sem baixar modelos. */
internal class CameraScanner(
    private val mode: ScannerMode,
    private val onDraft: (OcrDraft) -> Unit,
    private val onFiscalUrl: (String) -> Unit,
    private val onError: (String) -> Unit
) : ImageAnalysis.Analyzer, AutoCloseable {
    private val processing = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    val paused = AtomicBoolean(false)
    private var lastFrameAt = 0L
    private var lastRejectedCode: String? = null
    private val barcodeScanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder().setBarcodeFormats(
            Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A,
            Barcode.FORMAT_UPC_E, Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
            Barcode.FORMAT_ITF, Barcode.FORMAT_DATA_MATRIX, Barcode.FORMAT_QR_CODE
        ).build()
    )
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun analyze(frame: ImageProxy) {
        try {
            analyzeFrame(frame)
        } catch (_: Exception) {
            processing.set(false)
            frame.close()
            if (!closed.get()) onError("Não foi possível processar a imagem. Tente novamente ou cadastre manualmente.")
        }
    }

    @androidx.annotation.OptIn(markerClass = [ExperimentalGetImage::class])
    private fun analyzeFrame(frame: ImageProxy) {
        val now = SystemClock.elapsedRealtime()
        if (closed.get() || paused.get() || now - lastFrameAt < 650 || !processing.compareAndSet(false, true)) {
            frame.close()
            return
        }
        lastFrameAt = now
        val media = frame.image
        if (media == null) {
            processing.set(false)
            frame.close()
            return
        }
        val image = InputImage.fromMediaImage(media, frame.imageInfo.rotationDegrees)
        if (mode == ScannerMode.LABEL) {
            textRecognizer.process(image)
                .addOnSuccessListener { result ->
                    if (!closed.get() && !paused.get() && result.text.isNotBlank()) {
                        runCatching { LabelParser.parse(result.text) }
                            .onSuccess { draft ->
                                if (draft.priceCents != null || draft.name.isNotBlank()) {
                                    paused.set(true)
                                    onDraft(draft)
                                }
                            }.onFailure { onError("Texto reconhecido sem campos confiáveis. Revise a etiqueta ou preencha manualmente.") }
                    }
                }
                .addOnFailureListener { if (!closed.get()) onError("Não foi possível ler a etiqueta. Tente melhorar a iluminação ou preencha manualmente.") }
                .addOnCompleteListener { processing.set(false); frame.close() }
        } else {
            barcodeScanner.process(image)
                .addOnSuccessListener { codes ->
                    if (!closed.get() && !paused.get()) {
                        for (code in codes) {
                            val value = code.rawValue?.trim() ?: continue
                            if (mode == ScannerMode.RECEIPT) {
                                val url = FiscalQrValidator.approvedUrl(value)
                                if (url != null) {
                                    paused.set(true)
                                    onFiscalUrl(url)
                                    break
                                }
                                if (value != lastRejectedCode) {
                                    lastRejectedCode = value
                                    onError("O QR deve apontar para uma consulta HTTPS em domínio oficial .gov.br. Registre os tributos manualmente se a consulta não estiver disponível.")
                                }
                            } else if (BarcodeValidator.isValid(value) ||
                                (code.format == Barcode.FORMAT_UPC_E && value.length == 8 && value.all(Char::isDigit)) ||
                                (code.format in setOf(Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_ITF, Barcode.FORMAT_DATA_MATRIX) &&
                                    value.length in 1..128 && value.none { it.isISOControl() })) {
                                paused.set(true)
                                onDraft(OcrDraft(barcode = value, rawText = value, warnings = listOf("Confira o produto associado ao código e informe o preço observado.") +
                                    if (code.format == Barcode.FORMAT_UPC_E) listOf("Código UPC-E compacto reconhecido. Confirme a associação ao cadastro local.")
                                    else if (!BarcodeValidator.isValid(value)) listOf("Código de formato industrial reconhecido; não é um GTIN com dígito verificador.") else emptyList()))
                                break
                            } else if (value != lastRejectedCode) {
                                lastRejectedCode = value
                                onError("Código inválido ou não reconhecido. Tente novamente ou cadastre o produto manualmente.")
                            }
                        }
                    }
                }
                .addOnFailureListener { if (!closed.get()) onError("Não foi possível ler o código. Tente novamente ou use o cadastro manual.") }
                .addOnCompleteListener { processing.set(false); frame.close() }
        }
    }

    override fun close() {
        closed.set(true)
        barcodeScanner.close()
        textRecognizer.close()
    }
}
