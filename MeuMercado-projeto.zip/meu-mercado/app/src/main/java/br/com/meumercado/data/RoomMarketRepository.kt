package br.com.meumercado.data

import androidx.room.withTransaction
import br.com.meumercado.database.*
import br.com.meumercado.domain.*
import java.math.BigDecimal
import java.net.URI
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

/** All mutations are transactional. History has its own immutable product snapshots. */
@Singleton
class RoomMarketRepository @Inject constructor(
    private val database: MarketDatabase,
    private val settingsStore: SettingsStore
) : MarketRepository {
    private val dao get() = database.dao()
    override val settings: Flow<AISettings> = settingsStore.settings
    override val snapshot: Flow<AppSnapshot> = dao.observeChanges().map { database.withTransaction { readSnapshot() } }

    internal suspend fun readSnapshot(): AppSnapshot {
        val categories = dao.categories().associateBy { it.id }
        val brands = dao.brands().associateBy { it.id }
        val tags = dao.tags().associateBy { it.id }
        val productTags = dao.productTags().groupBy { it.productId }
        val products = dao.products().map { product ->
            Product(product.id, product.name, product.brandId?.let { brands[it]?.name }.orEmpty(),
                categories.getValue(product.categoryId).name,
                productTags[product.id].orEmpty().map { tags.getValue(it.tagId).name }.toSet(),
                product.barcode, product.photoUri, MeasurementUnit.valueOf(product.saleUnit),
                product.packageQuantity, MeasurementUnit.valueOf(product.packageUnit), product.equivalenceKey,
                JsonCodec.stringSet(product.characteristics), JsonCodec.stringSet(product.restrictions),
                product.favorite, product.neverSubstitute, product.accepted, product.notes)
        }
        val boughtItems = dao.historyItems().groupBy { it.historyId }
        val receipts = dao.receipts().associateBy { it.historyId }
        return AppSnapshot(products, dao.stores().map { it.model() }, dao.lists().map { it.model() },
            dao.items().map { it.model() }, dao.budgets().map { it.model() }, dao.prices().map { it.model() },
            dao.history().map { record -> ShoppingHistory(record.id, record.listName, record.storeId,
                record.storeName, record.completedAt, boughtItems[record.id].orEmpty().map { it.model() },
                record.totalCents, record.budgetCents, record.estimatedCents, receipts[record.id]?.uri) },
            dao.taxes().map { it.model() }, dao.decisions().map { it.model() }, dao.searches().map { it.query })
    }

    override suspend fun saveProduct(product: Product): Long = database.withTransaction {
        validateProduct(product)
        val barcode = product.barcode?.trim()?.takeIf { it.isNotEmpty() }
        val byBarcode = barcode?.let { dao.productByBarcode(it) }
        require(byBarcode == null || product.id == 0L || byBarcode.id == product.id) { "Código de barras já cadastrado em outro produto." }
        // Reusing a known identity must not clear dietary restrictions or protected preferences.
        if (product.id == 0L && byBarcode != null) return@withTransaction byBarcode.id
        val categoryId = category(product.category.ifBlank { "Outros" })
        val brandId = product.brand.trim().takeIf { it.isNotEmpty() }?.let { brand(it) }
        val matching = if (product.id == 0L && byBarcode == null) dao.products().firstOrNull {
            canonical(it.name) == canonical(product.name) && it.brandId == brandId && it.categoryId == categoryId &&
                it.saleUnit == product.saleUnit.name && it.packageUnit == product.packageUnit.name &&
                decimal(it.packageQuantity).compareTo(decimal(product.packageQuantity)) == 0 && it.barcode == barcode
        } else null
        if (product.id == 0L && matching != null) return@withTransaction matching.id
        val id = if (product.id > 0) {
            requireNotNull(dao.product(product.id)) { "Produto não encontrado." }; product.id
        } else byBarcode?.id ?: matching?.id ?: 0
        val entity = ProductEntity(id, product.name.trim(), brandId, categoryId, barcode, product.photoUri,
            product.saleUnit.name, normalizedQuantity(product.packageQuantity), product.packageUnit.name,
            product.equivalenceKey.trim(), JsonCodec.strings(product.essentialCharacteristics),
            JsonCodec.strings(product.restrictions), product.favorite, product.neverSubstitute, product.accepted, product.notes)
        val savedId = identity(dao.putProduct(entity), id)
        dao.clearProductTags(savedId)
        product.tags.map { it.trim() }.filter { it.isNotEmpty() }.forEach { name ->
            val tagId = dao.tagByName(name)?.id ?: dao.insertTag(TagEntity(name = name))
            dao.putProductTag(ProductTagEntity(savedId, tagId))
        }
        savedId
    }

    override suspend fun saveStore(store: Store): Long = database.withTransaction {
        require(store.id >= 0) { "Identificador de mercado inválido." }
        require(store.name.isNotBlank()) { "Informe o nome do mercado." }
        store.distanceKm?.takeIf { it.isNotBlank() }?.let { require(decimal(it).signum() >= 0) { "Distância inválida." } }
        if (store.id > 0) requireNotNull(dao.store(store.id)) { "Mercado não encontrado." }
        identity(dao.putStore(store.entity()), store.id)
    }

    override suspend fun deleteStore(id: Long) = database.withTransaction {
        requireNotNull(dao.store(id)) { "Mercado não encontrado." }
        // Preserve the written store name and purchase snapshots after removing its live registration.
        dao.detachHistoryStore(id)
        dao.deleteStore(id)
        dao.clearUndo()
    }

    override suspend fun saveList(list: ShoppingList): Long = database.withTransaction {
        require(list.id >= 0) { "Identificador de lista inválido." }
        require(list.name.isNotBlank()) { "Informe o nome da lista." }
        list.storeId?.let { requireNotNull(dao.store(it)) { "Mercado não encontrado." } }
        val previous = if (list.id > 0) requireNotNull(dao.list(list.id)) { "Lista não encontrada." } else null
        if (previous != null && previous.storeId != list.storeId) {
            require(dao.listItems(list.id).none { it.status == ItemStatus.IN_CART.name }) {
                "Finalize ou retire os itens do carrinho antes de trocar o mercado desta lista."
            }
            dao.openSession(list.id)?.let { dao.putSession(it.copy(completedAt = System.currentTimeMillis())) }
        }
        identity(dao.putList(list.entity()), list.id)
    }

    override suspend fun deleteList(id: Long) {
        val current = settings.first()
        try {
            database.withTransaction {
                requireNotNull(dao.list(id)) { "Lista não encontrada." }
                dao.deleteList(id)
                dao.clearUndo()
                if (current.activeListId == id) settingsStore.save(current.copy(activeListId = null))
            }
        } catch (error: Exception) { settingsStore.restoreAfterFailure(current, error); throw error }
    }

    override suspend fun duplicateList(id: Long): Long = database.withTransaction {
        val original = requireNotNull(dao.list(id)) { "Lista não encontrada." }
        val copyId = dao.putList(original.copy(id = 0, name = "${original.name} (cópia)", archived = false, createdAt = System.currentTimeMillis()))
        // A duplicated plan must also include products acquired in its last completed session.
        dao.listItems(id).forEach {
            dao.putItem(it.copy(id = 0, listId = copyId, actualPriceCents = null, discountCents = 0, status = ItemStatus.PENDING.name))
        }
        dao.budget(id)?.let { dao.putBudget(it.copy(listId = copyId)) }
        copyId
    }

    override suspend fun saveItem(item: ShoppingListItem): Long = database.withTransaction {
        validateItem(item)
        val list = requireNotNull(dao.list(item.listId)) { "Lista não encontrada." }
        requireNotNull(dao.product(item.productId)) { "Produto não encontrado." }
        val previous = if (item.id > 0) requireNotNull(dao.item(item.id)) { "Item não encontrado." } else null
        require(previous == null || previous.listId == item.listId) { "Não é possível mover um item entre listas." }
        val normalized = item.copy(quantity = normalizedQuantity(item.quantity))
        val id = identity(dao.putItem(normalized.entity()), item.id)
        var observationId: Long? = null
        if (normalized.status == ItemStatus.IN_CART) {
            ensureSession(list)
            val actualPrice = normalized.actualPriceCents
            if (actualPrice != null && list.storeId != null &&
                (previous == null || previous.status != ItemStatus.IN_CART.name || previous.productId != item.productId || previous.actualPriceCents != item.actualPriceCents)) {
                observationId = dao.putPrice(PriceObservation(productId = item.productId, storeId = list.storeId,
                    priceCents = actualPrice, promotion = if (item.discountCents > 0) "Há desconto específico no item; consulte condições da compra." else "").entity())
            }
        }
        dao.insertUndo(UndoEntity(itemId = id, previousItemJson = previous?.model()?.let { JsonCodec.item(it).toString() },
            observationId = observationId, decisionId = null, createdAt = System.currentTimeMillis()))
        id
    }

    override suspend fun deleteItem(id: Long) = database.withTransaction {
        val previous = requireNotNull(dao.item(id)) { "Item não encontrado." }
        dao.insertUndo(UndoEntity(itemId = id, previousItemJson = JsonCodec.item(previous.model()).toString(),
            observationId = null, decisionId = null, createdAt = System.currentTimeMillis()))
        dao.deleteItem(id)
    }

    override suspend fun saveBudget(budget: BudgetSettings) = database.withTransaction {
        requireNotNull(dao.list(budget.listId)) { "Lista não encontrada." }
        validateBudget(budget)
        dao.putBudget(budget.entity())
    }

    override suspend fun saveSettings(settings: AISettings) {
        validateSettings(settings)
        val previous = this.settings.first()
        try {
            database.withTransaction {
                settings.activeListId?.let { requireNotNull(dao.list(it)) { "Lista ativa não encontrada." } }
                dao.clearFavoriteBrands()
                settings.favoriteBrands.forEach { (categoryName, brands) ->
                    val categoryId = category(categoryName)
                    brands.forEach { dao.putFavoriteBrand(FavoriteBrandEntity(categoryId, brand(it))) }
                }
                dao.putAiSettings(AiSettingsEntity(mode = settings.mode.name, onlineConsent = settings.onlineConsent, gatewayUrl = settings.gatewayUrl))
                settingsStore.save(settings)
            }
        } catch (error: Exception) { settingsStore.restoreAfterFailure(previous, error); throw error }
    }

    override suspend fun observePrice(price: PriceObservation) = database.withTransaction {
        validatePrice(price)
        requireNotNull(dao.product(price.productId)) { "Produto não encontrado." }
        requireNotNull(dao.store(price.storeId)) { "Mercado não encontrado." }
        dao.putPrice(price.entity())
        Unit
    }

    override suspend fun substitute(itemId: Long, alternative: Alternative) = database.withTransaction {
        val current = requireNotNull(dao.item(itemId)) { "Item não encontrado." }
        val sourceProduct = requireNotNull(dao.product(current.productId)) { "Produto original não encontrado." }
        val replacement = requireNotNull(dao.product(alternative.product.id)) { "Alternativa não cadastrada." }
        require(!sourceProduct.neverSubstitute) { "Este produto está protegido contra substituições." }
        val currentModel = readSnapshot().products.first { it.id == current.productId }
        val replacementModel = readSnapshot().products.first { it.id == replacement.id }
        require(RecommendationEngine().isSafeEquivalent(currentModel, replacementModel)) {
            "A alternativa não atende às características e restrições essenciais."
        }
        val neededQuantity = UnitNormalizer.requiredQuantity(currentModel, current.quantity, replacementModel)
        require(Money.parseQuantity(alternative.quantity).compareTo(Money.parseQuantity(neededQuantity)) == 0) {
            "A quantidade da alternativa não atende à quantidade necessária."
        }
        validatePrice(alternative.observation)
        require(alternative.observation.productId == replacement.id) { "O preço pertence a outro produto." }
        requireNotNull(dao.store(alternative.observation.storeId)) { "Mercado do preço não encontrado." }
        val list = requireNotNull(dao.list(current.listId)) { "Lista não encontrada." }
        val anotherStore = alternative.observation.storeId != list.storeId
        require(current.status != ItemStatus.IN_CART.name || !anotherStore) {
            "Um preço de outro mercado não pode ser registrado como preço pago no mercado desta compra. Retire o item e confirme um preço encontrado no mercado atual."
        }
        val notes = if (anotherStore) {
            val storeName = dao.store(alternative.observation.storeId)?.name.orEmpty()
            val observedAt = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(alternative.observation.observedAt))
            listOf(current.notes, "Estimativa de outro mercado: $storeName, registro de $observedAt, fonte ${alternative.observation.sourceName}. Confirme preço e disponibilidade no mercado atual antes de comprar.").filter(String::isNotBlank).joinToString("\n")
        } else current.notes
        val updated = current.model().copy(productId = replacement.id, quantity = alternative.quantity,
            estimatedPriceCents = alternative.observation.priceCents,
            actualPriceCents = if (current.status == ItemStatus.IN_CART.name) alternative.observation.priceCents else null,
            discountCents = 0, notes = notes)
        validateItem(updated)
        val expectedTotal = Money.subtotal(alternative.observation.priceCents, alternative.quantity)
        require(alternative.totalCents == expectedTotal) { "Valor da alternativa inconsistente." }
        val oldTotal = Money.subtotal(if (current.status == ItemStatus.IN_CART.name) current.actualPriceCents ?: current.estimatedPriceCents else current.estimatedPriceCents, current.quantity,
            current.discountCents)
        val decisionId = dao.insertDecision(DecisionEntity(itemId = itemId, oldProductId = current.productId,
            newProductId = replacement.id, acceptedAt = System.currentTimeMillis(), savingsCents = oldTotal - expectedTotal))
        dao.putAlternative(ProductAlternativeEntity(current.productId, replacement.id, alternative.reason))
        dao.insertRecommendation(RecommendationEntity(itemId = itemId, alternativeProductId = replacement.id,
            mode = settings.first().mode.name, explanation = alternative.reason, createdAt = System.currentTimeMillis()))
        dao.putItem(updated.entity())
        dao.insertUndo(UndoEntity(itemId = itemId, previousItemJson = JsonCodec.item(current.model()).toString(),
            observationId = null, decisionId = decisionId, createdAt = System.currentTimeMillis()))
        Unit
    }

    override suspend fun undo(): Boolean = database.withTransaction {
        val operation = dao.latestUndo() ?: return@withTransaction false
        if (operation.previousItemJson == null) dao.deleteItem(operation.itemId)
        else {
            val item = JsonCodec.item(JSONObject(operation.previousItemJson))
            requireNotNull(dao.list(item.listId)) { "A lista dessa alteração não existe mais." }
            dao.putItem(item.entity())
        }
        operation.observationId?.let { dao.deletePrice(it) }
        operation.decisionId?.let { dao.deleteDecision(it) }
        dao.deleteUndo(operation.id)
        true
    }

    override suspend fun finishPurchase(listId: Long): Long = database.withTransaction {
        val list = requireNotNull(dao.list(listId)) { "Lista não encontrada." }
        val cart = dao.listItems(listId).filter { it.status == ItemStatus.IN_CART.name }
        require(cart.isNotEmpty()) { "Coloque ao menos um produto no carrinho para finalizar." }
        cart.forEach { validateItem(it.model()) }
        val products = readSnapshot().products.associateBy { it.id }
        val decisions = dao.decisions().groupBy { it.itemId }
        val completedAt = System.currentTimeMillis()
        val bought = cart.map { item ->
            val product = products.getValue(item.productId)
            val price = item.actualPriceCents ?: item.estimatedPriceCents
            HistoryItem(product.name, product.brand, product.category, product.id, item.quantity, product.saleUnit,
                price, item.discountCents, Money.subtotal(price, item.quantity, item.discountCents),
                Money.subtotal(item.estimatedPriceCents, item.quantity), decisions[item.id]?.isNotEmpty() == true)
        }
        val session = ensureSession(list)
        val store = list.storeId?.let { dao.store(it) }
        val total = bought.fold(0L) { sum, item -> Math.addExact(sum, item.totalCents) }
        val estimate = bought.fold(0L) { sum, item -> Math.addExact(sum, item.estimatedTotalCents) }
        val historyId = dao.insertHistory(HistoryEntity(listName = list.name, storeId = list.storeId,
            storeName = store?.name ?: "Mercado não informado", completedAt = completedAt, totalCents = total,
            budgetCents = dao.budget(listId)?.totalCents ?: 0, estimatedCents = estimate, sessionId = session.id))
        bought.forEach { dao.insertHistoryItem(it.entity(historyId)); dao.insertSessionItem(it.sessionEntity(session.id)) }
        dao.putSession(session.copy(completedAt = completedAt))
        cart.forEach { dao.putItem(it.copy(status = ItemStatus.REMOVED.name)) }
        if (settings.first().learnedPreferencesEnabled) {
            bought.forEach { item ->
                dao.product(item.productId)?.let { dao.putProduct(it.copy(accepted = true)) }
                learn("product", item.productId.toString())
                if (item.brand.isNotBlank()) learn("brand:${item.category}", item.brand)
                learn("quantity:${item.productId}", item.quantity)
            }
        }
        // A completed purchase is immutable; undo only operates within open shopping sessions.
        dao.clearUndo()
        historyId
    }

    override suspend fun saveTax(tax: TaxRecord) = database.withTransaction {
        require(tax.id >= 0) { "Identificador de tributo inválido." }
        require(tax.amountCents >= 0) { "O valor dos tributos não pode ser negativo." }
        require(tax.source.isNotBlank()) { "Informe a fonte dos tributos." }
        requireNotNull(dao.historyById(tax.historyId)) { "Compra não encontrada." }
        if (tax.id > 0) require(dao.taxes().any { it.id == tax.id && it.historyId == tax.historyId }) { "Tributo não encontrado nesta compra." }
        // Informational record only: taxes already included never change the frozen purchase total.
        dao.putTax(tax.entity())
        Unit
    }

    override suspend fun saveReceipt(historyId: Long, uri: String) = database.withTransaction {
        requireNotNull(dao.historyById(historyId)) { "Compra não encontrada." }
        validateReceiptUri(uri)
        val previous = dao.receipt(historyId)
        dao.putReceipt(ReceiptEntity(previous?.id ?: 0, historyId, uri, System.currentTimeMillis()))
        Unit
    }

    override suspend fun rememberSearch(query: String) = database.withTransaction {
        val value = query.trim().take(200)
        if (value.isNotBlank()) {
            val previous = dao.search(value)
            dao.putSearch(SearchEntity(previous?.id ?: 0, value, System.currentTimeMillis()))
            dao.trimSearches()
        }
    }

    override suspend fun clearLearnedPreferences() = database.withTransaction {
        dao.clearPreferences(); dao.resetLearnedAcceptance()
    }

    override suspend fun exportBackup(): String = DatabaseBackup(database, settingsStore, this).export()
    override suspend fun restoreBackup(json: String) = DatabaseBackup(database, settingsStore, this).restore(json)
    override suspend fun eraseAll() {
        val previous = settings.first()
        try {
            database.withTransaction {
                DatabaseBackup.clearTables(database)
                settingsStore.save(AISettings())
            }
        } catch (error: Exception) { settingsStore.restoreAfterFailure(previous, error); throw error }
    }

    private suspend fun category(name: String): Long = dao.categoryByName(name.trim())?.id ?: dao.insertCategory(CategoryEntity(name = name.trim()))
    private suspend fun brand(name: String): Long = dao.brandByName(name.trim())?.id ?: dao.insertBrand(BrandEntity(name = name.trim()))
    private suspend fun ensureSession(list: ListEntity): SessionEntity {
        dao.openSession(list.id)?.let { return it }
        val session = SessionEntity(listId = list.id, storeId = list.storeId, startedAt = System.currentTimeMillis())
        return session.copy(id = dao.putSession(session))
    }
    private suspend fun learn(kind: String, value: String) {
        val previous = dao.preference(kind, value)
        dao.putPreference(UserPreferenceEntity(previous?.id ?: 0, kind, value, Math.addExact(previous?.count ?: 0, 1), System.currentTimeMillis()))
    }
    private fun identity(result: Long, id: Long) = if (id > 0) id else result.also { check(it > 0) }
    private fun canonical(value: String) = value.trim().lowercase(Locale.ROOT)

    internal companion object {
        fun decimal(value: String): BigDecimal {
            val raw = value.trim()
            require(raw.isNotEmpty() && raw.length <= 60) { "Número inválido." }
            val normalized = if (',' in raw) {
                require(Regex("[+]?\\d{1,3}(?:\\.\\d{3})*,\\d+|[+]?\\d+,\\d+").matches(raw)) { "Número inválido." }
                raw.replace(".", "").replace(',', '.')
            } else {
                require(Regex("[+]?\\d+(?:\\.\\d+)?").matches(raw)) { "Número inválido." }
                raw
            }
            return try { BigDecimal(normalized) }
                catch (_: NumberFormatException) { throw IllegalArgumentException("Número inválido.") }
        }
        fun normalizedQuantity(value: String) = Money.parseQuantity(value).stripTrailingZeros().toPlainString()
        fun validateProduct(product: Product) {
            require(product.id >= 0) { "Identificador de produto inválido." }
            require(product.name.isNotBlank() && product.name.length <= 300) { "Informe um nome de produto válido." }
            Money.parseQuantity(product.packageQuantity)
            require(product.tags.none { it.length > 100 }) { "Etiqueta muito longa." }
            product.barcode?.takeIf { it.isNotBlank() }?.let { require(it.length <= 128 && it.none(Char::isWhitespace)) { "Código de barras inválido." } }
        }
        fun validateItem(item: ShoppingListItem) {
            require(item.id >= 0 && item.listId > 0 && item.productId > 0) { "Identificadores do item inválidos." }
            Money.parseQuantity(item.quantity)
            val actualPrice = item.actualPriceCents
            require(item.estimatedPriceCents >= 0 && (actualPrice == null || actualPrice >= 0) && item.discountCents >= 0) { "Preços e descontos devem ser positivos." }
            require(item.status != ItemStatus.IN_CART || actualPrice != null) { "Confirme o preço encontrado antes de colocar o produto no carrinho." }
            require(item.priority in 0..3) { "Prioridade inválida." }
            val base = if (item.status == ItemStatus.IN_CART) item.actualPriceCents ?: item.estimatedPriceCents else item.estimatedPriceCents
            require(item.discountCents <= Money.subtotal(base, item.quantity)) { "O desconto não pode superar o subtotal." }
            Money.subtotal(base, item.quantity, item.discountCents)
        }
        fun validateBudget(value: BudgetSettings) {
            require(value.listId > 0) { "Identificador de orçamento inválido." }
            val maximum = value.maximumCents
            require(value.totalCents >= 0 && value.safetyCents >= 0 && (maximum == null || maximum >= 0)) { "Orçamento e margem não podem ser negativos." }
            val percent = decimal(value.safetyPercent)
            require(percent >= BigDecimal.ZERO && percent <= BigDecimal(100)) { "A margem percentual deve ficar entre 0 e 100." }
            require(value.alertThresholds.all { it in 1..100 }) { "Percentual de alerta inválido." }
        }
        fun validateSettings(value: AISettings) {
            val activeList = value.activeListId
            require(activeList == null || activeList > 0) { "Identificador de lista ativa inválido." }
            require(value.favoriteBrands.all { (category, brands) -> category.isNotBlank() && brands.none { it.isBlank() } }) { "Marca ou categoria favorita inválida." }
            if (value.gatewayUrl.isNotBlank()) {
                val uri = try { URI(value.gatewayUrl) } catch (_: Exception) { throw IllegalArgumentException("Endereço do gateway inválido.") }
                require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && uri.fragment == null) { "O gateway deve utilizar HTTPS, sem credenciais no endereço." }
            }
        }
        fun validatePrice(value: PriceObservation) {
            require(value.id >= 0 && value.productId > 0 && value.storeId > 0) { "Identificadores de preço inválidos." }
            val validUntil = value.validUntil
            require(value.priceCents >= 0 && value.observedAt > 0 && (validUntil == null || validUntil >= value.observedAt)) { "Dados de preço inválidos." }
            require(value.sourceName.isNotBlank()) { "Informe a fonte do preço." }
        }
        fun validateReceiptUri(value: String) {
            require(value.length in 1..4096) { "Documento fiscal inválido." }
            val uri = try { URI(value) } catch (_: Exception) { throw IllegalArgumentException("Documento fiscal inválido.") }
            require(uri.userInfo == null && ((uri.scheme == "content" && !uri.authority.isNullOrBlank()) ||
                (uri.scheme == "https" && !uri.host.isNullOrBlank()))) { "Use um documento selecionado ou endereço HTTPS." }
        }
    }
}
