package br.com.meumercado.features.scanner

import java.net.URI

enum class ScannerMode(val label: String) {
    BARCODE("Código"), LABEL("Etiqueta"), RECEIPT("QR fiscal")
}

/** A consulta é feita no navegador, nunca por coleta oculta do portal fiscal. */
object FiscalQrValidator {
    fun approvedUrl(value: String): String? = runCatching {
        val uri = URI(value.trim())
        val host = uri.host?.lowercase() ?: return@runCatching null
        if (uri.scheme?.lowercase() != "https" || uri.userInfo != null || uri.port !in listOf(-1, 443)) return@runCatching null
        if (!(host == "gov.br" || host.endsWith(".gov.br"))) return@runCatching null
        if (value.length > 4096 || value.any { it.isISOControl() }) return@runCatching null
        uri.toASCIIString()
    }.getOrNull()
}
