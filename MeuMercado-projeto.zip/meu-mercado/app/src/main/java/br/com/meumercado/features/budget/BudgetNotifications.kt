package br.com.meumercado.features.budget

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import br.com.meumercado.domain.BudgetSummary
import br.com.meumercado.domain.Money
import br.com.meumercado.ui.MarketUiState
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first

private val Context.budgetAlertState by preferencesDataStore(name = "meu_mercado_budget_alerts")

/** Só publica após opt-in nas configurações e permissão do Android; nunca solicita permissão aqui. */
@Composable fun BudgetNotificationEffect(state: MarketUiState) {
    val context = LocalContext.current.applicationContext
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var resumed by remember { mutableIntStateOf(0) }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) resumed++ }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    val list = state.activeList
    val summary = state.summary
    LaunchedEffect(state.loading, state.settings.notificationsEnabled, list?.id, summary.alert, summary.operationalLimitCents, resumed) {
        if (state.loading) return@LaunchedEffect
        try {
        if (!state.settings.notificationsEnabled) {
            BudgetNotifier.clear(context)
            return@LaunchedEffect
        }
        if (list == null) return@LaunchedEffect
        val key = stringPreferencesKey("list_${list.id}")
        if (summary.alert == null) {
            context.budgetAlertState.edit { it.remove(key) }
            BudgetNotifier.cancel(context, list.id)
            return@LaunchedEffect
        }
        val signature = "${summary.alert}:${summary.operationalLimitCents}"
        if (context.budgetAlertState.data.first()[key] != signature && BudgetNotifier.post(context, list.id, list.name, summary)) {
            context.budgetAlertState.edit { it[key] = signature }
        }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: IOException) {
            // Uma falha do armazenamento dos avisos não afeta os alertas visuais nem os dados da compra.
        }
    }
}

private object BudgetNotifier {
    private const val CHANNEL = "budget_alerts"
    private fun notificationId(listId: Long): Int = 2_000 + (listId % 100_000).toInt()

    fun post(context: Context, listId: Long, listName: String, summary: BudgetSummary): Boolean {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Avisos de orçamento", NotificationManager.IMPORTANCE_DEFAULT))
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val title = if (summary.remainingCents < 0) "⚠ Limite da compra ultrapassado" else "⚠ ${summary.alert}% do limite utilizado"
        val text = "$listName • Carrinho: ${Money.format(summary.cartCents)} • Saldo: ${Money.format(summary.remainingCents)}"
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
        if (launch != null) notification.setContentIntent(PendingIntent.getActivity(context, notificationId(listId), launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        return try { manager.notify(notificationId(listId), notification.build()); true } catch (_: SecurityException) { false }
    }

    fun cancel(context: Context, listId: Long) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.cancel(notificationId(listId))
    }
    suspend fun clear(context: Context) {
        context.budgetAlertState.edit { it.clear() }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.activeNotifications.filter { it.notification.channelId == CHANNEL }.forEach { manager.cancel(it.id) }
    }
}
