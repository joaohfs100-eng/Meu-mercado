package br.com.meumercado.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.Money
import br.com.meumercado.domain.PriceSource
import br.com.meumercado.domain.RecommendationEngine
import br.com.meumercado.domain.Store
import br.com.meumercado.domain.StoreComparison
import br.com.meumercado.ui.MarketUiState
import br.com.meumercado.ui.MarketViewModel
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun StoresScreen(state: MarketUiState, vm: MarketViewModel) {
    var editId by rememberSaveable { mutableStateOf<Long?>(null) }
    var adding by rememberSaveable { mutableStateOf(false) }
    var deleteId by rememberSaveable { mutableStateOf<Long?>(null) }
    var pricesId by rememberSaveable { mutableStateOf<Long?>(null) }
    var compare by rememberSaveable { mutableStateOf(false) }
    var status by rememberSaveable { mutableStateOf<String?>(null) }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Meus mercados", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp)) }
        item { Button(onClick = { adding = true }) { Text("Cadastrar supermercado") } }
        item { OutlinedButton(onClick = { compare = true }, enabled = state.activeList != null) { Text("Comparar lista entre mercados") } }
        if (state.activeList == null) item { Text("Selecione uma lista para comparar preços registrados.", style = MaterialTheme.typography.bodySmall) }
        status?.let { item { Text(it) } }
        if (state.snapshot.stores.isEmpty()) item { Text("Cadastre onde você compra. Os preços observados ficam ligados ao mercado e à data.", modifier = Modifier.padding(vertical = 16.dp)) }
        items(state.snapshot.stores.sortedWith(compareByDescending<Store> { it.favorite }.thenBy { it.name }), key = { it.id }) { store ->
            SectionCard(store.name) {
                if (store.address.isNotBlank()) Text(store.address)
                if (store.neighborhood.isNotBlank() || store.city.isNotBlank()) Text(listOf(store.neighborhood, store.city).filter { it.isNotBlank() }.joinToString(" · "))
                store.distanceKm?.let { Text("Distância informada: $it km") }
                if (store.notes.isNotBlank()) Text(store.notes, style = MaterialTheme.typography.bodySmall)
                val selected = state.activeList?.storeId == store.id
                Text(if (selected) "Mercado da lista ativa" else if (store.favorite) "Mercado favorito" else "${state.snapshot.prices.count { it.storeId == store.id }} preços registrados", style = MaterialTheme.typography.labelLarge)
                Button(enabled = state.activeList != null && !selected, onClick = {
                    state.activeList?.let { vm.saveList(it.copy(storeId = store.id)); status = "${store.name} selecionado para ${it.name}." }
                }) { Text(if (selected) "Mercado selecionado" else "Comprar neste mercado") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { editId = store.id }) { Text("Editar") }
                    TextButton(onClick = { vm.saveStore(store.copy(favorite = !store.favorite)) }) { Text(if (store.favorite) "Desfavoritar" else "Favoritar") }
                }
                OutlinedButton(onClick = { pricesId = store.id }) { Text("Histórico de preços") }
                TextButton(onClick = { deleteId = store.id }) { Text("Excluir mercado", color = MaterialTheme.colorScheme.error) }
            }
        }
        item { Text("Preços anteriores são referências históricas. Confirme preço e disponibilidade no estabelecimento.", modifier = Modifier.padding(bottom = 16.dp), style = MaterialTheme.typography.bodySmall) }
    }
    if (adding) StoreEditor(null, vm) { adding = false }
    state.snapshot.stores.firstOrNull { it.id == editId }?.let { StoreEditor(it, vm) { editId = null } }
    state.snapshot.stores.firstOrNull { it.id == deleteId }?.let { store ->
        AlertDialog(onDismissRequest = { deleteId = null }, title = { Text("Excluir ${store.name}?") }, text = {
            Text("O cadastro e os preços associados serão removidos. As compras concluídas mantêm o nome do mercado em seus registros. Listas deixam de selecionar este estabelecimento.")
        }, confirmButton = { TextButton(onClick = { vm.deleteStore(store.id); deleteId = null }) { Text("Excluir", color = MaterialTheme.colorScheme.error) } }, dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } })
    }
    state.snapshot.stores.firstOrNull { it.id == pricesId }?.let { store ->
        AlertDialog(onDismissRequest = { pricesId = null }, title = { Text("Preços · ${store.name}") }, text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val prices = state.snapshot.prices.filter { it.storeId == store.id }.sortedByDescending { it.observedAt }
                if (prices.isEmpty()) Text("Nenhum preço registrado. Atualize o preço real ao colocar um produto no carrinho.")
                prices.forEach { price ->
                    val product = state.snapshot.products.firstOrNull { it.id == price.productId }
                    Text("${product?.name ?: "Produto não encontrado"} ${product?.brand.orEmpty()}\n${Money.format(price.priceCents)} / ${product?.saleUnit?.label ?: "un"} · ${dateLabel(price.observedAt)}\n${sourceLabel(price.source)} · ${price.sourceName}${if (price.promotion.isBlank()) "" else "\n${price.promotion}"}")
                }
                Text("Estas observações não garantem preço atual ou estoque.", style = MaterialTheme.typography.bodySmall)
            }
        }, confirmButton = { TextButton(onClick = { pricesId = null }) { Text("Fechar") } })
    }
    if (compare) StoreComparisonDialog(state) { compare = false }
}

@Composable
private fun StoreEditor(store: Store?, vm: MarketViewModel, onDismiss: () -> Unit) {
    var name by rememberSaveable(store?.id) { mutableStateOf(store?.name.orEmpty()) }
    var address by rememberSaveable(store?.id) { mutableStateOf(store?.address.orEmpty()) }
    var neighborhood by rememberSaveable(store?.id) { mutableStateOf(store?.neighborhood.orEmpty()) }
    var city by rememberSaveable(store?.id) { mutableStateOf(store?.city.orEmpty()) }
    var notes by rememberSaveable(store?.id) { mutableStateOf(store?.notes.orEmpty()) }
    var distance by rememberSaveable(store?.id) { mutableStateOf(store?.distanceKm.orEmpty()) }
    var favorite by rememberSaveable(store?.id) { mutableStateOf(store?.favorite ?: false) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (store == null) "Cadastrar supermercado" else "Editar mercado") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nome *") }, singleLine = true)
            OutlinedTextField(address, { address = it }, label = { Text("Endereço (opcional)") })
            OutlinedTextField(neighborhood, { neighborhood = it }, label = { Text("Bairro") }, singleLine = true)
            OutlinedTextField(city, { city = it }, label = { Text("Cidade") }, singleLine = true)
            OutlinedTextField(distance, { distance = it }, label = { Text("Distância de ida em km (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Observações") })
            Row { Checkbox(favorite, { favorite = it }); Text("Mercado favorito", Modifier.padding(top = 12.dp)) }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        runCatching {
            require(name.isNotBlank()) { "Informe o nome do mercado." }
            val normalizedDistance = distance.trim().replace(',', '.')
            if (normalizedDistance.isNotBlank()) require(BigDecimal(normalizedDistance) >= BigDecimal.ZERO && BigDecimal(normalizedDistance) <= BigDecimal(100000)) { "Informe uma distância entre 0 e 100000 km." }
            vm.saveStore(Store(id = store?.id ?: 0, name = name.trim(), address = address.trim(), neighborhood = neighborhood.trim(), city = city.trim(), notes = notes.trim(), distanceKm = normalizedDistance.takeIf { it.isNotBlank() }, favorite = favorite))
            onDismiss()
        }.onFailure { error = it.message ?: "Verifique os dados informados." }
    }) { Text("Salvar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun StoreComparisonDialog(state: MarketUiState, onDismiss: () -> Unit) {
    var order by rememberSaveable { mutableStateOf("Cobertura") }
    var travelCost by rememberSaveable { mutableStateOf("") }
    val comparisons = remember(state.snapshot, state.activeList) {
        RecommendationEngine().compareStores(state.activeItems, state.snapshot.products, state.snapshot.prices, state.snapshot.stores)
    }
    val costCents = travelCost.takeIf { it.isNotBlank() }?.let { runCatching { Money.parseCents(it).also { cents -> require(cents <= 100000000L) } }.getOrNull() }
    val ordered = when (order) {
        "Preço conhecido" -> comparisons.sortedBy { it.knownTotalCents }
        "Distância" -> comparisons.sortedBy { it.store.distanceKm?.toBigDecimalOrNull() ?: BigDecimal("999999999") }
        "Preferência" -> comparisons.sortedWith(compareByDescending<StoreComparison> { it.store.favorite }.thenByDescending { it.comparableCount })
        else -> comparisons.sortedWith(compareBy<StoreComparison> { it.missingCount }.thenBy { it.knownTotalCents })
    }
    val baseline = comparisons.firstOrNull { it.store.id == state.activeList?.storeId && it.missingCount == 0 }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Comparar ${state.activeList?.name.orEmpty()}") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Totais calculados com os últimos preços disponíveis de cada produto. Preços históricos precisam ser confirmados no mercado.")
            ChoiceChips(listOf("Cobertura", "Preço conhecido", "Distância", "Preferência"), order) { order = it }
            OutlinedTextField(travelCost, { travelCost = it }, label = { Text("Custo de deslocamento R$/km (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            if (travelCost.isNotBlank() && costCents == null) Text("Informe um custo válido.", color = MaterialTheme.colorScheme.error)
            if (ordered.isEmpty()) Text("Cadastre mercados e preços reais para comparar.")
            ordered.forEach { comparison ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(comparison.store.name, style = MaterialTheme.typography.titleMedium)
                    Text("Total conhecido: ${Money.format(comparison.knownTotalCents)}")
                    val count = comparison.comparableCount + comparison.missingCount
                    val coverage = if (count == 0) 0 else comparison.comparableCount * 100 / count
                    Text("Cobertura: $coverage% · ${comparison.comparableCount} com preço · ${comparison.missingCount} sem preço")
                    comparison.oldestObservation?.let { oldest ->
                        Text("Registros de ${dateLabel(oldest)} a ${dateLabel(comparison.latestObservation ?: oldest)}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (comparison.missingCount > 0) Text("Comparação parcial: o total não inclui todos os produtos.", style = MaterialTheme.typography.bodySmall)
                    else if (baseline != null && baseline.store.id != comparison.store.id) {
                        Text("Diferença potencial frente ao mercado da lista: ${Money.format(baseline.knownTotalCents - comparison.knownTotalCents)}", style = MaterialTheme.typography.bodySmall)
                    }
                    val distance = comparison.store.distanceKm?.toBigDecimalOrNull()
                    if (distance != null && costCents != null) {
                        val displacement = runCatching { BigDecimal(costCents).multiply(distance).multiply(BigDecimal(2)).setScale(0, RoundingMode.HALF_UP).longValueExact() }.getOrNull()
                        if (displacement != null) {
                            val combined = runCatching { Math.addExact(comparison.knownTotalCents, displacement) }.getOrNull()
                            Text("Deslocamento ida e volta estimado: ${Money.format(displacement)}${if (combined == null) "" else " · total conhecido + deslocamento: ${Money.format(combined)}"}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text("Fonte: observações locais, com datas registradas.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } })
}

private fun sourceLabel(source: PriceSource): String = when (source) {
    PriceSource.USER_CONFIRMED -> "Informado e confirmado pelo usuário"
    PriceSource.HISTORICAL -> "Histórico"
    PriceSource.ADVERTISED -> "Anunciado"
    PriceSource.ESTIMATED -> "Estimado"
}
