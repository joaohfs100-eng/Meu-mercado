package br.com.meumercado

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MeuMercadoApplication : Application()
