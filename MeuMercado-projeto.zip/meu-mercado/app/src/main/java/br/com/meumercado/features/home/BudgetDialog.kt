package br.com.meumercado.features.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*
import java.math.BigDecimal

@Composable fun BudgetDialog(budget: BudgetSettings, onDismiss: () -> Unit, onSave: (BudgetSettings) -> Unit) {
    var total by rememberSaveable { mutableStateOf(moneyInput(budget.totalCents)) }
    var safety by rememberSaveable { mutableStateOf(moneyInput(budget.safetyCents)) }
    var percent by rememberSaveable { mutableStateOf(budget.safetyPercent.replace('.', ',')) }
    var maximum by rememberSaveable { mutableStateOf(budget.maximumCents?.let(::moneyInput) ?: "") }
    var alerts by rememberSaveable { mutableStateOf(budget.alertThresholds.sorted().joinToString(",")) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Orçamento e margem de segurança") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            DecimalField(total, { total = it }, "Orçamento total (R$)")
            DecimalField(safety, { safety = it }, "Reserva em reais (R$)")
            DecimalField(percent, { percent = it }, "Reserva percentual (%)")
            Text("As duas reservas são somadas. O limite também respeita o máximo definido.", style = MaterialTheme.typography.bodySmall)
            DecimalField(maximum, { maximum = it }, "Limite máximo opcional (R$)")
            OutlinedTextField(alerts, { alerts = it }, label = { Text("Alertas em % separados por vírgula") })
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        try {
            val p = BigDecimal(percent.replace(',', '.'))
            require(p >= BigDecimal.ZERO && p <= BigDecimal(100)) { "Informe uma margem entre 0 e 100%." }
            val thresholds = alerts.split(',').filter { it.isNotBlank() }.map { it.trim().toInt() }.toSet()
            require(thresholds.all { it in 1..100 }) { "Alertas devem estar entre 1 e 100%." }
            val updated = budget.copy(totalCents = Money.parseCents(total), safetyCents = Money.parseCents(safety), safetyPercent = p.toPlainString(), maximumCents = maximum.takeIf { it.isNotBlank() }?.let(Money::parseCents), alertThresholds = thresholds)
            require(updated.safetyCents <= updated.totalCents) { "A reserva não pode superar o orçamento." }
            onSave(updated)
        } catch (e: Exception) { error = e.message ?: "Revise os valores informados." }
    }) { Text("Salvar") } }, dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
}
