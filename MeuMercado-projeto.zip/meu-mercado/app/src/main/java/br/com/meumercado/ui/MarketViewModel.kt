package br.com.meumercado.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.meumercado.domain.*
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class MarketUiState(
    val snapshot: AppSnapshot = AppSnapshot(), val settings: AISettings = AISettings(),
    val loading: Boolean = true, val error: String? = null
) {
    val activeList: ShoppingList? get() = snapshot.lists.firstOrNull { it.id == settings.activeListId }
    val activeItems: List<ShoppingListItem> get() = snapshot.items.filter { it.listId == activeList?.id }
    val activeBudget: BudgetSettings get() = snapshot.budgets.firstOrNull { it.listId == activeList?.id } ?: BudgetSettings(activeList?.id ?: 0)
    val summary: BudgetSummary get() = BudgetCalculator.calculate(activeItems, activeBudget)
}

@HiltViewModel
class MarketViewModel @Inject constructor(private val repository: MarketRepository) : ViewModel() {
    private val mutations = Mutex()
    private val errors = MutableStateFlow<String?>(null)
    private data class LoadedValue<T>(val value: T, val loaded: Boolean = false)
    private val snapshotCache = MutableStateFlow(LoadedValue(AppSnapshot()))
    private val settingsCache = MutableStateFlow(LoadedValue(AISettings()))

    /** Preserva o último valor válido durante uma falha transitória, sem consumir cancelamentos. */
    private fun <T> resilient(source: Flow<T>, cached: MutableStateFlow<LoadedValue<T>>): Flow<LoadedValue<T>> = source
        .map { LoadedValue(it, loaded = true) }
        .onEach { cached.value = it }
        .retryWhen { failure, attempt ->
            if (failure is CancellationException) throw failure
            if (attempt == 0L) errors.value = failure.message ?: "Não foi possível acessar seus dados. Tentando novamente."
            delay(3_000)
            true
        }
        .onStart { emit(cached.value) }

    val state: StateFlow<MarketUiState> = combine(
        resilient(repository.snapshot, snapshotCache),
        resilient(repository.settings, settingsCache), errors
    ) { snapshot, settings, error ->
        MarketUiState(snapshot.value, settings.value, !snapshot.loaded || !settings.loaded, error)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MarketUiState())

    private fun runAction(action: suspend () -> Unit) {
        viewModelScope.launch {
            try { mutations.withLock { action() } }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (failure: Exception) { errors.value = failure.message ?: "Não foi possível concluir a operação." }
        }
    }
    fun clearError() { errors.value = null }
    fun saveProduct(product: Product) = runAction { repository.saveProduct(product) }
    fun saveStore(store: Store) = runAction { repository.saveStore(store) }
    fun deleteStore(id: Long) = runAction { repository.deleteStore(id) }
    fun saveList(list: ShoppingList) = runAction {
        val id = repository.saveList(list)
        val current = repository.settings.first()
        if (list.id == 0L || current.activeListId == null) repository.saveSettings(current.copy(activeListId = id))
    }
    fun saveItem(item: ShoppingListItem) = runAction { repository.saveItem(item) }
    fun deleteItem(id: Long) = runAction { repository.deleteItem(id) }
    fun setItemStatus(id: Long, status: ItemStatus) = runAction {
        val current = repository.snapshot.first().items.firstOrNull { it.id == id } ?: error("Item não encontrado.")
        val discount = if (current.status == ItemStatus.IN_CART && status != ItemStatus.IN_CART) 0 else current.discountCents
        repository.saveItem(current.copy(status = status, discountCents = discount))
    }
    fun placeInCart(id: Long, quantity: String, priceCents: Long, discountCents: Long) = runAction {
        val current = repository.snapshot.first().items.firstOrNull { it.id == id } ?: error("Item não encontrado.")
        repository.saveItem(current.copy(quantity = quantity, actualPriceCents = priceCents, discountCents = discountCents, status = ItemStatus.IN_CART))
    }
    fun saveBudget(budget: BudgetSettings) = runAction { repository.saveBudget(budget) }
    /** Para restauração/configurações completas. Ações de controles usam updateSettings. */
    fun saveSettings(settings: AISettings) = runAction { repository.saveSettings(settings) }
    fun updateSettings(change: (AISettings) -> AISettings) = runAction {
        repository.saveSettings(change(repository.settings.first()))
    }
    fun deleteList(id: Long) = runAction { repository.deleteList(id) }
    fun duplicateList(id: Long) = runAction {
        val copy = repository.duplicateList(id)
        repository.saveSettings(repository.settings.first().copy(activeListId = copy))
    }
    fun activateList(id: Long) = updateSettings { it.copy(activeListId = id) }
    fun substitute(itemId: Long, alternative: Alternative) = runAction { repository.substitute(itemId, alternative) }
    fun applySubstitutions(changes: List<Pair<Long, Alternative>>) = runAction {
        var completed = 0
        try { changes.forEach { (id, alternative) -> repository.substitute(id, alternative); completed++ } }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (failure: Exception) { throw IllegalStateException("$completed de ${changes.size} trocas aplicadas. ${failure.message ?: "Revise a lista antes de continuar."}", failure) }
    }
    fun undo() = runAction { if (!repository.undo()) errors.value = "Não há uma alteração para desfazer." }
    fun finishPurchase(listId: Long) = runAction { repository.finishPurchase(listId) }
    fun saveTax(tax: TaxRecord) = runAction { repository.saveTax(tax) }
    fun saveReceipt(historyId: Long, uri: String) = runAction { repository.saveReceipt(historyId, uri) }
    fun rememberSearch(query: String) = runAction { if (query.isNotBlank()) repository.rememberSearch(query) }
    fun eraseAll() = runAction { repository.eraseAll() }
    fun clearLearnedPreferences() = runAction { repository.clearLearnedPreferences() }
    suspend fun exportBackup(): String = mutations.withLock { repository.exportBackup() }
    suspend fun restoreBackup(json: String) = mutations.withLock { repository.restoreBackup(json) }
    fun addProductToActiveList(product: Product, quantity: String, priceCents: Long, observed: Boolean = false) {
        // A ação permanece vinculada à lista que estava selecionada quando o usuário confirmou.
        val targetListId = state.value.activeList?.id
        runAction {
            val listId = targetListId ?: throw IllegalStateException("Crie e selecione uma lista antes de adicionar produtos.")
            Money.parseQuantity(quantity)
            val snapshot = repository.snapshot.first()
            val list = snapshot.lists.firstOrNull { it.id == listId } ?: error("A lista selecionada não existe mais.")
            val productId = repository.saveProduct(product)
            repository.saveItem(ShoppingListItem(listId = listId, productId = productId, quantity = quantity,
                estimatedPriceCents = priceCents, position = snapshot.items.count { it.listId == listId }))
            val storeId = list.storeId
            if (observed && storeId != null) repository.observePrice(PriceObservation(productId = productId, storeId = storeId, priceCents = priceCents))
        }
    }
    fun updateProductAndItem(product: Product, item: ShoppingListItem) = runAction {
        repository.saveProduct(product)
        repository.saveItem(item)
    }
}
