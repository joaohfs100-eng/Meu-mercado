package br.com.meumercado.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}
@Composable fun EmptyState(title: String, detail: String, actionLabel: String? = null, onAction: () -> Unit = {}) {
    SectionCard(title) { Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant); if (actionLabel != null) Button(onClick = onAction) { Text(actionLabel) } }
}
@Composable fun Metric(label: String, value: String, modifier: Modifier = Modifier, warning: Boolean = false) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            color = if (warning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
    }
}
@Composable fun DecimalField(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(value, onValueChange, modifier, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}
fun moneyInput(cents: Long): String = java.math.BigDecimal(cents).movePointLeft(2).toPlainString().replace('.', ',')
fun dateText(timestamp: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(timestamp))
fun RecommendationMode.portuguese(): String = when (this) {
    RecommendationMode.MAXIMUM_SAVINGS -> "Máxima economia"
    RecommendationMode.BEST_VALUE -> "Melhor custo-benefício"
    RecommendationMode.FAVORITE_BRANDS -> "Minhas marcas favoritas"
}
fun ItemStatus.portuguese(): String = when (this) {
    ItemStatus.PENDING -> "Pendente"
    ItemStatus.IN_CART -> "No carrinho"
    ItemStatus.UNAVAILABLE -> "Indisponível"
    ItemStatus.REMOVED -> "Removido"
}
fun PriceSource.portuguese(): String = when (this) {
    PriceSource.USER_CONFIRMED -> "Preço informado pelo usuário"
    PriceSource.HISTORICAL -> "Preço histórico"
    PriceSource.ADVERTISED -> "Preço anunciado"
    PriceSource.ESTIMATED -> "Estimativa"
}
