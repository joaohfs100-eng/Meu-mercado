package br.com.meumercado.features.settings

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

/** Lembrete persistido pelo WorkManager. Não transmite dados e não precisa de rede. */
class ShoppingReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Lembretes de compras", NotificationManager.IMPORTANCE_DEFAULT))
        val launch = applicationContext.packageManager.getLaunchIntentForPackage(applicationContext.packageName)
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("Meu Mercado")
            .setContentText("Hora de revisar sua lista e planejar uma compra dentro do orçamento.")
            .setAutoCancel(true)
        if (launch != null) notification.setContentIntent(PendingIntent.getActivity(applicationContext, 10, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        manager.notify(1201, notification.build())
        return Result.success()
    }

    companion object {
        const val UNIQUE_NAME = "meu_mercado_shopping_reminder"
        private const val CHANNEL = "shopping_reminders"
    }
}
