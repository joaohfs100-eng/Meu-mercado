package br.com.meumercado.features

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.Money
import br.com.meumercado.domain.ShoppingHistory
import br.com.meumercado.domain.TaxRecord
import br.com.meumercado.ui.MarketUiState
import br.com.meumercado.ui.MarketViewModel
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun HistoryScreen(state: MarketUiState, vm: MarketViewModel) {
    val (period, changePeriod) = rememberPeriod()
    var store by rememberSaveable { mutableStateOf("Todos os mercados") }
    var category by rememberSaveable { mutableStateOf("Todas as categorias") }
    var selectedId by rememberSaveable { mutableStateOf<Long?>(null) }
    val selected = state.snapshot.history.firstOrNull { it.id == selectedId }
    val visible = state.snapshot.history.filter { purchase ->
        period.accepts(purchase.completedAt) && (store == "Todos os mercados" || purchase.storeName == store) &&
            (category == "Todas as categorias" || purchase.items.any { it.category == category })
    }.sortedByDescending { it.completedAt }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Histórico de compras", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp)) }
        item { PeriodFilter(period, changePeriod) }
        item { ChoiceChips(listOf("Todos os mercados") + state.snapshot.history.map { it.storeName }.distinct(), store) { store = it } }
        item { ChoiceChips(listOf("Todas as categorias") + state.snapshot.history.flatMap { it.items }.map { it.category }.distinct(), category) { category = it } }
        item {
            SectionCard("Compras do período") {
                Text("${visible.size} compras · ${Money.format(visible.sumOf { it.totalCents })}")
                if (category != "Todas as categorias") Text("Total das compras que contêm $category. Os detalhes preservam todos os itens.", style = MaterialTheme.typography.bodySmall)
                Text("Produtos e preços são registros da compra finalizada.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (visible.isEmpty()) item { Text("Nenhuma compra neste período. As compras finalizadas aparecerão aqui.", modifier = Modifier.padding(vertical = 16.dp)) }
        items(visible, key = { it.id }) { purchase ->
            SectionCard(purchase.listName) {
                Text("${purchase.storeName.ifBlank { "Mercado não informado" }} · ${dateLabel(purchase.completedAt)}")
                Text(Money.format(purchase.totalCents), style = MaterialTheme.typography.titleLarge)
                Text("${purchase.items.size} produtos · orçamento ${Money.format(purchase.budgetCents)}")
                val taxes = state.snapshot.taxes.filter { it.historyId == purchase.id }
                Text(if (taxes.isEmpty()) "Tributos não informados." else "Tributos documentados: ${Money.format(taxes.filter { it.documented }.sumOf { it.amountCents })} · estimativas: ${Money.format(taxes.filterNot { it.documented }.sumOf { it.amountCents })}", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { selectedId = purchase.id }) { Text("Ver compra e impostos") }
            }
        }
        item { Text("", modifier = Modifier.padding(bottom = 8.dp)) }
    }
    selected?.let { purchase ->
        PurchaseDetails(purchase, state.snapshot.taxes.filter { it.historyId == purchase.id }, vm) { selectedId = null }
    }
}

@Composable
private fun PurchaseDetails(purchase: ShoppingHistory, taxes: List<TaxRecord>, vm: MarketViewModel, onDismiss: () -> Unit) {
    var taxDialog by rememberSaveable(purchase.id) { mutableStateOf(false) }
    var receiptDialog by rememberSaveable(purchase.id) { mutableStateOf(false) }
    var openReceipt by remember { mutableStateOf(false) }
    var message by rememberSaveable(purchase.id) { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    AlertDialog(onDismissRequest = onDismiss, title = { Text(purchase.listName) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${purchase.storeName} · ${dateLabel(purchase.completedAt)}")
            purchase.items.forEach { item ->
                Column {
                    Text("${item.productName} ${item.brand}", style = MaterialTheme.typography.titleSmall)
                    Text("${item.quantity} ${item.unit.label} × ${Money.format(item.unitPriceCents)} · ${Money.format(item.totalCents)}")
                    if (item.discountCents > 0) Text("Desconto: ${Money.format(item.discountCents)}", style = MaterialTheme.typography.bodySmall)
                    if (item.substituted) Text("Substituição aceita nesta compra", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("Total pago: ${Money.format(purchase.totalCents)}", style = MaterialTheme.typography.titleMedium)
            Text("Estimativa inicial: ${Money.format(purchase.estimatedCents)} · diferença ${Money.format(purchase.estimatedCents - purchase.totalCents)}")
            Text("Impostos da minha compra", style = MaterialTheme.typography.titleMedium)
            if (taxes.isEmpty()) Text("Tributos não informados.")
            taxes.forEach { tax ->
                Text("${Money.format(tax.amountCents)} · ${if (tax.documented) "Documentado" else "Estimativa"}\n${tax.source}\n${if (tax.includedInPrice) "Já incluído no preço; não somado ao total." else "Registrado separadamente; não altera o total pago."}")
            }
            OutlinedButton(onClick = { taxDialog = true }) { Text("Registrar tributos ou simulação") }
            OutlinedButton(onClick = { receiptDialog = true }) { Text("Vincular endereço da NFC-e") }
            if (purchase.receiptUri != null) TextButton(onClick = { openReceipt = true }) { Text("Abrir nota vinculada") }
            Text("Leia o QR Code fiscal pelo scanner. Portais oficiais podem exigir autenticação ou CAPTCHA; valores precisam de revisão manual.", style = MaterialTheme.typography.bodySmall)
            message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } })
    if (taxDialog) TaxDialog(purchase, taxes, vm) { taxDialog = false }
    if (receiptDialog) ReceiptDialog(purchase, vm) { receiptDialog = false }
    if (openReceipt) AlertDialog(onDismissRequest = { openReceipt = false }, title = { Text("Abrir portal da nota?") }, text = {
        Text("O navegador acessará este endereço externo:\n${purchase.receiptUri}\nConfira se pertence ao portal fiscal esperado.")
    }, confirmButton = {
        TextButton(onClick = {
            openReceipt = false
            val uri = Uri.parse(purchase.receiptUri.orEmpty())
            if (uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null) {
                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }.onFailure { message = "Não foi possível abrir o navegador." }
            } else message = "O endereço precisa usar HTTPS e não pode conter credenciais."
        }) { Text("Abrir navegador") }
    }, dismissButton = { TextButton(onClick = { openReceipt = false }) { Text("Cancelar") } })
}

@Composable
private fun TaxDialog(purchase: ShoppingHistory, records: List<TaxRecord>, vm: MarketViewModel, onDismiss: () -> Unit) {
    var amount by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("Informado na nota fiscal") }
    var documented by rememberSaveable { mutableStateOf(true) }
    var included by rememberSaveable { mutableStateOf(true) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var review by remember { mutableStateOf<TaxRecord?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Impostos da minha compra") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row { Checkbox(documented, { documented = it; source = if (it) "Informado na nota fiscal" else "Simulação informada pelo usuário" }); Text("Valor documentado na nota", modifier = Modifier.padding(top = 12.dp)) }
            if (!documented) {
                Text("Simulação: informe um percentual ou um valor. Esta estimativa não substitui a nota fiscal.")
                OutlinedTextField(rate, { rate = it }, label = { Text("Percentual estimado (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("Valor dos tributos em R$") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(source, { source = it }, label = { Text("Fonte / parâmetros da simulação") })
            Row { Checkbox(included, { included = it }); Text("Tributos incluídos no preço", modifier = Modifier.padding(top = 12.dp)) }
            Text("O total pago permanece ${Money.format(purchase.totalCents)}. Tributos nunca são adicionados novamente ao total.", style = MaterialTheme.typography.bodySmall)
            if (records.isNotEmpty()) Text("Esta compra já possui ${records.size} registros. Evite cadastrar o mesmo valor novamente.", style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        runCatching {
            val cents = if (!documented && rate.isNotBlank()) {
                require(amount.isBlank()) { "Preencha o percentual ou o valor, somente um deles." }
                val percent = BigDecimal(rate.trim().replace(',', '.'))
                require(percent >= BigDecimal.ZERO && percent <= BigDecimal(100)) { "Percentual deve estar entre 0 e 100." }
                BigDecimal(purchase.totalCents).multiply(percent).divide(BigDecimal(100), 0, RoundingMode.HALF_UP).longValueExact()
            } else Money.parseCents(amount)
            require(cents > 0) { "Informe um valor maior que zero." }
            require(source.isNotBlank()) { "Informe a fonte do valor." }
            review = TaxRecord(historyId = purchase.id, amountCents = cents, documented = documented, includedInPrice = included,
                source = if (!documented && rate.isNotBlank()) "$source · $rate% de ${Money.format(purchase.totalCents)}" else source.trim())
        }.onFailure { error = it.message ?: "Valor inválido." }
    }) { Text("Revisar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
    review?.let { tax -> AlertDialog(onDismissRequest = { review = null }, title = { Text("Confirmar registro de tributos?") }, text = {
        Text("${Money.format(tax.amountCents)} · ${if (tax.documented) "Documentado" else "Estimativa"}\n${tax.source}\nO registro não altera o total da compra.")
    }, confirmButton = { TextButton(onClick = { vm.saveTax(tax); review = null; onDismiss() }) { Text("Confirmar") } }, dismissButton = { TextButton(onClick = { review = null }) { Text("Corrigir") } }) }
}

@Composable
private fun ReceiptDialog(purchase: ShoppingHistory, vm: MarketViewModel, onDismiss: () -> Unit) {
    var url by rememberSaveable { mutableStateOf(purchase.receiptUri.orEmpty()) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Vincular NFC-e") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Cole o endereço HTTPS obtido no QR Code. A vinculação não extrai nem confirma tributos automaticamente.")
            OutlinedTextField(url, { url = it }, label = { Text("Endereço da nota fiscal") }, modifier = Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }, confirmButton = { TextButton(onClick = {
        val uri = Uri.parse(url.trim())
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null) error = "Informe um endereço HTTPS válido, sem credenciais."
        else { vm.saveReceipt(purchase.id, url.trim()); onDismiss() }
    }) { Text("Confirmar vínculo") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
