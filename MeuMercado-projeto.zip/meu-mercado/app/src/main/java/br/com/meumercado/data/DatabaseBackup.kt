package br.com.meumercado.data

import android.database.Cursor
import androidx.room.withTransaction
import br.com.meumercado.database.MarketDatabase
import br.com.meumercado.domain.*
import java.math.BigDecimal
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/** Versioned local backup. Imported table and column names are strictly allow-listed. */
internal class DatabaseBackup(
    private val database: MarketDatabase,
    private val settingsStore: SettingsStore,
    private val repository: RoomMarketRepository
) {
    suspend fun export(): String = database.withTransaction {
        val sql = database.openHelper.writableDatabase
        val data = JSONObject()
        MarketDatabase.TABLES.forEach { table ->
            val rows = JSONArray()
            sql.query("SELECT * FROM `$table`").use { cursor ->
                while (cursor.moveToNext()) {
                    val row = JSONObject()
                    cursor.columnNames.forEachIndexed { index, column ->
                        row.put(column, when (cursor.getType(index)) {
                            Cursor.FIELD_TYPE_NULL -> JSONObject.NULL
                            Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(index)
                            Cursor.FIELD_TYPE_STRING -> cursor.getString(index)
                            else -> error("Tipo de coluna não suportado no backup.")
                        })
                    }
                    rows.put(row)
                }
            }
            data.put(table, rows)
        }
        JSONObject().put("format", FORMAT).put("version", VERSION).put("databaseVersion", 2)
            .put("exportedAt", System.currentTimeMillis()).put("settings", JsonCodec.settings(settingsStore.settings.first()))
            .put("tables", data).toString(2)
    }

    suspend fun restore(raw: String) {
        require(raw.length <= MAX_BYTES) { "O backup excede o limite de 20 MB." }
        val document = try { JSONObject(raw) } catch (_: Exception) { throw IllegalArgumentException("Arquivo de backup inválido.") }
        require(document.getString("format") == FORMAT && document.getInt("version") == VERSION && document.getInt("databaseVersion") == 2) {
            "Formato ou versão de backup incompatível."
        }
        val restoredSettings = JsonCodec.settings(document.getJSONObject("settings"))
        RoomMarketRepository.validateSettings(restoredSettings)
        val tables = document.getJSONObject("tables")
        require(tables.keys().asSequence().toSet() == MarketDatabase.TABLES.toSet()) { "Backup incompleto ou com tabelas desconhecidas." }
        val sql = database.openHelper.writableDatabase
        // Parse all records before changing existing data. Also verify exact columns against the installed schema.
        var records = 0
        val parsed = MarketDatabase.TABLES.associateWith { table ->
            val columns = mutableListOf<String>()
            sql.query("PRAGMA table_info(`$table`)").use { cursor ->
                val nameIndex = cursor.getColumnIndexOrThrow("name")
                while (cursor.moveToNext()) columns += cursor.getString(nameIndex)
            }
            val rows = tables.getJSONArray(table)
            records += rows.length()
            require(records <= MAX_RECORDS) { "O backup tem registros demais." }
            columns to (0 until rows.length()).map { rowIndex ->
                val row = rows.getJSONObject(rowIndex)
                require(row.keys().asSequence().toSet() == columns.toSet()) { "Colunas inválidas na tabela $table." }
                columns.map { column ->
                    row.get(column).also { value ->
                        require(value === JSONObject.NULL || value is Int || value is Long || value is String) { "Tipo inválido em $table.$column." }
                        if (value is String) require(value.length <= 100_000) { "Campo excessivamente longo." }
                        if ((column == "id" || column.endsWith("Id")) && value !== JSONObject.NULL) {
                            require(value is Number && value.toLong() > 0) { "Identificador inválido no backup." }
                        }
                    }
                }
            }
        }
        val previousSettings = settingsStore.settings.first()
        try {
            database.withTransaction {
                clearTables(database)
                parsed.forEach { (table, data) ->
                    val (columns, rows) = data
                    val statement = sql.compileStatement("INSERT INTO `$table` (${columns.joinToString(",") { "`$it`" }}) VALUES (${columns.joinToString(",") { "?" }})")
                    try {
                        rows.forEach { row ->
                            statement.clearBindings()
                            row.forEachIndexed { index, value ->
                                when (value) {
                                    JSONObject.NULL -> statement.bindNull(index + 1)
                                    is Number -> statement.bindLong(index + 1, value.toLong())
                                    is String -> statement.bindString(index + 1, value)
                                }
                            }
                            statement.executeInsert()
                        }
                    } finally { statement.close() }
                }
                sql.query("PRAGMA foreign_key_check").use { require(!it.moveToFirst()) { "Relacionamentos inválidos no backup." } }
                validateSnapshot(repository.readSnapshot(), restoredSettings)
                validateStoredRows()
                settingsStore.save(restoredSettings)
            }
        } catch (error: Exception) {
            settingsStore.restoreAfterFailure(previousSettings, error)
            throw IllegalArgumentException("O backup não pôde ser restaurado. Os dados anteriores foram preservados.", error)
        }
    }

    private fun validateSnapshot(snapshot: AppSnapshot, settings: AISettings) {
        snapshot.products.forEach { RoomMarketRepository.validateProduct(it) }
        snapshot.items.forEach { RoomMarketRepository.validateItem(it) }
        snapshot.budgets.forEach { RoomMarketRepository.validateBudget(it) }
        snapshot.prices.forEach { RoomMarketRepository.validatePrice(it) }
        snapshot.stores.forEach { store ->
            require(store.name.isNotBlank())
            store.distanceKm?.takeIf(String::isNotBlank)?.let { require(RoomMarketRepository.decimal(it) >= BigDecimal.ZERO) }
        }
        snapshot.lists.forEach { require(it.name.isNotBlank() && it.createdAt > 0) }
        snapshot.taxes.forEach { require(it.amountCents >= 0 && it.source.isNotBlank()) }
        snapshot.history.forEach { purchase ->
            require(purchase.items.isNotEmpty() && purchase.listName.isNotBlank() && purchase.storeName.isNotBlank() && purchase.completedAt > 0 && purchase.budgetCents >= 0)
            require(purchase.totalCents == purchase.items.fold(0L) { total, item -> Math.addExact(total, item.totalCents) })
            require(purchase.estimatedCents == purchase.items.fold(0L) { total, item -> Math.addExact(total, item.estimatedTotalCents) })
            purchase.items.forEach { item ->
                require(item.productName.isNotBlank() && item.unitPriceCents >= 0 && item.discountCents >= 0 && item.estimatedTotalCents >= 0)
                require(item.discountCents <= Money.subtotal(item.unitPriceCents, item.quantity))
                require(item.totalCents == Money.subtotal(item.unitPriceCents, item.quantity, item.discountCents))
            }
        }
        settings.activeListId?.let { active -> require(snapshot.lists.any { it.id == active }) { "Lista ativa ausente no backup." } }
    }

    private suspend fun validateStoredRows() {
        val sql = database.openHelper.writableDatabase
        listOf("product_categories", "brands", "tags").forEach { table ->
            sql.query("SELECT name FROM `$table`").use { cursor ->
                while (cursor.moveToNext()) require(cursor.getString(0).isNotBlank()) { "Nome vazio no cadastro do backup." }
            }
        }
        // SQLite accepts any integer for a boolean; imports must respect the intended domain.
        val booleanColumns = mapOf("products" to listOf("favorite", "neverSubstitute", "accepted"), "stores" to listOf("favorite"),
            "shopping_lists" to listOf("favorite", "archived", "template"), "tax_records" to listOf("documented", "includedInPrice"),
            "history_items" to listOf("substituted"), "session_items" to listOf("substituted"), "ai_settings" to listOf("onlineConsent"))
        booleanColumns.forEach { (table, columns) ->
            sql.query("SELECT 1 FROM `$table` WHERE ${columns.joinToString(" OR ") { "`$it` NOT IN (0, 1)" }} LIMIT 1").use {
                require(!it.moveToFirst()) { "Valor booleano inválido no backup." }
            }
        }
        sql.query("SELECT itemId, previousItemJson FROM undo_records").use { cursor ->
            val itemIdIndex = cursor.getColumnIndexOrThrow("itemId")
            val previousIndex = cursor.getColumnIndexOrThrow("previousItemJson")
            while (cursor.moveToNext()) {
                if (!cursor.isNull(previousIndex)) {
                    val previous = JsonCodec.item(JSONObject(cursor.getString(previousIndex)))
                    RoomMarketRepository.validateItem(previous)
                    require(previous.id == cursor.getLong(itemIdIndex) && previous.listId > 0 && previous.productId > 0)
                    requireNotNull(database.dao().list(previous.listId))
                    requireNotNull(database.dao().product(previous.productId))
                }
            }
        }
        sql.query("SELECT 1 FROM user_preferences WHERE count < 0 OR updatedAt <= 0 LIMIT 1").use { require(!it.moveToFirst()) }
        sql.query("SELECT 1 FROM shopping_sessions WHERE startedAt <= 0 OR (completedAt IS NOT NULL AND completedAt < startedAt) LIMIT 1").use { require(!it.moveToFirst()) }
        sql.query("SELECT id, mode, gatewayUrl FROM ai_settings").use { cursor ->
            while (cursor.moveToNext()) {
                require(cursor.getInt(0) == 1)
                RoomMarketRepository.validateSettings(AISettings(mode = RecommendationMode.valueOf(cursor.getString(1)), gatewayUrl = cursor.getString(2)))
            }
        }
        sql.query("SELECT mode FROM recommendations").use { cursor ->
            while (cursor.moveToNext()) RecommendationMode.valueOf(cursor.getString(0))
        }
        sql.query("SELECT uri, createdAt FROM receipts").use { cursor ->
            while (cursor.moveToNext()) {
                RoomMarketRepository.validateReceiptUri(cursor.getString(0))
                require(cursor.getLong(1) > 0)
            }
        }
        sql.query("SELECT productName, unit, quantity, unitPriceCents, discountCents, totalCents, estimatedTotalCents FROM session_items").use { cursor ->
            while (cursor.moveToNext()) {
                require(cursor.getString(0).isNotBlank())
                MeasurementUnit.valueOf(cursor.getString(1))
                val gross = Money.subtotal(cursor.getLong(3), cursor.getString(2))
                val discount = cursor.getLong(4)
                require(discount in 0..gross)
                require(cursor.getLong(5) == gross - discount && cursor.getLong(6) >= 0)
            }
        }
    }

    companion object {
        private const val FORMAT = "meu-mercado-backup"
        private const val VERSION = 1
        private const val MAX_BYTES = 20 * 1024 * 1024
        private const val MAX_RECORDS = 100_000

        fun clearTables(database: MarketDatabase) {
            val sql = database.openHelper.writableDatabase
            MarketDatabase.TABLES.asReversed().forEach { sql.execSQL("DELETE FROM `$it`") }
        }
    }
}
