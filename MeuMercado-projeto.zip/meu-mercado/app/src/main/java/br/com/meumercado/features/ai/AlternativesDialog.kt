package br.com.meumercado.features.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*
import java.math.RoundingMode

@Composable fun AlternativeDetails(alternative: Alternative, state: MarketUiState) {
    Text("${alternative.product.name} • ${alternative.product.brand.ifBlank { "Sem marca" }}", style = MaterialTheme.typography.titleSmall)
    Text("Embalagem: ${alternative.product.packageQuantity} ${alternative.product.packageUnit.label} • Quantidade necessária: ${alternative.quantity} ${alternative.product.saleUnit.label}", style = MaterialTheme.typography.bodySmall)
    Text("${Money.format(alternative.observation.priceCents)} por ${alternative.product.saleUnit.label} • total ${Money.format(alternative.totalCents)}")
    Text("R$ ${alternative.normalizedUnitPrice.setScale(2, RoundingMode.HALF_UP).toPlainString().replace('.', ',')} / ${alternative.normalizedUnit}")
    Text("${state.snapshot.stores.firstOrNull { it.id == alternative.observation.storeId }?.name ?: "Mercado #${alternative.observation.storeId}"} • ${dateText(alternative.observation.observedAt)}", style = MaterialTheme.typography.bodySmall)
    Text("${alternative.observation.source.portuguese()} • ${alternative.observation.sourceName}", style = MaterialTheme.typography.bodySmall)
    Text(if (alternative.savingsCents >= 0) "Economia potencial: ${Money.format(alternative.savingsCents)} (${alternative.savingsPercent.toPlainString().replace('.', ',')}%)" else "Custo adicional: ${Money.format(-alternative.savingsCents)}", color = if (alternative.savingsCents >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
    if (alternative.observation.promotion.isNotBlank()) Text("Promoção: ${alternative.observation.promotion}", style = MaterialTheme.typography.bodySmall)
    Text(alternative.reason, style = MaterialTheme.typography.bodySmall)
}

@Composable fun AlternativesDialog(state: MarketUiState, vm: MarketViewModel, item: ShoppingListItem, onDismiss: () -> Unit) {
    var otherStores by rememberSaveable { mutableStateOf(false) }
    var selectedKey by rememberSaveable { mutableStateOf<String?>(null) }
    var confirm by rememberSaveable { mutableStateOf(false) }
    val alternatives = remember(state.snapshot, state.settings, item, otherStores) { RecommendationEngine().alternatives(item, state.snapshot.products, state.snapshot.prices, state.settings, state.activeList?.storeId, otherStores) }
    val selected = alternatives.firstOrNull { "${it.product.id}:${it.observation.id}" == selectedKey && (item.status != ItemStatus.IN_CART || it.observation.storeId == state.activeList?.storeId) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Encontrar mais barato") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${state.settings.mode.portuguese()} • dados locais")
            Row { Checkbox(otherStores, { otherStores = it; selectedKey = null }); Text("Incluir outros mercados", Modifier.padding(top = 12.dp)) }
            if (otherStores) Text("Preços de outro mercado são referências de comparação. Confirme o mesmo valor no mercado ativo antes de aplicar; compras em outro local devem usar uma lista desse estabelecimento.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            if (alternatives.isEmpty()) Text("Não há alternativas seguras com preços registrados. Cadastre produtos equivalentes, características, embalagens e um preço encontrado no mercado. Produtos protegidos não são substituídos.")
            alternatives.forEach { alternative ->
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AlternativeDetails(alternative, state)
                        val selectable = item.status != ItemStatus.IN_CART || alternative.observation.storeId == state.activeList?.storeId
                        if (!selectable) Text("Este item já está no carrinho. Um preço de outro mercado não pode ser tratado como pago neste local. Retire o item do carrinho para planejar a troca e depois confirme o preço encontrado no mercado atual.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        Row { RadioButton(selected == alternative, { selectedKey = "${alternative.product.id}:${alternative.observation.id}" }, enabled = selectable); TextButton(onClick = { selectedKey = "${alternative.product.id}:${alternative.observation.id}" }, enabled = selectable) { Text("Selecionar esta opção") } }
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { confirm = true }, enabled = selected != null) { Text("Revisar troca") } }, dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
    if (confirm && selected != null) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Confirmar substituição?") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Substituir por ${selected.product.name} (${selected.product.brand}), quantidade ${selected.quantity}. Total ${Money.format(selected.totalCents)}.")
            if (selected.optionalOutsideFavorites) Text("⚠ Esta marca está fora das suas favoritas.", color = MaterialTheme.colorScheme.error)
            if (selected.observation.storeId != state.activeList?.storeId) Text("⚠ Este preço foi registrado em outro mercado. Confirme a troca somente se você verificou este produto e valor no mercado da lista ativa. Para comprar no outro local, utilize uma lista desse estabelecimento.", color = MaterialTheme.colorScheme.error)
            if (item.status == ItemStatus.IN_CART) Text("⚠ Este item já está no carrinho. A troca alterará a compra em andamento.")
            Text("O preço registrado não garante disponibilidade atual. Você poderá desfazer a troca.")
        }
    }, confirmButton = { TextButton(onClick = { vm.substitute(item.id, selected); confirm = false; onDismiss() }) { Text("Confirmar troca") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancelar") } })
}
