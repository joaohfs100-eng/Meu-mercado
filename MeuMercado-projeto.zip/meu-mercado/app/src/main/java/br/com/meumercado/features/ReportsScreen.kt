package br.com.meumercado.features

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.Money
import br.com.meumercado.ui.MarketUiState
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun ReportsScreen(state: MarketUiState) {
    val (period, changePeriod) = rememberPeriod()
    var store by rememberSaveable { mutableStateOf("Todos os mercados") }
    var productQuery by rememberSaveable { mutableStateOf("") }
    var priceProductId by rememberSaveable { mutableStateOf<Long?>(null) }
    val history = state.snapshot.history.filter { period.accepts(it.completedAt) && (store == "Todos os mercados" || it.storeName == store) }
    val total = history.sumOf { it.totalCents }
    val estimated = history.sumOf { it.estimatedCents }
    val average = if (history.isEmpty()) 0 else BigDecimal(total).divide(BigDecimal(history.size), 0, RoundingMode.HALF_UP).longValueExact()
    val historyIds = history.map { it.id }.toSet()
    val taxes = state.snapshot.taxes.filter { it.historyId in historyIds }
    val categories = history.flatMap { it.items }.groupBy { it.category }.mapValues { (_, items) -> items.sumOf { it.totalCents } }.toList().sortedByDescending { it.second }
    val daily = history.groupBy { Instant.ofEpochMilli(it.completedAt).atZone(ZoneId.systemDefault()).toLocalDate() }.toSortedMap()
    val acceptedSavings = state.snapshot.decisions.filter { period.accepts(it.acceptedAt) }.sumOf { it.savingsCents }
    val today = LocalDate.now()
    fun currentPeriodTotal(predicate: (LocalDate) -> Boolean) = state.snapshot.history.filter { store == "Todos os mercados" || it.storeName == store }.filter {
        predicate(Instant.ofEpochMilli(it.completedAt).atZone(ZoneId.systemDefault()).toLocalDate())
    }.sumOf { it.totalCents }
    val monthly = currentPeriodTotal { it.year == today.year && it.month == today.month }
    val weekly = currentPeriodTotal { it >= today.minusDays(6) && it <= today }
    val yearly = currentPeriodTotal { it.year == today.year }
    val previousMonth = today.minusMonths(1)
    val previous = currentPeriodTotal { it.year == previousMonth.year && it.month == previousMonth.month }
    val selectedProduct = state.snapshot.products.firstOrNull { it.id == priceProductId }
    val priceHistory = state.snapshot.prices.filter { it.productId == selectedProduct?.id && period.accepts(it.observedAt) && (store == "Todos os mercados" || state.snapshot.stores.firstOrNull { market -> market.id == it.storeId }?.name == store) }.sortedBy { it.observedAt }

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Relatórios financeiros", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 12.dp)) }
        item { PeriodFilter(period, changePeriod) }
        item { ChoiceChips(listOf("Todos os mercados") + state.snapshot.history.map { it.storeName }.distinct(), store) { store = it } }
        item {
            SectionCard("Resumo do período selecionado") {
                Text(Money.format(total), style = MaterialTheme.typography.headlineMedium)
                Text("${history.size} compras · média ${Money.format(average)} por compra")
                Text("Planejado: ${Money.format(estimated)} · pago: ${Money.format(total)}")
                Text("Diferença planejado − real: ${Money.format(estimated - total)}")
                Text("Economia estimada em substituições aceitas (todas as listas no período): ${Money.format(acceptedSavings)}")
                Text("Tributos documentados: ${Money.format(taxes.filter { it.documented }.sumOf { it.amountCents })}")
                Text("Tributos estimados: ${Money.format(taxes.filterNot { it.documented }.sumOf { it.amountCents })}")
                if (taxes.isEmpty()) Text("Tributos não informados.")
                Text("Tributos incluídos já fazem parte do valor pago; não são somados novamente.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Gastos atuais") {
                Text("Últimos 7 dias: ${Money.format(weekly)}")
                Text("Mês atual: ${Money.format(monthly)}")
                Text("Ano atual: ${Money.format(yearly)}")
                if (previous > 0) {
                    val variation = BigDecimal(monthly - previous).multiply(BigDecimal(100)).divide(BigDecimal(previous), 1, RoundingMode.HALF_UP)
                    Text("Variação em relação ao mês anterior: ${if (variation.signum() > 0) "+" else ""}${variation.toPlainString().replace('.', ',')}%")
                    Text("O mês atual pode estar incompleto.", style = MaterialTheme.typography.bodySmall)
                } else Text("Sem compras no mês anterior para calcular evolução.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (history.isEmpty()) item { Text("Finalize uma compra para gerar relatórios com dados reais.", modifier = Modifier.padding(vertical = 12.dp)) }
        item {
            SectionCard("Categorias com maiores gastos") {
                if (categories.isEmpty()) Text("Sem dados neste período.")
                MoneyBars(categories)
            }
        }
        item {
            SectionCard("Planejado e pago por dia") {
                if (daily.isEmpty()) Text("Sem dados neste período.") else {
                    val dates = daily.keys.map { it.format(brazilDate) }
                    val paid = daily.values.map { rows -> rows.sumOf { it.totalCents } }
                    val planned = daily.values.map { rows -> rows.sumOf { it.estimatedCents } }
                    MoneyLineChart(dates, paid, planned)
                    Text("Verde: pago · amarelo: planejado", style = MaterialTheme.typography.bodySmall)
                    daily.forEach { (date, rows) -> Text("${date.format(brazilDate)} · pago ${Money.format(rows.sumOf { it.totalCents })} · planejado ${Money.format(rows.sumOf { it.estimatedCents })}", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item {
            SectionCard("Produtos mais recorrentes") {
                val recurring = history.flatMap { it.items }.groupBy { Triple(it.productName, it.brand, it.unit) }.toList().sortedByDescending { it.second.size }.take(10)
                if (recurring.isEmpty()) Text("Sem produtos registrados.")
                recurring.forEach { (key, entries) ->
                    val quantity = entries.fold(BigDecimal.ZERO) { acc, item -> acc + BigDecimal(item.quantity.replace(',', '.')) }
                    Text("${key.first} ${key.second} · ${entries.size} compras · ${quantity.stripTrailingZeros().toPlainString().replace('.', ',')} ${key.third.label}")
                }
            }
        }
        item {
            SectionCard("Mercados mais utilizados") {
                val stores = history.groupBy { it.storeName.ifBlank { "Não informado" } }.toList().sortedByDescending { it.second.size }
                if (stores.isEmpty()) Text("Sem compras registradas.")
                stores.forEach { (name, entries) -> Text("$name · ${entries.size} compras · ${Money.format(entries.sumOf { it.totalCents })}") }
            }
        }
        item {
            SectionCard("Evolução de preços registrados") {
                OutlinedTextField(productQuery, { productQuery = it }, label = { Text("Pesquisar produto") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                val choices = state.snapshot.products.filter { (it.name + " " + it.brand).contains(productQuery, ignoreCase = true) }
                choices.take(30).forEach { product ->
                    androidx.compose.material3.FilterChip(selected = product.id == priceProductId, onClick = { priceProductId = product.id }, label = { Text("${product.name} ${product.brand}") })
                }
                if (choices.size > 30) Text("Refine a pesquisa para localizar outros produtos.", style = MaterialTheme.typography.bodySmall)
                if (selectedProduct == null) Text("Selecione um produto para visualizar seus preços.")
                else if (priceHistory.isEmpty()) Text("Não há preços desse produto no período e mercado selecionados.")
                else {
                    Text("${selectedProduct.name} ${selectedProduct.brand}", style = MaterialTheme.typography.titleSmall)
                    MoneyLineChart(priceHistory.map { dateLabel(it.observedAt) }, priceHistory.map { it.priceCents })
                    priceHistory.forEach { observation ->
                        val market = state.snapshot.stores.firstOrNull { it.id == observation.storeId }
                        Text("${dateLabel(observation.observedAt)} · ${market?.name.orEmpty()} · ${Money.format(observation.priceCents)}/${selectedProduct.saleUnit.label} · ${observation.sourceName}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Os registros mostram preços observados; não garantem preços atuais. Mercados diferentes podem explicar parte da variação.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("", Modifier.padding(bottom = 12.dp)) }
    }
}

@Composable
private fun MoneyBars(values: List<Pair<String, Long>>) {
    val maximum = values.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surfaceVariant
    values.forEach { (label, value) ->
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("$label · ${Money.format(value)}")
            Canvas(Modifier.fillMaxWidth().height(14.dp).semantics { contentDescription = "$label: ${Money.format(value)}" }) {
                drawRoundRect(surface, cornerRadius = androidx.compose.ui.geometry.CornerRadius(7.dp.toPx()))
                drawRoundRect(primary, size = androidx.compose.ui.geometry.Size(size.width * (value.toDouble() / maximum).toFloat().coerceIn(0f, 1f), size.height), cornerRadius = androidx.compose.ui.geometry.CornerRadius(7.dp.toPx()))
            }
        }
    }
}

@Composable
private fun MoneyLineChart(labels: List<String>, first: List<Long>, second: List<Long> = emptyList()) {
    if (first.isEmpty()) return
    val primary = MaterialTheme.colorScheme.primary
    val warning = androidx.compose.ui.graphics.Color(0xFFBD8B10)
    val grid = MaterialTheme.colorScheme.outlineVariant
    val maximum = (first + second).maxOrNull()?.coerceAtLeast(1L) ?: 1L
    val description = labels.mapIndexed { i, label -> "$label: ${Money.format(first[i])}${if (i < second.size) ", planejado ${Money.format(second[i])}" else ""}" }.joinToString("; ")
    Canvas(Modifier.fillMaxWidth().height(180.dp).semantics { contentDescription = "Gráfico de evolução. $description" }) {
        val left = 10.dp.toPx()
        val top = 10.dp.toPx()
        val width = size.width - left * 2
        val height = size.height - top * 2
        for (index in 0..4) {
            val y = top + height * index / 4
            drawLine(grid, Offset(left, y), Offset(left + width, y), 1.dp.toPx())
        }
        fun line(values: List<Long>, color: androidx.compose.ui.graphics.Color) {
            val points = values.mapIndexed { index, value ->
                Offset(left + if (values.size == 1) width / 2 else width * index / (values.size - 1), top + height * (1f - (value.toDouble() / maximum).toFloat().coerceIn(0f, 1f)))
            }
            val path = Path()
            points.forEachIndexed { index, point -> if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y) }
            drawPath(path, color, style = Stroke(width = 2.dp.toPx()))
            points.forEach { drawCircle(color, 3.dp.toPx(), it) }
        }
        line(first, primary)
        if (second.isNotEmpty()) line(second, warning)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(labels.first(), style = MaterialTheme.typography.bodySmall)
        Text(labels.last(), style = MaterialTheme.typography.bodySmall)
    }
    Text("Escala: R$ 0,00 a ${Money.format(maximum)}", style = MaterialTheme.typography.bodySmall)
}
