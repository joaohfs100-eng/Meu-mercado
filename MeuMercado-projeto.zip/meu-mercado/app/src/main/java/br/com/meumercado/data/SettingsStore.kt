package br.com.meumercado.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import br.com.meumercado.domain.AISettings
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.json.JSONObject

private val Context.marketSettings by preferencesDataStore(
    name = "meu_mercado_settings", corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() }
)

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val key = stringPreferencesKey("ai_settings_v1")
    val settings: Flow<AISettings> = context.marketSettings.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { preferences -> preferences[key]?.let { JsonCodec.settings(JSONObject(it)) } ?: AISettings() }

    suspend fun save(settings: AISettings) {
        context.marketSettings.edit { it[key] = JsonCodec.settings(settings).toString() }
    }

    /** Restore settings even if the caller was cancelled during a database transaction. */
    internal suspend fun restoreAfterFailure(settings: AISettings, error: Exception) {
        try { withContext(NonCancellable) { save(settings) } }
        catch (rollbackError: Exception) { error.addSuppressed(rollbackError) }
    }
}
