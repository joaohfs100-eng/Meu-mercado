package br.com.meumercado.features.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.com.meumercado.domain.*
import br.com.meumercado.ui.*

@Composable fun HomeScreen(state: MarketUiState, vm: MarketViewModel, onLists: () -> Unit, onScan: () -> Unit, onStores: () -> Unit, onReports: () -> Unit, onAi: () -> Unit) {
    var showBudget by rememberSaveable { mutableStateOf(false) }
    val summary = state.summary
    val list = state.activeList
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Compras que cabem no seu bolso", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Planeje, compare e acompanhe sua compra.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (list == null) {
            EmptyState("Vamos começar?", "Cadastre seu mercado e crie uma lista. Seus dados ficam neste aparelho.", "Minhas listas", onLists)
            OutlinedButton(onStores, Modifier.fillMaxWidth()) { Icon(Icons.Default.Store, null); Spacer(Modifier.width(8.dp)); Text("Cadastrar supermercado") }
        } else {
            SectionCard(list.name) {
                Text(state.snapshot.stores.firstOrNull { it.id == list.storeId }?.name ?: "Mercado ainda não selecionado")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onStores) { Text("Mercados") }
                    TextButton(onClick = { showBudget = true }) { Text("Definir orçamento") }
                }
            }
            SectionCard("Orçamento da compra") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    val primary = MaterialTheme.colorScheme.primary
                    val background = MaterialTheme.colorScheme.surfaceContainerHighest
                    val warning = MaterialTheme.colorScheme.error
                    val percent = summary.usedPercent.toFloat().coerceIn(0f, 100f)
                    Canvas(Modifier.size(86.dp).semantics { contentDescription = "${summary.usedPercent.setScale(0, java.math.RoundingMode.DOWN).toPlainString()} por cento do limite usado" }) {
                        drawArc(background, -90f, 360f, false, style = Stroke(14.dp.toPx()))
                        drawArc(if (summary.remainingCents < 0) warning else primary, -90f, percent * 3.6f, false, style = Stroke(14.dp.toPx()))
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${summary.usedPercent.setScale(0, java.math.RoundingMode.DOWN).toPlainString()}% do limite usado", style = MaterialTheme.typography.titleMedium)
                        Text("Saldo operacional", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Money.format(summary.remainingCents), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                            color = if (summary.remainingCents < 0) MaterialTheme.colorScheme.error else primary)
                    }
                }
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Metric("Orçamento total", Money.format(state.activeBudget.totalCents), Modifier.weight(1f))
                    Metric("Limite operacional", Money.format(summary.operationalLimitCents), Modifier.weight(1f))
                }
                val margin = state.activeBudget.totalCents - summary.operationalLimitCents
                Text("Reserva e limites: ${Money.format(margin)} • margem ${state.activeBudget.safetyPercent}% + ${Money.format(state.activeBudget.safetyCents)}",
                    style = MaterialTheme.typography.bodySmall)
                summary.alert?.let { threshold ->
                    Text(if (summary.remainingCents < 0) "⚠ Limite ultrapassado. Revise os itens da compra." else "⚠ Você já utilizou $threshold% do limite.", color = if (summary.remainingCents < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary)
                }
            }
            SectionCard("Compra em tempo real") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Metric("Já no carrinho", Money.format(summary.cartCents), Modifier.weight(1f))
                    Metric("Pendentes (estimativa)", Money.format(summary.pendingCents), Modifier.weight(1f))
                }
                Metric("Projeção da compra inteira", Money.format(summary.projectedCents), warning = summary.projectedCents > summary.operationalLimitCents)
                Text("${summary.cartCount} produtos no carrinho • ${summary.pendingCount} produtos faltando")
                val withoutPrice = state.activeItems.count { (it.status == ItemStatus.PENDING && it.estimatedPriceCents == 0L) || (it.status == ItemStatus.IN_CART && it.actualPriceCents == null && it.estimatedPriceCents == 0L) }
                if (withoutPrice > 0) Text("⚠ $withoutPrice produtos sem preço; a projeção está incompleta.", color = MaterialTheme.colorScheme.error)
                LinearProgressIndicator(progress = { if (summary.cartCount + summary.pendingCount == 0) 0f else summary.cartCount.toFloat() / (summary.cartCount + summary.pendingCount) }, modifier = Modifier.fillMaxWidth())
            }
            val optimization = remember(state.snapshot, state.settings) { RecommendationEngine().optimize(state.activeItems, state.snapshot.products, state.snapshot.prices, state.settings, list.storeId) }
            SectionCard("Meu Mercado IA • ${state.settings.mode.portuguese()}") {
                Text("Economia potencial com dados locais: ${Money.format((optimization.originalCents - optimization.optimizedCents).coerceAtLeast(0))}")
                Text("Preços registrados têm data e origem; confirme a disponibilidade no mercado.", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = onAi) { Text("Ver recomendações") }
            }
            Button(onScan, Modifier.fillMaxWidth()) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Escanear produto ou etiqueta") }
        }
        SectionCard("Acompanhe seus gastos") {
            val totalTaxes = state.snapshot.taxes.sumOf { it.amountCents }
            Text(if (state.snapshot.taxes.isEmpty()) "Tributos não informados." else "Tributos registrados: ${Money.format(totalTaxes)} (não somados novamente aos preços)")
            OutlinedButton(onReports, Modifier.fillMaxWidth()) { Text("Relatórios e gráficos") }
        }
        Spacer(Modifier.height(8.dp))
    }
    if (showBudget) BudgetDialog(state.activeBudget, onDismiss = { showBudget = false }) { vm.saveBudget(it); showBudget = false }
}
