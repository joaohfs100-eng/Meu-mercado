package br.com.meumercado.features.scanner

import org.junit.Assert.*
import org.junit.Test

class FiscalQrValidatorTest {
    @Test fun acceptsOnlyOfficialHttpsUrlsForConfirmation() {
        assertNotNull(FiscalQrValidator.approvedUrl("https://www.nfce.fazenda.sp.gov.br/qrcode?p=123"))
        assertNull(FiscalQrValidator.approvedUrl("http://www.nfce.fazenda.sp.gov.br/qrcode?p=123"))
        assertNull(FiscalQrValidator.approvedUrl("https://fazenda.sp.gov.br.evil.example/qrcode"))
        assertNull(FiscalQrValidator.approvedUrl("https://user@fazenda.sp.gov.br/qrcode"))
        assertNull(FiscalQrValidator.approvedUrl("javascript:alert(1)"))
        assertNull(FiscalQrValidator.approvedUrl("texto não é QR fiscal"))
    }
}
