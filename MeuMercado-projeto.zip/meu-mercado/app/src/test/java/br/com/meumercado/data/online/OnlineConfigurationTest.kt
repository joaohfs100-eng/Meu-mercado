package br.com.meumercado.data.online

import br.com.meumercado.domain.MeasurementUnit
import br.com.meumercado.domain.PriceSource
import kotlinx.coroutines.runBlocking
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test

class OnlineConfigurationTest {
    @Test fun requiresHttpsAndDoesNotAcceptInlineCredentials() {
        assertNull(GatewayConfiguration.endpoint("http://example.com", "chat"))
        assertNull(GatewayConfiguration.endpoint("https://secret@example.com", "chat"))
        assertNull(GatewayConfiguration.endpoint("https://example.com?key=private", "chat"))
        assertEquals("https://example.com/api/chat", GatewayConfiguration.endpoint("https://example.com/api", "chat"))
        assertEquals("https://example.com/api/chat", GatewayConfiguration.endpoint("https://example.com/api/chat", "chat"))
        assertEquals("https://example.com/api/chat", GatewayConfiguration.endpoint("https://example.com/api/chat/", "chat"))
        assertEquals("https://example.com/api/prices", GatewayConfiguration.endpoint("https://example.com/api/chat", "prices"))
    }

    @Test fun neverFollowsRedirectsToDifferentHostsOrHttp() {
        val client = secureHttpClient()
        assertFalse(client.followRedirects)
        assertFalse(client.followSslRedirects)
    }

    @Test fun invalidQueryIsRejectedBeforeNetworkOrAndroidJson() = runBlocking {
        assertTrue(OnlineAiGateway().ask("https://example.com", "", true) is OnlineAiResult.Error)
        assertTrue(OnlineAiGateway().ask("https://example.com", "a".repeat(4001), true) is OnlineAiResult.Error)
        assertTrue(GatewayPriceProvider("https://example.com", true).search("a".repeat(501)) is PriceProviderResult.Error)
    }

    @Test fun boundedResponseReaderRejectsOversizedContent() {
        "{\"answer\":\"Resposta real\"}".toResponseBody().use { body ->
            assertEquals("{\"answer\":\"Resposta real\"}", readLimitedBody(body))
        }
        "a".repeat(MAX_RESPONSE_BYTES.toInt() + 1).toResponseBody().use { body ->
            assertNull(readLimitedBody(body))
        }
    }

    @Test fun absentConsentNeverConnectsAndMissingConfigurationIsExplicit() = runBlocking {
        assertTrue(OnlineAiGateway().ask("https://example.com", "Quanto posso gastar?", false) is OnlineAiResult.Unavailable)
        assertTrue(OnlineAiGateway().ask("", "Quanto posso gastar?", true) is OnlineAiResult.Unavailable)
        assertTrue(LocalOnlyPriceProvider().search("Arroz") is PriceProviderResult.Unavailable)
        assertTrue(GatewayPriceProvider("https://example.com", false).search("Arroz") is PriceProviderResult.Unavailable)
    }

    @Test fun rejectsInvalidAndFutureExternalPrices() {
        val valid = ExternalPrice("Arroz", "7891000000010", "Mercado", 2390, "5", MeasurementUnit.KG, 1_000,
            "https://example.com/arroz", "Catálogo autorizado", PriceSource.ADVERTISED)
        assertTrue(ExternalPriceValidator.isValid(valid, 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(priceCents = -1), 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(sourceUrl = "http://example.com"), 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(quantity = "0"), 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(observedAt = 999_999_999), 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(sourceName = ""), 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(quantity = "1e-2147483647"), 2_000))
        assertFalse(ExternalPriceValidator.isValid(valid.copy(productName = "Arroz\nPreço falso"), 2_000))
    }
}
