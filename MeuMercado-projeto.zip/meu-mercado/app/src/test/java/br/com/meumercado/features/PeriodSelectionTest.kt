package br.com.meumercado.features

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class PeriodSelectionTest {
    private fun timestamp(date: String) = LocalDate.parse(date).atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    @Test fun brazilianDatesIncludeBothBoundaryDays() {
        val period = PeriodSelection("Personalizado", "01/06/2024", "30/06/2024")
        assertNull(period.error())
        assertTrue(period.accepts(timestamp("2024-06-01")))
        assertTrue(period.accepts(timestamp("2024-06-30")))
        assertFalse(period.accepts(timestamp("2024-05-31")))
        assertFalse(period.accepts(timestamp("2024-07-01")))
    }

    @Test fun rejectsImpossibleAndReversedDates() {
        assertNotNull(PeriodSelection("Personalizado", "31/02/2024", "01/03/2024").error())
        assertFalse(PeriodSelection("Personalizado", "31/02/2024", "01/03/2024").accepts(timestamp("2024-03-01")))
        assertNotNull(PeriodSelection("Personalizado", "30/06/2024", "01/06/2024").error())
    }

    @Test fun acceptsIsoDatesFromPreviouslySavedFilters() {
        val period = PeriodSelection("Personalizado", "2024-06-01", "2024-06-30")
        assertNull(period.error())
        assertTrue(period.accepts(timestamp("2024-06-15")))
    }
}
