package br.com.meumercado.features.settings

import br.com.meumercado.domain.AppSnapshot
import br.com.meumercado.domain.HistoryItem
import br.com.meumercado.domain.MeasurementUnit
import br.com.meumercado.domain.ShoppingHistory
import br.com.meumercado.domain.TaxRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryCsvExporterTest {
    private val item = HistoryItem("Arroz", "Marca", "Alimentação", 1, "1,5", MeasurementUnit.KG, 1000, 100, 1400, 1500)
    private val purchase = ShoppingHistory(id = 1, listName = "Semana", storeId = 1, storeName = "Mercado", completedAt = 1_700_000_000_000, items = listOf(item), totalCents = 1400, budgetCents = 2000, estimatedCents = 1500)

    @Test fun preservesExactPaidTotalAndSeparatesDocumentedAndEstimatedTaxes() {
        val snapshot = AppSnapshot(history = listOf(purchase), taxes = listOf(
            TaxRecord(historyId = 1, amountCents = 350, documented = true, includedInPrice = true),
            TaxRecord(historyId = 1, amountCents = 100, documented = false, includedInPrice = true)))
        val csv = HistoryCsvExporter.export(snapshot)
        assertTrue(csv.contains("\"1,5\";\"kg\";\"10.00\";\"1.00\";\"14.00\";\"14.00\";\"20.00\";\"3.50\";\"1.00\""))
        assertFalse(csv.contains("\"18.50\""))
        assertEquals(1400L, snapshot.history.single().totalCents)
    }

    @Test fun neutralizesSpreadsheetFormulaAndEscapesQuotedNames() {
        val csv = HistoryCsvExporter.export(AppSnapshot(history = listOf(purchase.copy(
            storeName = "=HYPERLINK(\"https://example.com\")", items = listOf(item.copy(productName = "Sabão; \"Premium\"", brand = "@formula"))))))
        assertTrue(csv.contains("\"'=HYPERLINK(\"\"https://example.com\"\")\""))
        assertTrue(csv.contains("\"Sabão; \"\"Premium\"\"\""))
        assertTrue(csv.contains("\"'@formula\""))
        assertEquals('\uFEFF', csv.first())
    }

    @Test fun exportsHeaderWhenHistoryIsEmpty() {
        val csv = HistoryCsvExporter.export(AppSnapshot())
        assertTrue(csv.contains("tributos_documentados_rs;tributos_estimados_rs"))
        assertEquals(1, csv.lines().count { it.isNotEmpty() })
    }
}
