package br.com.meumercado.data.online

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Estes testes usam org.json REAL do Android; não dependem dos stubs dos testes JVM. */
@RunWith(AndroidJUnit4::class)
class OnlineResponseInstrumentedTest {
    @Test fun validatesActualJsonAnswers() {
        assertEquals("Resposta do backend", GatewayResponseParser.answer("{\"answer\":\" Resposta do backend \"}"))
        assertNull(GatewayResponseParser.answer("{\"answer\":null}"))
        assertNull(GatewayResponseParser.answer("{\"answer\":true}"))
        assertNull(GatewayResponseParser.answer("{\"answer\":123}"))
        assertNull(GatewayResponseParser.answer("{\"answer\":\"\"}"))
        assertNull(GatewayResponseParser.answer("não é JSON"))
    }

    @Test fun refusesFractionalCentsAndInvalidPriceMetadata() {
        fun quote() = JSONObject().put("productName", "Arroz").put("storeName", "Mercado")
            .put("priceCents", 2390).put("quantity", "5").put("unit", "KG").put("observedAt", 1000L)
            .put("sourceUrl", "https://example.com/arroz").put("sourceName", "Catálogo autorizado").put("kind", "ADVERTISED")
        assertNotNull(GatewayPriceParser.quote(quote(), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("priceCents", 2390.5), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("priceCents", "2390"), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("quantity", 5), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("sourceName", JSONObject.NULL), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("productName", 123), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("observedAt", 1000.5), 2000))
        assertNull(GatewayPriceParser.quote(quote().put("unit", "TON"), 2000))
    }
}
