package br.com.meumercado.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import br.com.meumercado.database.MarketDatabase
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith

/** Builds the complete v1 schema and lets Room validate every table after the real migration. */
@RunWith(AndroidJUnit4::class)
class DatabaseMigrationTest {
    @Test fun migrationOneToTwoPreservesCatalogueAndInitializesAcceptance() = runBlocking {
        val context: Context = ApplicationProvider.getApplicationContext()
        val filename = "migration-1-2-test.db"
        context.deleteDatabase(filename)
        val reference = Room.inMemoryDatabaseBuilder(context, MarketDatabase::class.java).build()
        val declarations = mutableListOf<Pair<String, String>>()
        try {
            reference.openHelper.writableDatabase.query(
                "SELECT name, sql FROM sqlite_master WHERE type IN ('table','index') AND sql IS NOT NULL ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END"
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    val name = cursor.getString(0)
                    if (name in MarketDatabase.TABLES || name.startsWith("index_")) declarations += name to cursor.getString(1)
                }
            }
        } finally { reference.close() }
        val path = context.getDatabasePath(filename)
        path.parentFile?.mkdirs()
        SQLiteDatabase.openOrCreateDatabase(path, null).use { old ->
            declarations.forEach { (name, declaration) ->
                val v1 = if (name == "products") declaration.replace(Regex(",\\s*`accepted`\\s+INTEGER\\s+NOT NULL\\s+DEFAULT\\s+0"), "") else declaration
                if (name == "products") check(v1 != declaration) { "Coluna accepted não localizada no esquema de referência." }
                old.execSQL(v1)
            }
            old.execSQL("INSERT INTO product_categories (id, name) VALUES (1, 'Alimentação')")
            old.execSQL("""INSERT INTO products (id, name, brandId, categoryId, barcode, photoUri, saleUnit,
                packageQuantity, packageUnit, equivalenceKey, characteristics, restrictions, favorite,
                neverSubstitute, notes) VALUES (42, 'Produto da versão 1', NULL, 1, NULL, NULL, 'UNIT',
                '1', 'UNIT', 'arroz', '[]', '[]', 0, 0, '')""")
            old.version = 1
        }
        val upgraded = Room.databaseBuilder(context, MarketDatabase::class.java, filename)
            .addMigrations(MarketDatabase.MIGRATION_1_2).build()
        try {
            val product = upgraded.dao().products().single()
            assertEquals(42L, product.id)
            assertEquals("Produto da versão 1", product.name)
            assertFalse(product.accepted)
            assertEquals(2, upgraded.openHelper.writableDatabase.version)
        } finally { upgraded.close(); context.deleteDatabase(filename) }
    }
}
