package br.com.meumercado.ui

import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import br.com.meumercado.data.RoomMarketRepository
import br.com.meumercado.data.SettingsStore
import br.com.meumercado.database.MarketDatabase
import br.com.meumercado.domain.*
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Verifica a navegação e a atualização visível a partir de uma gravação real no Room. */
@RunWith(AndroidJUnit4::class)
class NavigationAndCartTest {
    @get:Rule val compose = createComposeRule()
    private lateinit var database: MarketDatabase
    private lateinit var vm: MarketViewModel
    private var itemId = 0L

    @Before fun setup() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, MarketDatabase::class.java).build()
        val repository = RoomMarketRepository(database, SettingsStore(context))
        repository.eraseAll()
        val store = repository.saveStore(Store(name = "Mercado de teste"))
        val list = repository.saveList(ShoppingList(name = "Lista semanal", storeId = store))
        val product = repository.saveProduct(Product(name = "Banana", saleUnit = MeasurementUnit.KG))
        itemId = repository.saveItem(ShoppingListItem(listId = list, productId = product, quantity = "0.75", estimatedPriceCents = 1200))
        repository.saveBudget(BudgetSettings(list, totalCents = 50000, safetyCents = 5000))
        repository.saveSettings(AISettings(activeListId = list))
        vm = MarketViewModel(repository)
    }

    @After fun cleanup() { database.close() }

    @Test fun cartUpdatesImmediatelyAndNavigationKeepsPurchaseData() {
        compose.setContent { MarketContent(vm) }
        compose.waitUntil(10_000) { !vm.state.value.loading && vm.state.value.activeList != null }
        compose.onNodeWithTag("nav_cart").performClick()
        compose.onNodeWithTag("cart_toggle_$itemId").performScrollTo().performClick()
        compose.onNodeWithText("Confirmar preço e adicionar").performClick()
        compose.waitUntil(10_000) { vm.state.value.summary.cartCents == 900L }
        compose.onNodeWithText(Money.format(44_100)).assertIsDisplayed()
        compose.onNodeWithTag("nav_lists").performClick()
        compose.onNodeWithText("Produtos • Lista semanal").performScrollTo().assertIsDisplayed()
        compose.onNodeWithTag("nav_home").performClick()
        compose.onNodeWithText("Lista semanal").assertIsDisplayed()
        compose.onNodeWithText(Money.format(44_100)).assertIsDisplayed()
        compose.onNodeWithTag("nav_history").performClick()
        compose.onNodeWithTag("nav_ai").performClick()
        compose.onNodeWithText("Seu assistente de economia, com dados reais do aparelho.").assertIsDisplayed()
    }
}
