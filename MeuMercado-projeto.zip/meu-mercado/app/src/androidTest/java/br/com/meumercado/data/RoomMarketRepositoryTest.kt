package br.com.meumercado.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import br.com.meumercado.database.MarketDatabase
import br.com.meumercado.domain.*
import java.math.BigDecimal
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RoomMarketRepositoryTest {
    private lateinit var context: Context
    private lateinit var database: MarketDatabase
    private lateinit var repository: RoomMarketRepository
    private lateinit var store: SettingsStore

    @Before fun setup() = runBlocking {
        context = ApplicationProvider.getApplicationContext()
        store = SettingsStore(context)
        database = Room.inMemoryDatabaseBuilder(context, MarketDatabase::class.java).build()
        repository = RoomMarketRepository(database, store)
        repository.eraseAll()
    }
    @After fun cleanup() { database.close() }

    @Test fun savedItemsEmitActualCartAndEstimatedPending() = runBlocking {
        val listId = repository.saveList(ShoppingList(name = "Semana"))
        val productId = repository.saveProduct(Product(name = "Banana", saleUnit = MeasurementUnit.KG))
        repository.saveBudget(BudgetSettings(listId, totalCents = 50_000, safetyCents = 5_000))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, quantity = "0,75", estimatedPriceCents = 1200, actualPriceCents = 1000, discountCents = 50, status = ItemStatus.IN_CART))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, quantity = "2", estimatedPriceCents = 1200, actualPriceCents = 1000))
        val state = repository.snapshot.first()
        val totals = BudgetCalculator.calculate(state.items, state.budgets.single())
        assertEquals(700L, totals.cartCents)
        assertEquals(2400L, totals.pendingCents)
        assertEquals(3100L, totals.projectedCents)
        assertEquals(44_300L, totals.remainingCents)
    }

    @Test fun barcodeDeduplicatesAndPreservesRelationships() = runBlocking {
        val first = repository.saveProduct(Product(name = "Arroz", barcode = "7891234567895", category = "Alimentação", brand = "Marca", tags = setOf("Essencial"), restrictions = setOf("Sem glúten"), neverSubstitute = true))
        val second = repository.saveProduct(Product(name = "Arroz branco", barcode = "7891234567895", category = "Alimentação", brand = "Marca", tags = setOf("Essencial", "Favoritos")))
        val products = repository.snapshot.first().products
        assertEquals(first, second)
        assertEquals(1, products.size)
        assertEquals(setOf("Essencial"), products.single().tags)
        assertTrue(products.single().neverSubstitute)
        assertEquals(setOf("Sem glúten"), products.single().restrictions)
        repository.saveProduct(products.single().copy(name = "Arroz branco", tags = setOf("Essencial", "Favoritos")))
        assertEquals(setOf("Essencial", "Favoritos"), repository.snapshot.first().products.single().tags)
    }

    @Test fun itemUpdatesRecordStorePriceAndUndoRestoresPreviousState() = runBlocking {
        val storeId = repository.saveStore(Store(name = "Mercado A"))
        val listId = repository.saveList(ShoppingList(name = "Semana", storeId = storeId))
        val productId = repository.saveProduct(Product(name = "Café"))
        val itemId = repository.saveItem(ShoppingListItem(listId = listId, productId = productId, estimatedPriceCents = 1500))
        repository.saveItem(repository.snapshot.first().items.single().copy(actualPriceCents = 1200, status = ItemStatus.IN_CART))
        assertEquals(1200L, repository.snapshot.first().prices.single().priceCents)
        assertTrue(repository.undo())
        val snapshot = repository.snapshot.first()
        assertEquals(itemId, snapshot.items.single().id)
        assertEquals(ItemStatus.PENDING, snapshot.items.single().status)
        assertTrue(snapshot.prices.isEmpty())
    }

    @Test fun substitutionRequiresCompatibilityAndCanBeUndone() = runBlocking {
        val storeId = repository.saveStore(Store(name = "Mercado"))
        val listId = repository.saveList(ShoppingList(name = "Lista", storeId = storeId))
        val first = repository.saveProduct(Product(name = "Arroz A", category = "Alimentação", equivalenceKey = "arroz-branco"))
        val second = repository.saveProduct(Product(name = "Arroz B", category = "Alimentação", equivalenceKey = "arroz-branco"))
        val item = repository.saveItem(ShoppingListItem(listId = listId, productId = first, estimatedPriceCents = 2990))
        val alternative = Alternative(repository.snapshot.first().products.first { it.id == second }, PriceObservation(productId = second, storeId = storeId, priceCents = 2390), "1", 2390, BigDecimal("2390"), "un", 600, BigDecimal("20"), "Preço local menor")
        repository.substitute(item, alternative)
        assertEquals(second, repository.snapshot.first().items.single().productId)
        assertEquals(600L, repository.snapshot.first().decisions.single().savingsCents)
        assertTrue(repository.undo())
        assertEquals(first, repository.snapshot.first().items.single().productId)
        assertTrue(repository.snapshot.first().decisions.isEmpty())
    }

    @Test fun historyFreezesOnlyBoughtProductsAndSurvivesCatalogueChangesAndListDeletion() = runBlocking {
        val listId = repository.saveList(ShoppingList(name = "Feira"))
        val productId = repository.saveProduct(Product(name = "Banana", brand = "A", category = "Frutas", saleUnit = MeasurementUnit.KG))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, quantity = "0.75", estimatedPriceCents = 1200, actualPriceCents = 1000, discountCents = 50, status = ItemStatus.IN_CART))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, quantity = "2", estimatedPriceCents = 1200))
        repository.finishPurchase(listId)
        repository.saveProduct(repository.snapshot.first().products.single().copy(name = "Produto renomeado", brand = "B"))
        val state = repository.snapshot.first()
        assertEquals(1, state.history.single().items.size)
        assertEquals("Banana", state.history.single().items.single().productName)
        assertEquals("A", state.history.single().items.single().brand)
        assertEquals(700L, state.history.single().totalCents)
        assertEquals(1, state.items.count { it.status == ItemStatus.PENDING })
        assertFalse(repository.undo())
        repository.deleteList(listId)
        assertEquals(700L, repository.snapshot.first().history.single().totalCents)
    }

    @Test fun includedTaxesNeverIncreasePurchaseTotalAndMissingTaxStaysMissing() = runBlocking {
        val list = repository.saveList(ShoppingList(name = "Lista"))
        val product = repository.saveProduct(Product(name = "Sabão"))
        repository.saveItem(ShoppingListItem(listId = list, productId = product, estimatedPriceCents = 500, actualPriceCents = 500, status = ItemStatus.IN_CART))
        val history = repository.finishPurchase(list)
        assertTrue(repository.snapshot.first().taxes.isEmpty())
        repository.saveTax(TaxRecord(historyId = history, amountCents = 150, includedInPrice = true))
        assertEquals(500L, repository.snapshot.first().history.single().totalCents)
    }

    @Test fun backupRestoresIdsRelationshipsHistoryAndDataStoreSettings() = runBlocking {
        val storeId = repository.saveStore(Store(name = "Meu mercado"))
        val listId = repository.saveList(ShoppingList(name = "Semana", storeId = storeId))
        val product = repository.saveProduct(Product(name = "Arroz", category = "Alimentação", brand = "Preferida", tags = setOf("Essencial")))
        repository.saveItem(ShoppingListItem(listId = listId, productId = product, estimatedPriceCents = 2390, actualPriceCents = 2390, status = ItemStatus.IN_CART))
        repository.saveBudget(BudgetSettings(listId, 10000, 1000))
        repository.saveSettings(AISettings(mode = RecommendationMode.FAVORITE_BRANDS, favoriteBrands = mapOf("Alimentação" to setOf("Preferida")), activeListId = listId))
        val historyId = repository.finishPurchase(listId)
        repository.saveTax(TaxRecord(historyId = historyId, amountCents = 500))
        val before = repository.snapshot.first()
        val beforeSettings = repository.settings.first()
        val backup = repository.exportBackup()
        repository.eraseAll()
        assertTrue(repository.snapshot.first().products.isEmpty())
        repository.restoreBackup(backup)
        assertEquals(before, repository.snapshot.first())
        assertEquals(beforeSettings, repository.settings.first())
    }

    @Test fun invalidBackupRollsBackAllTablesAndSettings() = runBlocking {
        val list = repository.saveList(ShoppingList(name = "Importação"))
        val product = repository.saveProduct(Product(name = "Maçã"))
        repository.saveItem(ShoppingListItem(listId = list, productId = product, estimatedPriceCents = 500))
        val before = repository.snapshot.first()
        val json = JSONObject(repository.exportBackup())
        json.getJSONObject("tables").getJSONArray("shopping_list_items").getJSONObject(0).put("quantity", "-1")
        var rejected = false
        try { repository.restoreBackup(json.toString()) } catch (_: IllegalArgumentException) { rejected = true }
        assertTrue(rejected)
        assertEquals(before, repository.snapshot.first())
    }

    @Test fun dataAndModePersistAfterDatabaseReopens() = runBlocking {
        val filename = "persistence-test.db"
        context.deleteDatabase(filename)
        val persistent = Room.databaseBuilder(context, MarketDatabase::class.java, filename).addMigrations(MarketDatabase.MIGRATION_1_2).build()
        val first = RoomMarketRepository(persistent, store)
        val productId = first.saveProduct(Product(name = "Persistente"))
        first.saveSettings(AISettings(mode = RecommendationMode.BEST_VALUE))
        persistent.close()
        val reopened = Room.databaseBuilder(context, MarketDatabase::class.java, filename).addMigrations(MarketDatabase.MIGRATION_1_2).build()
        try {
            val second = RoomMarketRepository(reopened, store)
            assertEquals(productId, second.snapshot.first().products.single().id)
            assertEquals(RecommendationMode.BEST_VALUE, second.settings.first().mode)
        } finally { reopened.close(); context.deleteDatabase(filename) }
    }

    @Test fun deletingStorePreservesHistoricalNameAndDetachesLiveReferences() = runBlocking {
        val storeId = repository.saveStore(Store(name = "Mercado histórico"))
        val listId = repository.saveList(ShoppingList(name = "Lista", storeId = storeId))
        val productId = repository.saveProduct(Product(name = "Arroz"))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, actualPriceCents = 1000, status = ItemStatus.IN_CART))
        repository.finishPurchase(listId)
        repository.deleteStore(storeId)
        val state = repository.snapshot.first()
        assertTrue(state.stores.isEmpty())
        assertTrue(state.prices.isEmpty())
        assertNull(state.lists.single().storeId)
        assertNull(state.history.single().storeId)
        assertEquals("Mercado histórico", state.history.single().storeName)
        assertEquals(1000L, state.history.single().totalCents)
    }

    @Test fun learnedPreferencesCanBeResetWithoutDeletingPurchases() = runBlocking {
        val listId = repository.saveList(ShoppingList(name = "Lista"))
        val productId = repository.saveProduct(Product(name = "Café", brand = "Aceita"))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, estimatedPriceCents = 1000, actualPriceCents = 1000, status = ItemStatus.IN_CART))
        repository.finishPurchase(listId)
        assertTrue(repository.snapshot.first().products.single().accepted)
        repository.clearLearnedPreferences()
        assertFalse(repository.snapshot.first().products.single().accepted)
        assertEquals(1, repository.snapshot.first().history.size)
    }

    @Test fun cartRequiresConfirmedActualPriceAndRejectsOnlyAnEstimate() = runBlocking {
        val listId = repository.saveList(ShoppingList(name = "Lista"))
        val productId = repository.saveProduct(Product(name = "Arroz"))
        var rejected = false
        try {
            repository.saveItem(ShoppingListItem(listId = listId, productId = productId, estimatedPriceCents = 1000, status = ItemStatus.IN_CART))
        } catch (_: IllegalArgumentException) { rejected = true }
        assertTrue(rejected)
        assertTrue(repository.snapshot.first().items.isEmpty())
    }

    @Test fun duplicatingCompletedListCreatesReusablePendingPlan() = runBlocking {
        val listId = repository.saveList(ShoppingList(name = "Lista semanal", cadence = "Semanal"))
        val productId = repository.saveProduct(Product(name = "Café"))
        repository.saveBudget(BudgetSettings(listId, totalCents = 10000, safetyCents = 1000))
        repository.saveItem(ShoppingListItem(listId = listId, productId = productId, estimatedPriceCents = 1200, actualPriceCents = 1000, discountCents = 100, status = ItemStatus.IN_CART))
        repository.finishPurchase(listId)
        val duplicate = repository.duplicateList(listId)
        val state = repository.snapshot.first()
        val item = state.items.single { it.listId == duplicate }
        assertEquals(ItemStatus.PENDING, item.status)
        assertEquals(productId, item.productId)
        assertEquals(1200L, item.estimatedPriceCents)
        assertNull(item.actualPriceCents)
        assertEquals(0L, item.discountCents)
        assertEquals(10000L, state.budgets.single { it.listId == duplicate }.totalCents)
        assertEquals("Semanal", state.lists.single { it.id == duplicate }.cadence)
    }

    @Test fun cartSubstitutionCannotTurnAnotherStoresPriceIntoPaidPrice() = runBlocking {
        val currentStore = repository.saveStore(Store(name = "Mercado atual"))
        val otherStore = repository.saveStore(Store(name = "Outro mercado"))
        val listId = repository.saveList(ShoppingList(name = "Lista", storeId = currentStore))
        val productId = repository.saveProduct(Product(name = "Arroz A", equivalenceKey = "arroz-branco"))
        val alternativeId = repository.saveProduct(Product(name = "Arroz B", equivalenceKey = "arroz-branco"))
        val itemId = repository.saveItem(ShoppingListItem(listId = listId, productId = productId, estimatedPriceCents = 1000, actualPriceCents = 1000, status = ItemStatus.IN_CART))
        val alternative = Alternative(repository.snapshot.first().products.first { it.id == alternativeId },
            PriceObservation(productId = alternativeId, storeId = otherStore, priceCents = 700), "1", 700,
            BigDecimal("7"), "un", 300, BigDecimal("30"), "Preço registrado em outro mercado")
        var rejected = false
        try { repository.substitute(itemId, alternative) } catch (_: IllegalArgumentException) { rejected = true }
        assertTrue(rejected)
        assertEquals(productId, repository.snapshot.first().items.single().productId)
        assertTrue(repository.snapshot.first().decisions.isEmpty())
    }
}
