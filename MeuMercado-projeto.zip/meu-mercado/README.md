# Meu Mercado — Compras Inteligentes

Aplicativo Android nativo, em português brasileiro, sem login, com dados locais. Kotlin, Compose/Material 3, MVVM, domínio independente, Repository Pattern, Room, DataStore, Hilt, Coroutines/StateFlow, Navigation Compose, CameraX, ML Kit embarcado e WorkManager. Dinheiro em centavos e quantidades em `BigDecimal`.

## Estado da entrega

O código das funcionalidades abaixo está implementado e conectado ao repositório local. **Este ambiente não possui SDK Android nem uma distribuição Gradle no cache. O acesso necessário aos downloads não foi concluído. Não foi possível compilar o aplicativo, executar os testes Kotlin/Android ou produzir um APK nesta sessão.** A revisão estática e as verificações estruturais não substituem a compilação nem a validação em um celular. Consulte [VALIDACAO.md](docs/VALIDACAO.md) para os testes criados e seus estados.

Há scripts `gradlew`/`gradlew.bat`, propriedades do Wrapper e um bootstrap Java compilado, com código-fonte auditável. **O JAR oficial `gradle-wrapper.jar` não foi obtido neste ambiente.** O bootstrap baixa a distribuição oficial 8.11.1 via HTTPS, verifica SHA-256 antes de extrair e repassa os comandos ao Gradle. Depois da primeira execução com rede, execute `./gradlew wrapper --gradle-version 8.11.1` para gerar o Wrapper oficial completo. Também é possível usar uma instalação local do Gradle 8.11.1. O bootstrap não faz parte do APK.

Foram criados **88 métodos de teste Kotlin**: 57 no domínio JVM, 13 testes JVM do app e 18 testes instrumentados Android. Essas suítes não foram executadas. As **8 verificações SQLite locais passaram**. [RESULTADOS.md](docs/RESULTADOS.md) registra o que foi efetivamente executado.

## Funcionalidades implementadas

- Cinco abas: Início, Minhas Listas, Carrinho, Histórico e Meu Mercado IA; mercados, configurações, relatórios e scanner acessíveis pela navegação.
- Listas múltiplas, edição, duplicação, exclusão confirmada, arquivamento, favoritos, modelos, periodicidade semanal/mensal e compartilhamento de texto pelo Android, inclusive WhatsApp quando instalado.
- Produtos com marca, categoria, etiquetas livres, código de barras, foto via seletor Android, embalagem, unidade de venda, quantidades fracionárias, prioridade, notas, restrições e proteção contra substituição. Busca e filtros no catálogo, produtos do histórico e pesquisas recentes.
- Carrinho com preços confirmados, desconto total por linha, indisponibilidade, remoção, edição, desfazer persistente e finalização mesmo com produtos pendentes. Finalizar congela os itens do carrinho e mantém os pendentes na lista.
- Orçamento, margem fixa, margem percentual, limite máximo e alertas por patamar. Os valores do carrinho e dos pendentes aparecem separadamente; alterações chegam à UI pelo `StateFlow`.
- Mercados e preços observados por estabelecimento, data, origem e condição promocional. Comparações apresentam cobertura e lacunas, sem afirmar menor total definitivo quando faltam preços.
- CameraX/ML Kit com modelos embarcados para leitura local de códigos e OCR. Revisão obrigatória antes de salvar; cadastro desconhecido e entrada manual disponíveis. QR NFC-e abre consulta HTTPS oficial após confirmação, sem presumir extração fiscal estruturada.
- Recomendações locais de equivalentes, normalização de kg/g/L/ml/un, quantidade necessária de embalagens, explicações, três perfis persistidos, alternativas, otimização por trocas aprovadas e chat baseado nos dados locais. Os perfis são `MAXIMUM_SAVINGS`, `BEST_VALUE` e `FAVORITE_BRANDS`.
- Histórico com cópias dos nomes, marcas, categorias, unidades, preços e descontos pagos; editar um produto não muda compras concluídas. Preferências aprendidas localmente podem ser redefinidas.
- Tributos documentados ou estimados ligados à compra, revisão antes de salvar, simulação por percentual, recibos vinculados e mensagem “Tributos não informados.” quando necessário. Tributos registrados não são adicionados ao valor dos produtos.
- Relatórios por período/mercado/categoria, totais semanais/mensais/anuais, média, recorrência, comparação planejado/pago, gráficos de barras/linhas, preços e tributos.
- Backup JSON versionado e validado, restauração transacional, CSV, exclusão dos dados, lembretes WorkManager, notificações autorizadas, temas claro/escuro/sistema, textos acessíveis e formulários preservados em rotação.
- Gateway opcional HTTPS para IA e contratos extensíveis de preços. Nenhuma chave privada é embutida, nenhuma loja é apresentada como integrada sem configuração.

## Abrir no Android Studio

1. Instale Android Studio com suporte ao Android Gradle Plugin 8.9.3 ou superior compatível e **JDK 21**. Use um SDK local instalado pelo SDK Manager.
2. Instale Android SDK Platform **35** e Build Tools **35.0.0**. A versão mínima do aparelho é Android 8.0/API 26.
3. Abra esta pasta, que contém `settings.gradle.kts`. Configure o Gradle JDK para 21.
4. Se o IDE não iniciar a sincronização por faltar o JAR oficial do Wrapper, execute o bootstrap no terminal para gerar o Wrapper oficial. É necessário acesso aos repositórios Google/Maven Central e às distribuições Gradle na primeira compilação.
5. O Android Studio pode criar `local.properties` com `sdk.dir`. Esse arquivo é específico do computador e não está no pacote.

As versões de plugins e dependências estão fixadas em `build.gradle.kts` e `app/build.gradle.kts`: AGP 8.9.3, Gradle 8.11.1, Kotlin 2.1.20, Compose BOM 2025.04.01, Room 2.7.1, Hilt 2.56.2, DataStore 1.1.4, CameraX 1.4.2, ML Kit código 17.3.0/OCR 16.0.1.

## Compilar e instalar

Linux/macOS:

```sh
chmod +x gradlew
./gradlew wrapper --gradle-version 8.11.1
./gradlew :domain:test :app:testDebugUnitTest :app:assembleDebug
```

Windows: substitua `./gradlew` por `gradlew.bat`. Se já possui Gradle 8.11.1 instalado, pode usar `gradle wrapper --gradle-version 8.11.1` e os mesmos comandos seguintes. Após baixar dependências, a compilação pode usar `--offline`.

O APK gerado será `app/build/outputs/apk/debug/app-debug.apk`:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Ou copie o APK para o celular e abra-o, autorizando a instalação pela aplicação que o abriu. O debug usa assinatura de desenvolvimento. Uma versão de distribuição exige assinatura própria; nenhum keystore privado é fornecido.

Para verificações adicionais:

```sh
./gradlew :app:assembleDebugAndroidTest :app:lintDebug
./gradlew :app:connectedDebugAndroidTest
```

O segundo comando exige aparelho/emulador conectado. A leitura óptica precisa de câmera e etiquetas reais; testes do interpretador OCR não comprovam qualidade da captura. A configuração CI em `.github/workflows/android.yml` compila/testa em um runner com SDK; não foi executada nesta sessão. A instrumentação do CI é opcional via `workflow_dispatch`.

## Primeiro uso offline

1. Cadastre um supermercado pelo ícone de mercado.
2. Crie e selecione uma lista, vincule o mercado e defina orçamento/margem.
3. Adicione produtos manualmente ou escaneie código/etiqueta. Confirme os campos reconhecidos.
4. Para produtos pesados, selecione unidade de venda kg ou L e informe quantidade decimal. Para pacotes, use venda em `un` e registre conteúdo, como `5 kg`.
5. Para comparar alternativas, cadastre produtos com **o mesmo grupo de equivalência**, características essenciais compatíveis e restrições verdadeiras. Cadastre/observe preços das alternativas por scanner ou compras. Estimativas da lista não se tornam preços confirmados de mercado automaticamente.
6. Escolha o modo em Configurações → Inteligência Artificial → “Como você prefere economizar?”. Use “Encontrar mais barato” ou “Otimizar minha lista com IA”. Toda troca precisa de confirmação.
7. Ao colocar um produto no carrinho, confirme o preço encontrado. Edite quantidade/desconto se necessário. Acompanhe saldo operacional e projeção separadamente.
8. Finalize a compra. No histórico, informe os tributos da nota se disponíveis. Reabra o app: Room e DataStore preservam os registros.

Não há catálogo inicial com preços inventados. Sem registros comparáveis, o motor informa ausência de dados. Preços históricos servem de referência com data e não garantem preço/disponibilidade atuais. Comprar em outro mercado exige confirmar o preço no mercado da lista ou iniciar outra lista/sessão nesse estabelecimento.

## Regras de cálculo

- Limite operacional = menor valor entre o máximo definido e `orçamento − margem fixa − margem percentual`, limitado a zero. **Se preencher as duas margens, ambas são reservadas.**
- Carrinho usa preço encontrado × quantidade − desconto por linha. Pendentes usam estimativa × quantidade − desconto registrado. Removidos e indisponíveis ficam fora da projeção.
- Subtotais arredondam uma vez para centavos com `HALF_UP`; valores não passam por `Double`. Descontos não podem criar totais negativos.
- Preço de embalagem é normalizado por conteúdo; pacotes necessários são arredondados para cima. Massa e volume não são convertidos entre si sem dados objetivos.
- O modo custo-benefício usa dados de embalagem e preferências explícitas/registradas; não inventa notas de qualidade. Favoritos fora do perfil aparecem como alternativa opcional.
- Tributos são informativos. A simulação é explicitamente estimada; registros incluídos no preço não são somados novamente.

Detalhes: [MOTOR_LOCAL.md](docs/MOTOR_LOCAL.md) e [PERSISTENCIA.md](docs/PERSISTENCIA.md).

## Integrações opcionais e privacidade

Configure um backend HTTPS confiável em Configurações e autorize o processamento externo. O chat envia somente a pergunta digitada e `locale`; não envia automaticamente banco, histórico, fotos ou recibos. O backend precisa implementar `POST /chat` e retornar JSON com `answer`. Ele é responsável por autenticação, autorização, controle de acesso, limites e chaves de provedores. Este projeto não inclui serviço remoto nem credenciais fictícias.

`PriceProvider` permite integração futura autorizada; o padrão usa dados locais. Não há scraping de supermercados. Portais fiscais são consultados no navegador oficial; extração automatizada de NFC-e, CAPTCHA e serviços privados não estão implementados. Veja [INTEGRACOES.md](docs/INTEGRACOES.md).

Câmera e notificações são solicitadas durante o uso. Arquivos/fotos são escolhidos com SAF; não há permissão ampla de armazenamento. O backup JSON contém dados exportados e referências URI de fotos/recibos, não copia seus arquivos de imagem. Ao restaurar em outro aparelho, escolha novamente imagens/recibos inacessíveis. A exclusão local não apaga cópias de backup já exportadas pelo usuário.

## Organização

```text
app/src/main/java/br/com/meumercado/
  data/        Repository, JSON, DataStore, Hilt, gateway e provedores
  database/    Entidades normalizadas, DAO e migração
  ui/          Estado/ViewModel, tema e componentes
  navigation/  Destinos Compose
  features/    Dashboard, listas, produtos, carrinho, IA, scanner e extras
domain/        Modelos, contratos, cálculos, equivalência, assistente, OCR e testes JVM
docs/          Regras, persistência, integrações e validação
```

O domínio não depende de Android; o app depende dos contratos e implementa armazenamento/apresentação. Room exporta seus schemas para `app/schemas` na primeira compilação. A migração v1→v2 adiciona a preferência aprendida `accepted` e tem teste instrumentado. O histórico usa snapshots, evitando alterações retroativas no catálogo.
