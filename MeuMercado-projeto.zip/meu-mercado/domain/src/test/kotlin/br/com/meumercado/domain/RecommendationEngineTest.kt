package br.com.meumercado.domain

import java.math.BigDecimal
import org.junit.Assert.*
import org.junit.Test

class RecommendationEngineTest {
    private val now = 1_700_000_000_000L
    private val engine = RecommendationEngine { now }
    private val original = Product(1, "Arroz branco", "Original", "Alimentação", packageQuantity = "1", packageUnit = MeasurementUnit.KG,
        equivalenceKey = "arroz-branco", essentialCharacteristics = setOf("branco", "tipo 1"))
    private val item = ShoppingListItem(1, 1, 1, estimatedPriceCents = 1000)
    private fun price(id: Long, cents: Long, store: Long = 1) = PriceObservation(productId = id, storeId = store, priceCents = cents, observedAt = now)
    private fun candidate(id: Long, brand: String = "Alternativa", quantity: String = "1", accepted: Boolean = false) =
        original.copy(id = id, brand = brand, packageQuantity = quantity, accepted = accepted)
    private fun alternatives(products: List<Product>, prices: List<PriceObservation>, settings: AISettings = AISettings()) =
        engine.alternatives(item, listOf(original) + products, prices, settings, 1)

    @Test fun `tres modos produzem ordens diferentes usando preferencias reais`() {
        val products = listOf(candidate(2, "Barata"), candidate(3, "Aceita", accepted = true), candidate(4, "Favorita"))
        val prices = listOf(price(2, 600), price(3, 650), price(4, 800))
        val settings = AISettings(favoriteBrands = mapOf("Alimentação" to setOf("Favorita")))
        assertEquals(2L, alternatives(products, prices, settings).first().product.id)
        assertEquals(3L, alternatives(products, prices, settings.copy(mode = RecommendationMode.BEST_VALUE)).first().product.id)
        assertEquals(4L, alternatives(products, prices, settings.copy(mode = RecommendationMode.FAVORITE_BRANDS)).first().product.id)
    }

    @Test fun `marcas diferentes sao opcionais no modo favoritas`() {
        val result = alternatives(listOf(candidate(2)), listOf(price(2, 600)), AISettings(mode = RecommendationMode.FAVORITE_BRANDS,
            favoriteBrands = mapOf("alimentacao" to setOf("Original"))))
        assertTrue(result.single().optionalOutsideFavorites)
        assertTrue(result.single().reason.contains("Nenhuma troca"))
        val optimized = engine.optimize(listOf(item), listOf(original, candidate(2)), listOf(price(2, 600)),
            AISettings(mode = RecommendationMode.FAVORITE_BRANDS), 1)
        assertEquals(1000L, optimized.optimizedCents)
    }

    @Test fun `produto que nao pode ser substituido e protegido em todos os modos`() {
        RecommendationMode.entries.forEach { mode ->
            assertTrue(engine.alternatives(item, listOf(original.copy(neverSubstitute = true), candidate(2)), listOf(price(2, 600)), AISettings(mode = mode), 1).isEmpty())
        }
    }

    @Test fun `embalagens sao arredondadas para cima conforme quantidade necessaria`() {
        val pack = candidate(2, quantity = "0.6")
        val choice = alternatives(listOf(pack), listOf(price(2, 300))).single()
        assertEquals("2", choice.quantity)
        assertEquals(600L, choice.totalCents)
        assertEquals(400L, choice.savingsCents)
        assertEquals(0, BigDecimal("5").compareTo(choice.normalizedUnitPrice))
    }

    @Test fun `quilogramas e gramas tem comparacao normalizada correta`() {
        val grams = candidate(2).copy(packageQuantity = "500", packageUnit = MeasurementUnit.G)
        val choice = alternatives(listOf(grams), listOf(price(2, 250))).single()
        assertEquals("kg", choice.normalizedUnit)
        assertEquals("2", choice.quantity)
        assertEquals(0, BigDecimal("5").compareTo(choice.normalizedUnitPrice))
    }

    @Test fun `litros e mililitros tem comparacao normalizada correta`() {
        val liter = original.copy(category = "Bebidas", packageUnit = MeasurementUnit.L, equivalenceKey = "suco")
        val half = liter.copy(id = 2, packageQuantity = "500", packageUnit = MeasurementUnit.ML)
        val result = engine.alternatives(item, listOf(liter, half), listOf(price(2, 350)), AISettings(), 1).single()
        assertEquals("L", result.normalizedUnit)
        assertEquals(700L, result.totalCents)
    }

    @Test fun `produtos por peso aceitam quantidades fracionarias na alternativa`() {
        val weighted = candidate(2).copy(saleUnit = MeasurementUnit.KG, packageUnit = MeasurementUnit.KG)
        val result = engine.alternatives(item.copy(quantity = "0.5"), listOf(original, weighted), listOf(price(2, 600)), AISettings(), 1).single()
        assertEquals("0.5", result.quantity)
        assertEquals(300L, result.totalCents)
    }

    @Test fun `massa nao e convertida em volume`() {
        assertTrue(alternatives(listOf(candidate(2).copy(packageUnit = MeasurementUnit.L)), listOf(price(2, 600))).isEmpty())
    }

    @Test fun `pacotes com contagens diferentes usam custo por unidade`() {
        val six = original.copy(packageQuantity = "6", packageUnit = MeasurementUnit.UNIT)
        val four = six.copy(id = 2, packageQuantity = "4")
        val result = engine.alternatives(item.copy(quantity = "2", estimatedPriceCents = 900), listOf(six, four),
            listOf(price(2, 500)), AISettings(), 1).single()
        assertEquals("3", result.quantity)
        assertEquals(1500L, result.totalCents)
        assertEquals(0, BigDecimal("1.25").compareTo(result.normalizedUnitPrice))
        assertEquals("un", result.normalizedUnit)
    }

    @Test fun `caracteristicas essenciais e restricoes impedem equivalencia insegura`() {
        val restricted = original.copy(restrictions = setOf("sem glúten"))
        val a = candidate(2).copy(essentialCharacteristics = setOf("integral", "tipo 1"))
        assertTrue(alternatives(listOf(a), listOf(price(2, 600))).isEmpty())
        assertTrue(engine.alternatives(item, listOf(restricted, candidate(2)), listOf(price(2, 600)), AISettings(), 1).isEmpty())
        val safe = candidate(2).copy(restrictions = setOf("sem glúten", "sem lactose"))
        assertEquals(1, engine.alternatives(item, listOf(restricted, safe), listOf(price(2, 600)), AISettings(), 1).size)
    }

    @Test fun `formula infantil e quimico sem composicao explicita nao sao substituidos`() {
        val formula = original.copy(name = "Fórmula infantil", category = "Infantil")
        assertTrue(engine.alternatives(item, listOf(formula, formula.copy(id = 2)), listOf(price(2, 600)), AISettings(), 1).isEmpty())
        val pluralFormula = original.copy(name = "Produto para bebê", category = "Fórmulas infantis")
        assertFalse(engine.isSafeEquivalent(pluralFormula, pluralFormula.copy(id = 2)))
        assertFalse(engine.isSafeEquivalent(pluralFormula.copy(id = 0), pluralFormula.copy(id = 0, brand = "Outra")))
        val chemical = original.copy(name = "Detergente", category = "Limpeza", essentialCharacteristics = emptySet())
        assertTrue(engine.alternatives(item, listOf(chemical, chemical.copy(id = 2)), listOf(price(2, 600)), AISettings(), 1).isEmpty())
        assertFalse(engine.isSafeEquivalent(chemical.copy(category = "Outros"), chemical.copy(id = 2, category = "Outros")))
    }

    @Test fun `nenhum preco ou equivalencia desconhecida nao gera resultado ficticio`() {
        assertTrue(alternatives(listOf(candidate(2)), emptyList()).isEmpty())
        assertTrue(alternatives(listOf(candidate(2).copy(equivalenceKey = "")), listOf(price(2, 600))).isEmpty())
    }

    @Test fun `historico e identificado e nao apresentado como preco atual`() {
        val result = alternatives(listOf(candidate(2)), listOf(price(2, 600).copy(source = PriceSource.HISTORICAL, sourceName = "Compra antiga"))).single()
        assertTrue(result.reason.contains("histórico"))
        assertTrue(result.reason.contains("não é um preço atual confirmado"))
        assertTrue(result.reason.contains("Compra antiga"))
        assertTrue(result.reason.contains("14/11/2023"))
    }

    @Test fun `outro mercado so e consultado quando permitido`() {
        val products = listOf(original, candidate(2))
        val observations = listOf(price(2, 600, 2))
        assertTrue(engine.alternatives(item, products, observations, AISettings(), 1).isEmpty())
        val allowed = engine.alternatives(item, products, observations, AISettings(), 1, true).single()
        assertTrue(allowed.reason.contains("Outro mercado"))
        assertTrue(engine.alternatives(item, products, observations, AISettings(), null).isEmpty())
    }

    @Test fun `promocao expirada e observacao futura nao entram em sugestoes`() {
        assertTrue(alternatives(listOf(candidate(2)), listOf(price(2, 600).copy(validUntil = now - 1))).isEmpty())
        assertTrue(alternatives(listOf(candidate(2)), listOf(price(2, 600).copy(observedAt = now + 1))).isEmpty())
    }

    @Test fun `ultimo preco observado prevalece sobre registro antigo mais barato`() {
        val results = alternatives(listOf(candidate(2)), listOf(price(2, 300).copy(observedAt = now - 1), price(2, 700)))
        assertEquals(700L, results.single().observation.priceCents)
        val tie = alternatives(listOf(candidate(2)), listOf(price(2, 300).copy(id = 1), price(2, 700).copy(id = 2)))
        assertEquals(700L, tie.single().observation.priceCents)
    }

    @Test fun `otimizacao calcula economia e preserva produtos ja comprados`() {
        val products = listOf(original, candidate(2))
        val result = engine.optimize(listOf(item, item.copy(id = 2, status = ItemStatus.IN_CART)), products, listOf(price(2, 600)), AISettings(), 1)
        assertEquals(2000L, result.originalCents)
        assertEquals(1600L, result.optimizedCents)
        assertEquals(1, result.suggestions.size)
        assertEquals(listOf("Arroz branco"), result.duplicates)
    }

    @Test fun `recomendacao e visualizacao imutavel sem substituir lista`() {
        val before = item.copy()
        alternatives(listOf(candidate(2)), listOf(price(2, 600)))
        assertEquals(before, item)
        assertEquals(1L, item.productId)
    }

    @Test fun `comparacao informa cobertura e nao aplica descontos de outro mercado`() {
        val store1 = Store(1, "A")
        val store2 = Store(2, "B")
        val items = listOf(item.copy(discountCents = 200), item.copy(id = 2, productId = 2))
        val results = engine.compareStores(items, listOf(original, candidate(2)), listOf(price(1, 900), price(1, 700, 2), price(2, 700, 2)), listOf(store1, store2))
        val first = results.find { it.store.id == 1L }!!
        assertEquals(900L, first.knownTotalCents)
        assertEquals(1, first.comparableCount)
        assertEquals(1, first.missingCount)
        assertEquals(2L, results.first().store.id)
    }
}
