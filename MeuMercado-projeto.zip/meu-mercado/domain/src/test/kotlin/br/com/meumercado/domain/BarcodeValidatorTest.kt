package br.com.meumercado.domain

import org.junit.Assert.*
import org.junit.Test

class BarcodeValidatorTest {
    @Test fun validatesCommonGtinLengths() {
        listOf("96385074", "036000291452", "4006381333931", "10012345678902").forEach { assertTrue(it, BarcodeValidator.isValid(it)) }
    }
    @Test fun rejectsIncorrectChecksumsAndUnsupportedInput() {
        listOf("96385075", "036000291453", "4006381333932", "10012345678903", "", "ABC123", "123456", "4006381333931 ", "400638133393X", "00000000", "0000000000000").forEach {
            assertFalse(it, BarcodeValidator.isValid(it))
        }
    }
    @Test fun readsValidatedBarcodeFromLocalOcrWithoutInternet() {
        assertEquals("4006381333931", LabelParser.parse("ARROZ\n4006381333931\nR$ 7,90").barcode)
        assertNull(LabelParser.parse("ARROZ\n4006381333932\nR$ 7,90").barcode)
    }
}
