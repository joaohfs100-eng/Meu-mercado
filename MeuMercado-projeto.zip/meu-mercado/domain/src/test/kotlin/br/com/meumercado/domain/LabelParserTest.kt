package br.com.meumercado.domain

import org.junit.Assert.*
import org.junit.Test

class LabelParserTest {
    @Test fun parsesBrazilianPricePackageAndBarcodeForReview() {
        val draft = LabelParser.parse("ARROZ BRANCO\nPacote 5 kg\nR$ 29,90\n4006381333931")
        assertEquals("ARROZ BRANCO", draft.name)
        assertEquals(2990L, draft.priceCents)
        assertEquals("5", draft.packageQuantity)
        assertEquals(MeasurementUnit.KG, draft.packageUnit)
        assertEquals("4006381333931", draft.barcode)
        assertTrue(draft.warnings.any { it.contains("Revise") })
    }
    @Test fun detectsUnconditionalDePorPromotionButStillRequiresReview() {
        val draft = LabelParser.parse("CAFÉ TORRADO 500 g\nDE R$ 18,99 POR R$ 14,90")
        assertEquals(1490L, draft.priceCents)
        assertTrue(draft.promotion.isNotBlank())
        assertTrue(draft.warnings.any { it.contains("promocional") })
        assertEquals(1490L, LabelParser.parse("CAFÉ 500 g\nDE R$ 18,99\nPOR R$ 14,90").priceCents)
        assertNull(LabelParser.parse("CAFÉ 500 g\nDE R$ 18,99 POR R$ XX,XX").priceCents)
    }
    @Test fun refusesAmbiguousPricesAndConditionalDiscounts() {
        assertNull(LabelParser.parse("LEITE 1 L\nR$ 4,99\nR$ 5,49").priceCents)
        val draft = LabelParser.parse("LEITE 1 L\nCLUBE R$ 3,99\nPREÇO NORMAL R$ 4,99")
        assertNull(draft.priceCents)
        assertTrue(draft.warnings.any { it.contains("condicionada") })
    }
    @Test fun keepsPackagePriceSeparateFromPricePerLiter() {
        val draft = LabelParser.parse("DETERGENTE 500 ml\nR$ 3,20\nR$ 6,40/L")
        assertEquals(320L, draft.priceCents)
        assertEquals(MeasurementUnit.UNIT, draft.unit)
        assertEquals("500", draft.packageQuantity)
        assertEquals(MeasurementUnit.ML, draft.packageUnit)
        assertTrue(draft.warnings.any { it.contains("Preço por unidade") })
    }
    @Test fun readsWeightedShelfPriceAndDoesNotTreatVolumeAsMoney() {
        assertEquals(MeasurementUnit.KG, LabelParser.parse("BANANA PRATA\nR$ 7,99/kg").unit)
        assertEquals(799L, LabelParser.parse("BANANA PRATA\nR$ 7,99/kg").priceCents)
        val pricedByKg = LabelParser.parse("BANANA PRATA\nPreço por 1 kg: R$    7,99")
        assertEquals(MeasurementUnit.KG, pricedByKg.unit)
        assertEquals("1", pricedByKg.packageQuantity)
        assertEquals(MeasurementUnit.UNIT, pricedByKg.packageUnit)
        val suffixKg = LabelParser.parse("BANANA PRATA\nR$    7,99 kg")
        assertEquals(MeasurementUnit.KG, suffixKg.unit)
        assertEquals(MeasurementUnit.UNIT, suffixKg.packageUnit)
        assertNull(LabelParser.parse("QUEIJO\nR$ 9,90/100 g").priceCents)
        assertNull(LabelParser.parse("QUEIJO\nPreço por 100 g: R$ 9,90").priceCents)
        assertNull(LabelParser.parse("LEITE INTEGRAL 1,00 L").priceCents)
    }
    @Test fun damagedOrEmptyOcrNeverInventsPrice() {
        assertNull(LabelParser.parse("").priceCents)
        assertTrue(LabelParser.parse("").warnings.isNotEmpty())
        assertNull(LabelParser.parse("ARROZ\nR$ XX,XX").priceCents)
        assertNull(LabelParser.parse("ARROZ\nR$ 9,9").priceCents)
        assertNull(LabelParser.parse("ARROZ\nR$ 1.234.56").priceCents)
        assertNull(LabelParser.parse("ARROZ\nR$ -1,99").priceCents)
        assertNull(LabelParser.parse("ARROZ\nR$ +1,99").priceCents)
        assertNull(LabelParser.parse("ARROZ\nR$ + 1,99").priceCents)
        assertNull(LabelParser.parse("ARROZ\nDESCONTO 10,00%").priceCents)
        assertEquals(1000L, LabelParser.parse("ARROZ\nDESCONTO 10,00%\nR$ 10,00").priceCents)
        assertNull(LabelParser.parse("ARROZ\n99999999999999999999,99").priceCents)
    }
    @Test fun acceptsDotDecimalAndBrazilianThousands() {
        assertEquals(999L, LabelParser.parse("AZEITE\nR$ 9.99").priceCents)
        assertEquals(123456L, LabelParser.parse("PRODUTO\nR$ 1.234,56").priceCents)
    }
}
