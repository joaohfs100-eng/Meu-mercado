package br.com.meumercado.domain

import java.math.BigDecimal
import org.junit.Assert.*
import org.junit.Test

class MoneyBudgetTest {
    private fun item(status: ItemStatus = ItemStatus.PENDING, quantity: String = "1", estimated: Long = 1000,
        actual: Long? = null, discount: Long = 0) = ShoppingListItem(1, 1, 1, quantity, estimated, actual, discount, status)

    @Test fun `precos brasileiros sao representados em centavos exatos`() {
        assertEquals(123456L, Money.parseCents("R$ 1.234,56"))
        assertEquals(1L, Money.parseCents("0,01"))
        assertEquals(250L, Money.parseCents("  R$ 2,50  "))
        assertEquals(100000L, Money.parseCents("1.000"))
        assertEquals(123456L, Money.parseCents("1234.56"))
        assertTrue(Money.format(123456).contains("1.234,56"))
    }

    @Test fun `quantidade fracionaria preserva todas as casas`() {
        assertEquals(BigDecimal("0.125"), Money.parseQuantity("0,125"))
        assertEquals(BigDecimal("0.125"), Money.parseQuantity("0.125"))
        assertEquals(125L, Money.subtotal(1000, "0,125"))
    }

    @Test fun `arredondamento ocorre somente no subtotal por linha`() {
        assertEquals(333L, Money.subtotal(1000, "0,3333"))
        assertEquals(34L, Money.subtotal(100, "0,335"))
    }

    @Test fun `desconto e por linha e nao multiplicado pela quantidade`() {
        assertEquals(1800L, Money.subtotal(1000, "2", 200))
        assertEquals(0L, Money.subtotal(1000, "1", 1200))
    }

    @Test fun `preco negativo quantidade zero e notacao ambigua sao rejeitados`() {
        listOf("-2", "NaN", "1e3", "", "1,2,3", "1.2.3,40", "0,001").forEach { input ->
            assertThrows(IllegalArgumentException::class.java) { Money.parseCents(input) }
        }
        assertThrows(IllegalArgumentException::class.java) { Money.parseQuantity("0") }
        assertThrows(IllegalArgumentException::class.java) { Money.subtotal(-1, "1") }
    }

    @Test fun `overflow monetario e rejeitado`() {
        assertThrows(IllegalArgumentException::class.java) { Money.parseCents("9999999999999999999999999") }
        assertThrows(IllegalArgumentException::class.java) { Money.subtotal(Long.MAX_VALUE, "2") }
    }

    @Test fun `orcamento reserva margem fixa`() {
        val result = BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART, estimated = 30000)), BudgetSettings(1, 50000, 5000))
        assertEquals(45000L, result.operationalLimitCents)
        assertEquals(15000L, result.remainingCents)
    }

    @Test fun `margens percentual e fixa sao somadas e limite maximo respeitado`() {
        val settings = BudgetSettings(1, 50000, 5000, "10", 35000)
        val result = BudgetCalculator.calculate(emptyList(), settings)
        assertEquals(35000L, result.operationalLimitCents)
        assertEquals(40000L, BudgetCalculator.calculate(emptyList(), settings.copy(maximumCents = null)).operationalLimitCents)
    }

    @Test fun `pendentes ignoram preco efetivo e nao contam no carrinho`() {
        val result = BudgetCalculator.calculate(listOf(item(estimated = 1000, actual = 9000)), BudgetSettings(1, 10000))
        assertEquals(0L, result.cartCents)
        assertEquals(1000L, result.pendingCents)
        assertEquals(1000L, result.projectedCents)
        assertEquals(10000L, result.remainingCents)
    }

    @Test fun `carrinho prefere preco real e mantem previsao pendente separada`() {
        val cart = item(ItemStatus.IN_CART, "2", 1000, 1200, 100)
        val pending = item().copy(id = 2)
        val result = BudgetCalculator.calculate(listOf(cart, pending), BudgetSettings(1, 10000))
        assertEquals(2300L, result.cartCents)
        assertEquals(1000L, result.pendingCents)
        assertEquals(3300L, result.projectedCents)
        assertEquals(7700L, result.remainingCents)
    }

    @Test fun `indisponiveis removidos e itens de outra lista nao contam`() {
        val result = BudgetCalculator.calculate(listOf(item(ItemStatus.UNAVAILABLE), item(ItemStatus.REMOVED), item().copy(listId = 2)), BudgetSettings(1, 10000))
        assertEquals(0L, result.projectedCents)
        assertEquals(0, result.pendingCount)
    }

    @Test fun `recalculo reage a atualizacao do carrinho sem cache`() {
        val settings = BudgetSettings(1, 10000)
        val before = BudgetCalculator.calculate(listOf(item()), settings)
        val after = BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART, actual = 800)), settings)
        assertEquals(0L, before.cartCents)
        assertEquals(800L, after.cartCents)
        assertEquals(0L, after.pendingCents)
    }

    @Test fun `alertas obedecem limiares e excesso e identificado`() {
        val settings = BudgetSettings(1, 10000)
        assertEquals(75, BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART, actual = 8000)), settings).alert)
        assertEquals(101, BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART, actual = 11000)), settings).alert)
        assertNull(BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART, actual = 8000)), settings.copy(alertThresholds = emptySet())).alert)
    }

    @Test fun `limite zero nao divide por zero e reserva nunca fica negativa`() {
        val settings = BudgetSettings(1, 1000, 5000)
        val result = BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART)), settings)
        assertEquals(0L, result.operationalLimitCents)
        assertEquals(-1000L, result.remainingCents)
        assertEquals(101, result.alert)
        assertEquals(0L, BudgetCalculator.calculate(emptyList(), BudgetSettings(1, Long.MAX_VALUE, Long.MAX_VALUE, "100")).operationalLimitCents)
    }

    @Test fun `tributos incluidos nao sao somados novamente ao carrinho`() {
        val total = BudgetCalculator.calculate(listOf(item(ItemStatus.IN_CART)), BudgetSettings(1, 10000)).cartCents
        val record = TaxRecord(historyId = 1, amountCents = 350, includedInPrice = true)
        assertTrue(record.includedInPrice)
        // Tributos são informação separada; BudgetCalculator trabalha exclusivamente com linhas.
        assertEquals(1000L, total)
    }
}
