package br.com.meumercado.domain

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId

class LocalAssistantTest {
    private val now = Instant.parse("2026-10-10T12:00:00Z").toEpochMilli()
    private val assistant = LocalAssistant(RecommendationEngine { now }, { now }, ZoneId.of("UTC"))
    private val settings = AISettings(activeListId = 1)
    private val arroz = Product(id = 1, name = "Arroz branco", brand = "A", category = "Alimentação", packageQuantity = "5", packageUnit = MeasurementUnit.KG, equivalenceKey = "arroz branco")
    private val barato = arroz.copy(id = 2, name = "Arroz branco econômico", brand = "B")
    private fun snapshot() = AppSnapshot(products = listOf(arroz, barato), stores = listOf(Store(1, "Mercado do bairro")),
        lists = listOf(ShoppingList(1, "Semanal", storeId = 1)),
        items = listOf(ShoppingListItem(1, 1, 1, "1", 2990), ShoppingListItem(2, 1, 1, "2", 3000, 2500, status = ItemStatus.IN_CART)),
        budgets = listOf(BudgetSettings(1, 50000, 5000)),
        prices = listOf(PriceObservation(productId = 2, storeId = 1, priceCents = 2390, observedAt = now - 86400000)))

    @Test fun budgetReplySeparatesCartAndPendingProjection() {
        val reply = assistant.reply("Quanto ainda posso gastar?", snapshot(), settings).text
        assertTrue(reply.contains(Money.format(40000)))
        assertTrue(reply.contains(Money.format(5000)))
        assertTrue(reply.contains(Money.format(2990)))
        assertTrue(reply.contains(Money.format(7990)))
        assertTrue(reply.contains("pendentes"))
    }
    @Test fun pendingReplyExcludesCartUnavailableAndRemoved() {
        val source = snapshot().copy(items = snapshot().items + listOf(
            ShoppingListItem(3, 1, 2, status = ItemStatus.UNAVAILABLE), ShoppingListItem(4, 1, 2, status = ItemStatus.REMOVED)))
        val reply = assistant.reply("Quais produtos ainda faltam no carrinho?", source, settings).text
        assertTrue(reply.contains("1 produto"))
        assertFalse(reply.contains("econômico"))
    }
    @Test fun recommendationIsLocalAndRequiresConfirmation() {
        val source = snapshot()
        val reply = assistant.reply("Encontre um arroz mais barato.", source, settings)
        assertEquals(2, reply.recommendations.size)
        assertEquals(2L, reply.recommendations.first().alternatives.first().product.id)
        assertTrue(reply.text.contains("confirmação"))
        assertEquals(1L, source.items.first().productId)
    }
    @Test fun changingModeChangesRankingAndExplainsPreferences() {
        val favorites = settings.copy(mode = RecommendationMode.FAVORITE_BRANDS, favoriteBrands = mapOf("Alimentação" to setOf("A")))
        val response = assistant.reply("Encontre arroz mais barato", snapshot(), favorites)
        assertTrue(response.text.contains("marcas favoritas"))
        assertTrue(response.recommendations.first().alternatives.first().optionalOutsideFavorites)
        assertTrue(assistant.reply("Ajude a economizar", snapshot(), settings.copy(mode = RecommendationMode.BEST_VALUE)).text.contains("Custo-Benefício"))
        assertTrue(assistant.reply("Ajude a economizar", snapshot(), settings).text.contains("Máxima Economia"))
    }
    @Test fun unavailablePricesAndOnlineAreExplicit() {
        val emptyPrices = snapshot().copy(prices = emptyList())
        assertTrue(assistant.reply("Encontre arroz mais barato", emptyPrices, settings).text.contains("Não encontrei"))
        assertTrue(assistant.reply("Faça uma pesquisa online", emptyPrices, settings).text.contains("não está disponível"))
        assertEquals("Tributos não informados.", assistant.reply("Quais os impostos?", emptyPrices, settings).text)
    }
    @Test fun optimizationDoesNotSilentlyChangeAlreadyPurchasedItems() {
        val response = assistant.reply("Me ajude a economizar R$ 50 nesta compra", snapshot(), settings)
        assertEquals(1, response.recommendations.size)
        assertEquals(ItemStatus.PENDING, response.recommendations.single().item.status)
        assertTrue(response.text.contains("não permitem alcançar"))
        assertTrue(response.text.contains("nada foi alterado"))
        val thousandTarget = assistant.reply("Me ajude a economizar R$ 1.000 nesta compra", snapshot(), settings)
        assertTrue(thousandTarget.text.contains(Money.format(100000)))
        assertEquals(1, assistant.reply("Otimizar minha lista dentro do orçamento", snapshot(), settings).recommendations.size)
    }
    @Test fun lastMonthSpendingUsesImmutableHistoryWithinCalendarPeriod() {
        fun purchase(id: Long, whenDate: String, cents: Long) = ShoppingHistory(id, "Lista", 1, "Mercado", Instant.parse(whenDate).toEpochMilli(),
            listOf(HistoryItem("Produto histórico", "Marca", "Alimentação", 1, "1", MeasurementUnit.UNIT, cents, 0, cents, cents)), cents, 50000, cents)
        val source = snapshot().copy(history = listOf(purchase(1, "2026-09-01T00:00:00Z", 1234), purchase(2, "2026-08-31T23:59:59Z", 9999), purchase(3, "2026-10-01T00:00:00Z", 7777)))
        val reply = assistant.reply("Quanto gastei com alimentação no último mês?", source, settings).text
        assertTrue(reply.contains(Money.format(1234)))
        assertFalse(reply.contains(Money.format(9999)))
        assertFalse(reply.contains(Money.format(7777)))
    }
    @Test fun taxesRemainSeparateAndIncludedTaxesNeverIncreaseSpending() {
        val history = ShoppingHistory(1, "Lista", 1, "Mercado", now - 86400000, emptyList(), 10000, 15000, 10000)
        val source = snapshot().copy(history = listOf(history), taxes = listOf(TaxRecord(historyId = 1, amountCents = 1500, includedInPrice = true)))
        val taxReply = assistant.reply("Impostos da compra", source, settings).text
        assertTrue(taxReply.contains(Money.format(1500)))
        assertTrue(taxReply.contains("não são somados"))
        assertTrue(assistant.reply("Quanto gastei neste mês?", source, settings).text.contains(Money.format(10000)))
        assertFalse(assistant.reply("Quanto gastei neste mês?", source, settings).text.contains(Money.format(11500)))
    }
    @Test fun storeComparisonWarnsAboutCoverageAndHistoricalPrices() {
        val source = snapshot().copy(prices = listOf(PriceObservation(productId = 1, storeId = 1, priceCents = 1990, observedAt = now - 86400000, source = PriceSource.HISTORICAL)))
        val text = assistant.reply("Qual mercado teve o menor preço de arroz?", source, settings).text
        assertTrue(text.contains("produtos comparáveis"))
        assertTrue(text.contains("Totais parciais"))
        assertTrue(text.contains("não garantem"))
    }
    @Test fun catalogComparisonRejectsFutureAndExpiredPromotionalPrices() {
        val source = snapshot().copy(lists = emptyList(), items = emptyList(), prices = listOf(
            PriceObservation(productId = 1, storeId = 1, priceCents = 100, observedAt = now + 1),
            PriceObservation(productId = 2, storeId = 1, priceCents = 200, observedAt = now - 1000, validUntil = now - 1)))
        val text = assistant.reply("Qual mercado teve o menor preço de arroz?", source, settings).text
        assertTrue(text.contains("Não há preços locais"))
    }
    @Test fun catalogComparisonReportsNormalizedPackagePriceAndSource() {
        val source = snapshot().copy(lists = emptyList(), items = emptyList())
        val text = assistant.reply("Qual mercado teve o menor preço de arroz?", source, settings).text
        assertTrue(text.contains("embalagem de 5 kg"))
        assertTrue(text.contains("R$ 4,78/kg"))
        assertTrue(text.contains("informado pelo usuário"))
    }
    @Test fun absentCategoryDoesNotReportUnrelatedTotalAsRequestedSpending() {
        val item = HistoryItem("Arroz", "A", "Alimentação", 1, "1", MeasurementUnit.UNIT, 1000, 0, 1000, 1000)
        val history = ShoppingHistory(1, "Lista", 1, "Mercado", now - 1, listOf(item), 1000, 15000, 1000)
        val source = snapshot().copy(history = listOf(history))
        val text = assistant.reply("Quanto gastei com limpeza neste mês?", source, settings).text
        assertTrue(text.contains("Não há registros da categoria solicitada"))
        assertFalse(text.contains(Money.format(1000)))
        assertTrue(assistant.reply("Quanto gastei no ano passado?", source, settings).text.contains("outros períodos"))
    }
    @Test fun recurrentCountsPurchasesInsteadOfDuplicateLines() {
        val item = HistoryItem("Arroz", "A", "Alimentação", 1, "1", MeasurementUnit.UNIT, 1000, 0, 1000, 1000)
        val history = ShoppingHistory(1, "Lista", 1, "Mercado", now - 1, listOf(item, item), 2000, 15000, 2000)
        val text = assistant.reply("Quais produtos são mais comprados?", snapshot().copy(history = listOf(history)), settings).text
        assertTrue(text.contains("1 compra"))
        assertFalse(text.contains("2 compras"))
    }
}
