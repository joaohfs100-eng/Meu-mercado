package br.com.meumercado.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.Normalizer

/** Interpreta OCR sem criar associações definitivas. Todo resultado deve ser revisado. */
object LabelParser {
    private val amountPattern = Regex("(?<![\\d.,+\\-])(?:\\d{1,3}(?:\\.\\d{3})+|\\d+)[,.]\\d{2}(?![\\d.,+\\-])")
    private val packagePattern = Regex("(?i)(\\d+(?:[,.]\\d+)?)\\s*(kg|ml|g|litros?|l|unidades?|un)\\b")
    private val priceUnitPattern = Regex("(?i)^\\s*(?:/|por\\s+)(?:1(?:[,.]0+)?\\s*)?(kg|g|ml|litros?|l|unidades?|un)\\b")
    private val unitReferencePattern = Regex("(?i)(?:por|/)\\s*(?:1(?:[,.]0+)?\\s*)?(kg|g|ml|litros?|l|unidades?|un)\\b")
    private val pricedBasePattern = Regex("(?i)(?:por|/)\\s*(\\d+(?:[,.]\\d+)?)\\s*(?:kg|g|ml|litros?|l|unidades?|un)\\b")
    private val conditions = Regex("\\b(clube|cartao|fidelidade|leve|pague|minimo|acima|partir|atacado)\\b")

    fun parse(text: String): OcrDraft {
        val lines = text.lines().map(String::trim).filter(String::isNotBlank)
        val warnings = mutableListOf("Revise o produto, o preço e a unidade antes de salvar.")
        if (lines.isEmpty()) return OcrDraft(rawText = text, warnings = listOf("Nenhum texto reconhecido. Tente novamente ou cadastre manualmente."))
        val candidates = lines.flatMapIndexed { lineIndex, line ->
            amountPattern.findAll(line).mapNotNull { match ->
                val suffix = line.substring(match.range.last + 1)
                val prefix = line.take(match.range.first)
                val preceding = prefix.trimEnd().lastOrNull()
                if (preceding == '-' || preceding == '+' || preceding == '−') return@mapNotNull null
                if (suffix.trimStart().startsWith('%')) return@mapNotNull null
                // "R$ 9,90/100 g" exige interpretação da base do preço, sem presumir embalagem.
                val pricedBase = (pricedBasePattern.find(suffix) ?: pricedBasePattern.find(prefix))?.groupValues?.get(1)
                if (pricedBase != null && pricedBase.replace(',', '.').toBigDecimal().compareTo(BigDecimal.ONE) != 0) return@mapNotNull null
                // Uma medida decimal não representa um preço (ex.: embalagem de 1,00 L).
                if (Regex("(?i)^\\s*(kg|g|ml|l|litros?|unidades?|un)\\b").containsMatchIn(suffix) &&
                    !line.take(match.range.first).contains("R$", ignoreCase = true)) return@mapNotNull null
                val value = runCatching {
                    match.value.replace(".", if (match.value.contains(',')) "" else ".")
                        .replace(',', '.').toBigDecimal().multiply(BigDecimal(100))
                        .setScale(0, RoundingMode.UNNECESSARY).longValueExact()
                }.getOrNull() ?: return@mapNotNull null
                val unitLabel = priceUnitPattern.find(suffix)?.groupValues?.get(1)
                    ?: Regex("(?i)^\\s*(kg|g|ml|litros?|l|unidades?|un)\\b").find(suffix)?.groupValues?.get(1)
                    ?: unitReferencePattern.find(line.take(match.range.first))?.groupValues?.get(1)
                val unit = unitLabel?.let(::unitFor)
                PriceCandidate(value, lineIndex, match.range.first, unit)
            }.toList()
        }
        val normalized = normalize(text)
        val conditional = conditions.containsMatchIn(normalized)
        val packagePrices = candidates.filter { it.unit == null }
        val usable = (if (packagePrices.isNotEmpty()) packagePrices else candidates).filterNot { candidate ->
            // Um valor "DE" não vira preço vigente se o valor "POR" veio danificado pelo OCR.
            Regex("\\bde\\s*(?:r\\$\\s*)?$").containsMatchIn(normalize(lines[candidate.line].take(candidate.start)))
        }
        val promo = normalized.contains("promoc") || normalized.contains("oferta") || conditional ||
            Regex("\\bde\\b.+\\bpor\\b").containsMatchIn(normalized.replace('\n', ' '))
        val chosen = when {
            usable.isEmpty() -> null
            conditional -> null // Não pressupõe que o consumidor satisfaz as condições.
            usable.map { it.cents to it.unit }.distinct().size == 1 -> usable.first()
            else -> usable.singleOrNull { candidate ->
                val prefix = normalize(lines[candidate.line].take(candidate.start))
                Regex("\\bpor\\s*(?:r\\$\\s*)?$").containsMatchIn(prefix) &&
                    Regex("\\bde\\b").containsMatchIn(prefix)
            }
        }
        if (chosen == null) warnings += if (candidates.isEmpty()) "Preço não identificado com segurança." else "Há preços ou condições diferentes; informe o preço aplicável manualmente."
        if (conditional) warnings += "Oferta condicionada: confirme as regras da promoção."
        if (promo && chosen != null) warnings += "Preço promocional identificado; confirme a validade e as condições."
        if (packagePrices.isNotEmpty() && candidates.any { it.unit != null }) warnings += "Preço por unidade também foi encontrado; confira o preço da embalagem."

        val packageMatch = packagePattern.findAll(text).firstOrNull { match ->
            val prefix = text.take(match.range.first).substringAfterLast('\n').trimEnd()
            // Referências como "por 1 kg" e "R$    7,99 kg" não são embalagens.
            !Regex("(?i)(?:r\\$|/|\\bpor)\\s*$").containsMatchIn(prefix) &&
                runCatching { Money.parseQuantity(match.groupValues[1]) }.isSuccess
        }
        val quantity = packageMatch?.groupValues?.get(1)?.replace(',', '.') ?: "1"
        val packageUnit = packageMatch?.groupValues?.get(2)?.let(::unitFor) ?: MeasurementUnit.UNIT
        val barcode = Regex("(?<!\\d)\\d{8,14}(?!\\d)").findAll(text).map { it.value }.firstOrNull(BarcodeValidator::isValid)
        val name = lines.firstNotNullOfOrNull { line ->
            val value = line.replace(amountPattern, " ").replace(Regex("(?i)R\\$"), " ")
                .replace(packagePattern, " ").replace(Regex("\\b\\d{8,14}\\b"), " ")
                .replace(Regex("(?i)^\\s*(produto|descricao)\\s*:?\\s*"), "")
                .replace(Regex("\\s+"), " ").trim(' ', ':', '-', '/')
            value.takeIf { candidate ->
                candidate.count(Char::isLetter) >= 3 &&
                    !Regex("(?i)^(preco|preço|de|por|oferta|promoção|promocao|clube|valor|un|kg|litro)\\b").containsMatchIn(candidate)
            }
        }.orEmpty()
        if (name.isBlank()) warnings += "Nome não identificado; selecione ou cadastre o produto correto."
        return OcrDraft(name = name, priceCents = chosen?.cents, unit = chosen?.unit ?: MeasurementUnit.UNIT,
            packageQuantity = quantity, packageUnit = packageUnit, barcode = barcode,
            promotion = if (promo) lines.filter { line ->
                val normalizedLine = normalize(line)
                normalizedLine.contains("promoc") || normalizedLine.contains("oferta") ||
                    conditions.containsMatchIn(normalizedLine) || Regex("\\bde\\b.*\\bpor\\b").containsMatchIn(normalizedLine)
            }.joinToString("; ") else "", rawText = text, warnings = warnings.distinct())
    }

    private data class PriceCandidate(val cents: Long, val line: Int, val start: Int, val unit: MeasurementUnit?)
    private fun normalize(value: String) = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    private fun unitFor(value: String): MeasurementUnit = when (value.lowercase()) {
        "kg" -> MeasurementUnit.KG
        "g" -> MeasurementUnit.G
        "ml" -> MeasurementUnit.ML
        "l", "litro", "litros" -> MeasurementUnit.L
        else -> MeasurementUnit.UNIT
    }
}
