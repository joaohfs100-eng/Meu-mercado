package br.com.meumercado.domain

import java.math.BigDecimal
import java.math.RoundingMode

/** Conversões só ocorrem dentro da mesma dimensão: massa, volume ou contagem. */
object UnitNormalizer {
    fun normalizedUnit(unit: MeasurementUnit): String = when (unit) {
        MeasurementUnit.KG, MeasurementUnit.G -> "kg"
        MeasurementUnit.L, MeasurementUnit.ML -> "L"
        MeasurementUnit.UNIT -> "un"
    }

    fun factor(unit: MeasurementUnit): BigDecimal = when (unit) {
        MeasurementUnit.G, MeasurementUnit.ML -> BigDecimal("0.001")
        else -> BigDecimal.ONE
    }

    fun content(product: Product): BigDecimal = if (product.saleUnit == MeasurementUnit.UNIT)
        Money.parseQuantity(product.packageQuantity).multiply(factor(product.packageUnit))
    else factor(product.saleUnit)

    fun dimension(product: Product): String = normalizedUnit(
        if (product.saleUnit == MeasurementUnit.UNIT) product.packageUnit else product.saleUnit)

    fun requiredQuantity(original: Product, quantity: String, alternative: Product): String {
        require(dimension(original) == dimension(alternative)) { "Unidades incompatíveis." }
        val needed = Money.parseQuantity(quantity).multiply(content(original))
        val candidateContent = content(alternative)
        val count = if (alternative.saleUnit == MeasurementUnit.UNIT)
            needed.divide(candidateContent, 0, RoundingMode.CEILING)
        else needed.divide(candidateContent, 12, RoundingMode.CEILING)
        return count.stripTrailingZeros().toPlainString()
    }

    fun pricePerStandardUnit(priceCents: Long, product: Product): BigDecimal {
        require(priceCents >= 0)
        return BigDecimal.valueOf(priceCents, 2).divide(content(product), 8, RoundingMode.HALF_UP)
            .stripTrailingZeros()
    }
}
