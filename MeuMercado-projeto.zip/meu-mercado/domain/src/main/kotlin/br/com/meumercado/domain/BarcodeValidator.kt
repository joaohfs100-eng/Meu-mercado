package br.com.meumercado.domain

/** Valida o dígito verificador de GTIN-8, UPC-A, EAN-13 e GTIN-14. */
object BarcodeValidator {
    fun isValid(value: String): Boolean {
        if (value.length !in setOf(8, 12, 13, 14) || value.any { it !in '0'..'9' } || value.all { it == '0' }) return false
        val sum = value.dropLast(1).reversed().mapIndexed { index, digit ->
            (digit - '0') * if (index % 2 == 0) 3 else 1
        }.sum()
        return (10 - sum % 10) % 10 == value.last() - '0'
    }
}
