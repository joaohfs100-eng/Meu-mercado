package br.com.meumercado.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale

/** Nenhum cálculo monetário passa por Double; o único arredondamento ocorre no subtotal. */
object Money {
    fun parseCents(input: String): Long {
        val raw = input.trim().removePrefix("R$").trim()
        // Em valores monetários brasileiros, grupos de três dígitos são milhares.
        // Quantidades continuam aceitando ponto decimal (ex.: 0.125 kg).
        val localized = if (',' !in raw && Regex("[+]?\\d{1,3}(?:\\.\\d{3})+").matches(raw)) raw.replace(".", "") else raw
        val value = decimal(localized)
        require(value.signum() >= 0) { "O valor não pode ser negativo." }
        require(value.stripTrailingZeros().scale() <= 2) { "Informe até duas casas decimais para preços." }
        return exactLong(value.movePointRight(2))
    }

    fun parseQuantity(input: String): BigDecimal {
        val value = decimal(input)
        require(value.signum() > 0) { "A quantidade deve ser maior que zero." }
        return value
    }

    fun format(cents: Long): String = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        .format(BigDecimal.valueOf(cents, 2))

    /** Desconto é por linha, não por unidade. Não cria subtotais negativos. */
    fun subtotal(priceCents: Long, quantity: String, discountCents: Long = 0): Long {
        require(priceCents >= 0 && discountCents >= 0) { "Preço e desconto não podem ser negativos." }
        val gross = exactLong(BigDecimal.valueOf(priceCents).multiply(parseQuantity(quantity)).setScale(0, RoundingMode.HALF_UP))
        return (gross - discountCents.coerceAtMost(gross))
    }

    internal fun decimal(input: String): BigDecimal {
        val raw = input.trim()
        require(raw.isNotEmpty() && raw.length <= 60) { "Número inválido." }
        val normalized = when {
            ',' in raw -> {
                require(Regex("[+]?\\d{1,3}(?:\\.\\d{3})*,\\d+|[+]?\\d+,\\d+").matches(raw)) { "Número inválido." }
                raw.replace(".", "").replace(',', '.')
            }
            else -> {
                require(Regex("[+]?\\d+(?:\\.\\d+)?").matches(raw)) { "Número inválido." }
                raw
            }
        }
        return try { BigDecimal(normalized) } catch (_: NumberFormatException) {
            throw IllegalArgumentException("Número inválido.")
        }
    }

    internal fun exactLong(value: BigDecimal): Long = try {
        value.longValueExact()
    } catch (_: ArithmeticException) {
        throw IllegalArgumentException("O valor excede o limite suportado.")
    }

    internal fun add(a: Long, b: Long): Long = try { Math.addExact(a, b) } catch (_: ArithmeticException) {
        throw IllegalArgumentException("O valor excede o limite suportado.")
    }
}
