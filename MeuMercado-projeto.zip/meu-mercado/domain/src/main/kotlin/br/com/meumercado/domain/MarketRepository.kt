package br.com.meumercado.domain

import kotlinx.coroutines.flow.Flow

interface MarketRepository {
    val snapshot: Flow<AppSnapshot>
    val settings: Flow<AISettings>
    suspend fun saveProduct(product: Product): Long
    suspend fun saveStore(store: Store): Long
    suspend fun deleteStore(id: Long)
    suspend fun saveList(list: ShoppingList): Long
    suspend fun deleteList(id: Long)
    suspend fun duplicateList(id: Long): Long
    suspend fun saveItem(item: ShoppingListItem): Long
    suspend fun deleteItem(id: Long)
    suspend fun saveBudget(budget: BudgetSettings)
    suspend fun saveSettings(settings: AISettings)
    suspend fun observePrice(price: PriceObservation)
    suspend fun substitute(itemId: Long, alternative: Alternative)
    suspend fun undo(): Boolean
    suspend fun finishPurchase(listId: Long): Long
    suspend fun saveTax(tax: TaxRecord)
    suspend fun saveReceipt(historyId: Long, uri: String)
    suspend fun rememberSearch(query: String)
    suspend fun clearLearnedPreferences()
    suspend fun exportBackup(): String
    suspend fun restoreBackup(json: String)
    suspend fun eraseAll()
}
