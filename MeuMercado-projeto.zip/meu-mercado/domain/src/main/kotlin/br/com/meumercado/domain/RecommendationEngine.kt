package br.com.meumercado.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Motor determinístico de regras. Não presume disponibilidade nem gera dados de mercado. */
class RecommendationEngine(private val clock: () -> Long = System::currentTimeMillis) {
    fun alternatives(
        item: ShoppingListItem, products: List<Product>, prices: List<PriceObservation>,
        settings: AISettings, storeId: Long?, allowOtherStores: Boolean = false
    ): List<Alternative> {
        val original = products.find { it.id == item.productId } ?: return emptyList()
        if (original.neverSubstitute || original.equivalenceKey.isBlank()) return emptyList()
        if (storeId == null && !allowOtherStores) return emptyList()
        val originalTotal = BudgetCalculator.total(item)
        val favorites = favoriteBrands(original, settings)
        val observations = latestPrices(prices.filter { allowOtherStores || it.storeId == storeId })
        val alternatives = products.filter { isSafeEquivalent(original, it) }.flatMap { product ->
            observations.filter { it.productId == product.id }.mapNotNull { price ->
                val quantity = UnitNormalizer.requiredQuantity(original, item.quantity, product)
                val total = Money.subtotal(price.priceCents, quantity)
                // Uma oferta do mesmo produto só é útil se de fato reduzir o custo da linha.
                if (product.id == original.id && total >= originalTotal) return@mapNotNull null
                val savings = originalTotal - total
                val percent = if (originalTotal == 0L) BigDecimal.ZERO else BigDecimal.valueOf(savings)
                    .multiply(BigDecimal(100)).divide(BigDecimal.valueOf(originalTotal), 2, RoundingMode.HALF_UP)
                val outside = settings.mode == RecommendationMode.FAVORITE_BRANDS && favorites.isNotEmpty() &&
                    canonical(product.brand) !in favorites
                Alternative(product, price, quantity, total,
                    UnitNormalizer.pricePerStandardUnit(price.priceCents, product), UnitNormalizer.dimension(product),
                    savings, percent, explanation(original, product, price, quantity, settings, storeId, outside), outside)
            }
        }
        return when (settings.mode) {
            RecommendationMode.MAXIMUM_SAVINGS -> alternatives.sortedWith(compareBy<Alternative> { it.totalCents }
                .thenBy { it.normalizedUnitPrice }.thenBy { it.product.name }.thenBy { it.observation.storeId })
            RecommendationMode.BEST_VALUE -> alternatives.sortedWith(compareBy<Alternative> { valueScore(it, favorites) }
                .thenBy { it.totalCents }.thenBy { it.product.name })
            RecommendationMode.FAVORITE_BRANDS -> alternatives.sortedWith(compareBy<Alternative> { it.optionalOutsideFavorites }
                .thenBy { it.totalCents }.thenBy { it.normalizedUnitPrice }.thenBy { it.product.name })
        }
    }

    fun optimize(
        items: List<ShoppingListItem>, products: List<Product>, prices: List<PriceObservation>,
        settings: AISettings, storeId: Long?, allowOtherStores: Boolean = false
    ): Optimization {
        val active = items.filter { it.status == ItemStatus.PENDING || it.status == ItemStatus.IN_CART }
        val originalTotal = active.fold(0L) { sum, item -> Money.add(sum, BudgetCalculator.total(item)) }
        val suggestions = active.filter { it.status == ItemStatus.PENDING }.mapNotNull { item ->
            val product = products.find { it.id == item.productId } ?: return@mapNotNull null
            val choices = alternatives(item, products, prices, settings, storeId, allowOtherStores)
                .filter { it.savingsCents > 0 }
            if (choices.isEmpty()) null else ItemRecommendation(item, product, choices)
        }
        val savings = suggestions.fold(0L) { sum, suggestion ->
            val selected = suggestion.alternatives.firstOrNull { !it.optionalOutsideFavorites }
            Money.add(sum, selected?.savingsCents ?: 0)
        }
        val duplicates = active.groupBy { it.productId }.filterValues { it.size > 1 }.keys.map { id ->
            products.find { it.id == id }?.name ?: "Produto #$id"
        }
        val missing = active.count { (if (it.status == ItemStatus.IN_CART) it.actualPriceCents ?: it.estimatedPriceCents
            else it.estimatedPriceCents) == 0L }
        return Optimization(originalTotal, originalTotal - savings, suggestions, duplicates, missing)
    }

    fun compareStores(
        items: List<ShoppingListItem>, products: List<Product>, prices: List<PriceObservation>, stores: List<Store>
    ): List<StoreComparison> {
        val active = items.filter { it.status == ItemStatus.PENDING || it.status == ItemStatus.IN_CART }
        val productIds = products.map { it.id }.toSet()
        val observations = latestPrices(prices)
        return stores.map { store ->
            var total = 0L
            val dates = mutableListOf<Long>()
            for (item in active) {
                val price = observations.find { it.storeId == store.id && it.productId == item.productId && it.productId in productIds }
                    ?: continue
                // Descontos particulares da lista não são extrapolados a outros mercados.
                total = Money.add(total, Money.subtotal(price.priceCents, item.quantity))
                dates += price.observedAt
            }
            StoreComparison(store, total, dates.size, active.size - dates.size, dates.minOrNull(), dates.maxOrNull())
        }.sortedWith(compareByDescending<StoreComparison> { it.comparableCount }.thenBy { it.knownTotalCents })
    }

    /** Regra compartilhada com a persistência para revalidar uma troca confirmada. */
    fun isSafeEquivalent(original: Product, candidate: Product): Boolean {
        if (original.neverSubstitute || original.equivalenceKey.isBlank()) return false
        if (canonical(original.category) != canonical(candidate.category)) return false
        if (canonical(original.equivalenceKey) != canonical(candidate.equivalenceKey)) return false
        if (original.essentialCharacteristics.map(::canonical).toSet() != candidate.essentialCharacteristics.map(::canonical).toSet()) return false
        if (!candidate.restrictions.map(::canonical).toSet().containsAll(original.restrictions.map(::canonical))) return false
        if (UnitNormalizer.dimension(original) != UnitNormalizer.dimension(candidate)) return false
        val sameProduct = original.id > 0 && original.id == candidate.id
        if (!sameProduct && (sensitive(original) || sensitive(candidate))) return false
        val isChemical = listOf(original, candidate).any(::chemical)
        if (isChemical && !sameProduct && original.essentialCharacteristics.isEmpty()) return false
        return true
    }

    private fun sensitive(product: Product): Boolean {
        val text = canonical("${product.name} ${product.category} ${product.equivalenceKey}")
        if (Regex("formulas?.*(infanti[ls]|bebe|lactente)").containsMatchIn(text)) return true
        return listOf("formula infantil", "formula para", "lactente", "raticida", "inseticida", "acido", "soda caustica")
            .any { it in text }
    }

    private fun chemical(product: Product): Boolean {
        val text = canonical("${product.name} ${product.category} ${product.equivalenceKey}")
        return listOf("limpeza", "quimic", "detergente", "desinfetante", "agua sanitaria", "alvejante", "cloro", "amonia", "amonio", "limpador")
            .any { it in text }
    }

    private fun favoriteBrands(product: Product, settings: AISettings): Set<String> {
        val configured = settings.favoriteBrands.entries.firstOrNull { canonical(it.key) == canonical(product.category) }
            ?.value.orEmpty().map(::canonical).toSet()
        if (configured.isNotEmpty()) return configured
        return if (settings.mode == RecommendationMode.FAVORITE_BRANDS && product.brand.isNotBlank()) setOf(canonical(product.brand))
            else emptySet()
    }

    private fun valueScore(alternative: Alternative, favorites: Set<String>): BigDecimal {
        // Preferências registradas têm peso explícito; nenhuma nota de qualidade é inventada.
        val preference = when {
            alternative.product.accepted -> BigDecimal("0.90")
            canonical(alternative.product.brand) in favorites -> BigDecimal("0.95")
            else -> BigDecimal.ONE
        }
        return alternative.normalizedUnitPrice.multiply(preference)
    }

    private fun latestPrices(prices: List<PriceObservation>): List<PriceObservation> {
        val now = clock()
        return prices.filter { it.priceCents >= 0 && it.observedAt > 0 && it.observedAt <= now && (it.validUntil == null || it.validUntil >= now) }
            .groupBy { it.productId to it.storeId }.values.map { observations ->
                observations.maxWithOrNull(compareBy<PriceObservation> { it.observedAt }
                    .thenBy { sourcePriority(it.source) }.thenBy { it.id })!!
            }
    }

    private fun sourcePriority(source: PriceSource): Int = when (source) {
        PriceSource.USER_CONFIRMED -> 3
        PriceSource.ADVERTISED -> 2
        PriceSource.HISTORICAL -> 1
        PriceSource.ESTIMATED -> 0
    }

    private fun explanation(original: Product, product: Product, price: PriceObservation, quantity: String,
        settings: AISettings, storeId: Long?, outside: Boolean): String {
        val basis = when (settings.mode) {
            RecommendationMode.MAXIMUM_SAVINGS -> "Custo para a quantidade necessária; comparação por ${UnitNormalizer.dimension(product)}."
            RecommendationMode.BEST_VALUE -> if (product.accepted) "Marca/produto já aceito por você e preço por ${UnitNormalizer.dimension(product)}."
                else "Comparação do preço por ${UnitNormalizer.dimension(product)} e das preferências registradas."
            RecommendationMode.FAVORITE_BRANDS -> if (outside) "Alternativa opcional fora das marcas favoritas. Nenhuma troca é automática."
                else "Prioridade às suas marcas favoritas; nenhuma troca é automática."
        }
        val source = when (price.source) {
            PriceSource.USER_CONFIRMED -> "Preço informado/confirmado pelo usuário"
            PriceSource.HISTORICAL -> "Preço histórico; não é um preço atual confirmado"
            PriceSource.ADVERTISED -> "Preço anunciado; confirme as condições e a disponibilidade"
            PriceSource.ESTIMATED -> "Preço estimado; não confirmado"
        }
        val date = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(price.observedAt))
        val place = if (price.storeId != storeId) " Outro mercado (#${price.storeId}); confirme o deslocamento e a compra nesse local." else ""
        val packs = if (product.saleUnit == MeasurementUnit.UNIT && product.packageUnit != MeasurementUnit.UNIT)
            " São necessárias $quantity embalagens de ${product.packageQuantity} ${product.packageUnit.label}." else ""
        val promotion = if (price.promotion.isBlank()) "" else " Condição registrada: ${price.promotion}."
        return "$basis Equivalência cadastrada: ${original.equivalenceKey}. $source em $date. Fonte: ${price.sourceName}.$place$packs$promotion Revise antes de confirmar."
    }

    private fun canonical(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT).trim()
}
