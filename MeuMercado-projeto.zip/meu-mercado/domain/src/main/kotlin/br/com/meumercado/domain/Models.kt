package br.com.meumercado.domain

import java.math.BigDecimal

enum class RecommendationMode { MAXIMUM_SAVINGS, BEST_VALUE, FAVORITE_BRANDS }
enum class ItemStatus { PENDING, IN_CART, UNAVAILABLE, REMOVED }
enum class MeasurementUnit(val label: String) { UNIT("un"), KG("kg"), G("g"), L("L"), ML("ml") }
enum class PriceSource { USER_CONFIRMED, HISTORICAL, ADVERTISED, ESTIMATED }
enum class ThemeChoice { SYSTEM, LIGHT, DARK }

data class Product(
    val id: Long = 0, val name: String, val brand: String = "", val category: String = "Outros",
    val tags: Set<String> = emptySet(), val barcode: String? = null, val photoUri: String? = null,
    val saleUnit: MeasurementUnit = MeasurementUnit.UNIT, val packageQuantity: String = "1",
    val packageUnit: MeasurementUnit = MeasurementUnit.UNIT, val equivalenceKey: String = "",
    val essentialCharacteristics: Set<String> = emptySet(), val restrictions: Set<String> = emptySet(),
    val favorite: Boolean = false, val neverSubstitute: Boolean = false,
    val accepted: Boolean = false, val notes: String = ""
)
data class Store(val id: Long = 0, val name: String, val address: String = "", val neighborhood: String = "", val city: String = "", val notes: String = "", val distanceKm: String? = null, val favorite: Boolean = false)
data class ShoppingList(val id: Long = 0, val name: String, val storeId: Long? = null, val favorite: Boolean = false, val archived: Boolean = false, val template: Boolean = false, val cadence: String = "Avulsa", val createdAt: Long = System.currentTimeMillis())
data class ShoppingListItem(val id: Long = 0, val listId: Long, val productId: Long, val quantity: String = "1", val estimatedPriceCents: Long = 0, val actualPriceCents: Long? = null, val discountCents: Long = 0, val status: ItemStatus = ItemStatus.PENDING, val priority: Int = 1, val notes: String = "", val position: Int = 0)
data class BudgetSettings(val listId: Long, val totalCents: Long = 0, val safetyCents: Long = 0, val safetyPercent: String = "0", val maximumCents: Long? = null, val alertThresholds: Set<Int> = setOf(50,75,90,100))
data class AISettings(val mode: RecommendationMode = RecommendationMode.MAXIMUM_SAVINGS, val favoriteBrands: Map<String, Set<String>> = emptyMap(), val onlineConsent: Boolean = false, val gatewayUrl: String = "", val theme: ThemeChoice = ThemeChoice.SYSTEM, val activeListId: Long? = null, val notificationsEnabled: Boolean = false, val learnedPreferencesEnabled: Boolean = true)
data class PriceObservation(val id: Long = 0, val productId: Long, val storeId: Long, val priceCents: Long, val observedAt: Long = System.currentTimeMillis(), val source: PriceSource = PriceSource.USER_CONFIRMED, val sourceName: String = "Informado pelo usuário", val promotion: String = "", val validUntil: Long? = null)
data class TaxRecord(val id: Long = 0, val historyId: Long, val amountCents: Long, val documented: Boolean = true, val includedInPrice: Boolean = true, val source: String = "Informado na nota fiscal")
data class HistoryItem(val productName: String, val brand: String, val category: String, val productId: Long, val quantity: String, val unit: MeasurementUnit, val unitPriceCents: Long, val discountCents: Long, val totalCents: Long, val estimatedTotalCents: Long, val substituted: Boolean = false)
data class ShoppingHistory(val id: Long = 0, val listName: String, val storeId: Long?, val storeName: String, val completedAt: Long = System.currentTimeMillis(), val items: List<HistoryItem>, val totalCents: Long, val budgetCents: Long, val estimatedCents: Long, val receiptUri: String? = null)
data class RecommendationDecision(val id: Long = 0, val itemId: Long, val oldProductId: Long, val newProductId: Long, val acceptedAt: Long = System.currentTimeMillis(), val savingsCents: Long = 0)
data class AppSnapshot(val products: List<Product> = emptyList(), val stores: List<Store> = emptyList(), val lists: List<ShoppingList> = emptyList(), val items: List<ShoppingListItem> = emptyList(), val budgets: List<BudgetSettings> = emptyList(), val prices: List<PriceObservation> = emptyList(), val history: List<ShoppingHistory> = emptyList(), val taxes: List<TaxRecord> = emptyList(), val decisions: List<RecommendationDecision> = emptyList(), val searchHistory: List<String> = emptyList())
data class BudgetSummary(val operationalLimitCents: Long, val cartCents: Long, val pendingCents: Long, val projectedCents: Long, val remainingCents: Long, val usedPercent: BigDecimal, val cartCount: Int, val pendingCount: Int, val alert: Int?)
data class Alternative(val product: Product, val observation: PriceObservation, val quantity: String, val totalCents: Long, val normalizedUnitPrice: BigDecimal, val normalizedUnit: String, val savingsCents: Long, val savingsPercent: BigDecimal, val reason: String, val optionalOutsideFavorites: Boolean = false)
data class ItemRecommendation(val item: ShoppingListItem, val original: Product, val alternatives: List<Alternative>)
data class Optimization(val originalCents: Long, val optimizedCents: Long, val suggestions: List<ItemRecommendation>, val duplicates: List<String>, val missingPrices: Int)
data class StoreComparison(val store: Store, val knownTotalCents: Long, val comparableCount: Int, val missingCount: Int, val oldestObservation: Long?, val latestObservation: Long?)
data class OcrDraft(val name: String = "", val priceCents: Long? = null, val unit: MeasurementUnit = MeasurementUnit.UNIT, val packageQuantity: String = "1", val packageUnit: MeasurementUnit = MeasurementUnit.UNIT, val barcode: String? = null, val promotion: String = "", val rawText: String = "", val warnings: List<String> = emptyList())
data class AssistantReply(val text: String, val recommendations: List<ItemRecommendation> = emptyList())
