package br.com.meumercado.domain

import java.text.Normalizer
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Assistente por regras: usa somente registros locais, sem gerar preços ou alterar dados. */
class LocalAssistant(
    private val engine: RecommendationEngine = RecommendationEngine(),
    private val nowMillis: () -> Long = System::currentTimeMillis,
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {
    fun reply(query: String, snapshot: AppSnapshot, settings: AISettings): AssistantReply {
        val normalized = normalize(query)
        val optimizationRequested = normalized.contains("otimiz") || normalized.contains("economiz") ||
            normalized.contains("trocando") || normalized.contains("troque")
        val list = snapshot.lists.firstOrNull { it.id == settings.activeListId }
            ?: snapshot.lists.firstOrNull { !it.archived }
        val items = snapshot.items.filter { it.listId == list?.id }
        val products = snapshot.products.associateBy(Product::id)
        val budget = list?.let { active -> snapshot.budgets.firstOrNull { it.listId == active.id } }
        if (normalized.isBlank()) return AssistantReply(help(settings))
        if (normalized.contains("tribut") || normalized.contains("imposto")) return taxes(snapshot, normalized)
        if (normalized.contains("gastei") || normalized.contains("gastos") || normalized.contains("gasto mensal")) {
            return spending(snapshot, normalized)
        }
        if (normalized.contains("recorrent") || normalized.contains("mais comprad")) return recurring(snapshot)
        if (normalized.contains("faltam") || normalized.contains("pendente")) {
            val pending = items.filter { it.status == ItemStatus.PENDING }
            return AssistantReply(if (list == null) "Crie ou selecione uma lista de compras." else if (pending.isEmpty())
                "Não há produtos pendentes na lista ${list.name}." else "Ainda ${if (pending.size == 1) "falta 1 produto" else "faltam ${pending.size} produtos"}: " +
                pending.joinToString { "${products[it.productId]?.name ?: "Produto #${it.productId}"} (${it.quantity})" } + ".")
        }
        if (!optimizationRequested && (normalized.contains("saldo") || normalized.contains("orcamento") || normalized.contains("ainda posso") ||
            (normalized.contains("quanto") && normalized.contains("gastar")))) {
            if (list == null) return AssistantReply("Crie ou selecione uma lista de compras.")
            if (budget == null) return AssistantReply("Defina o orçamento e a margem de segurança da lista ${list.name} para consultar o saldo.")
            val summary = BudgetCalculator.calculate(items, budget)
            return AssistantReply("Você tem ${Money.format(summary.remainingCents)} de saldo operacional. " +
                "O carrinho contém ${Money.format(summary.cartCents)}; os pendentes são estimados em ${Money.format(summary.pendingCents)}. " +
                "A projeção completa é ${Money.format(summary.projectedCents)}, para um limite de ${Money.format(summary.operationalLimitCents)}.")
        }
        if (normalized.contains("mais caro")) {
            val candidate = items.filter { it.status in setOf(ItemStatus.IN_CART, ItemStatus.PENDING) }
                .maxByOrNull { itemSubtotal(it) }
                ?: return AssistantReply("Não há produtos com valores na lista ativa.")
            val source = if (candidate.status == ItemStatus.IN_CART && candidate.actualPriceCents != null) "preço encontrado" else "preço estimado"
            return AssistantReply("O maior subtotal é ${products[candidate.productId]?.name ?: "Produto #${candidate.productId}"}: " +
                "${Money.format(itemSubtotal(candidate))} para ${candidate.quantity}, com $source.")
        }
        if (normalized.contains("mercado") && (normalized.contains("menor") || normalized.contains("compar") || normalized.contains("barato"))) {
            return compareMarkets(snapshot, settings, items, normalized)
        }
        if (optimizationRequested) {
            if (list == null) return AssistantReply("Crie ou selecione uma lista para calcular alternativas de economia.")
            val optimization = engine.optimize(items, snapshot.products,
                snapshot.prices, settings, list.storeId)
            val savings = optimization.originalCents - optimization.optimizedCents
            val request = Regex("r\\$\\s*(\\d{1,3}(?:\\.\\d{3})+(?:,\\d{1,2})?|\\d+(?:[,.]\\d{1,2})?)(?!\\d|[,.]\\d)")
                .find(normalized)?.groupValues?.get(1)
                ?.let { runCatching { Money.parseCents(it) }.getOrNull() }
            val message = if (optimization.suggestions.isEmpty()) "Não encontrei substituições econômicas compatíveis nos dados locais deste mercado. " else
                "A estimativa original é ${Money.format(optimization.originalCents)} e a otimizada é ${Money.format(optimization.optimizedCents)}. " +
                    "A economia potencial é ${Money.format(savings)}. "
            val target = if (request != null && request > savings) "Os dados locais ainda não permitem alcançar a meta de ${Money.format(request)}. " else ""
            val duplicates = if (optimization.duplicates.isNotEmpty()) "Há possíveis duplicados: ${optimization.duplicates.joinToString()}. " else ""
            return AssistantReply(message + target + duplicates + modeText(settings.mode) +
                " São sugestões baseadas em preços registrados, não uma garantia de disponibilidade atual. Confirme cada troca; nada foi alterado.", optimization.suggestions)
        }
        if (normalized.contains("barat") || normalized.contains("alternativ") || normalized.contains("equivalente") || normalized.contains("substitu")) {
            if (list == null) return AssistantReply("Crie ou selecione uma lista para comparar alternativas.")
            val terms = productTerms(normalized)
            val matching = items.filter { it.status in setOf(ItemStatus.PENDING, ItemStatus.IN_CART) }
                .filter { item -> products[item.productId]?.let { matches(it, terms) } == true }
            val recommendations = matching.mapNotNull { item ->
                val original = products[item.productId] ?: return@mapNotNull null
                val alternatives = engine.alternatives(item, snapshot.products, snapshot.prices, settings, list.storeId)
                    .filter { it.savingsCents > 0 }
                if (alternatives.isEmpty()) null else ItemRecommendation(item, original, alternatives)
            }
            if (recommendations.isEmpty()) return AssistantReply("Não encontrei alternativas equivalentes com preços locais suficientes para essa consulta. " +
                "Registre preços e características essenciais dos produtos. ${modeText(settings.mode)}")
            return AssistantReply("Encontrei ${recommendations.sumOf { it.alternatives.size }} alternativas nos dados locais. " +
                "${modeText(settings.mode)} Confira mercado, data, condições e fonte do preço. A substituição exige confirmação; nada foi alterado.", recommendations)
        }
        if (normalized.contains("online") || normalized.contains("internet") || normalized.contains("pesquis")) {
            return AssistantReply(if (!settings.onlineConsent || settings.gatewayUrl.isBlank())
                "A IA online não está disponível: configure um gateway HTTPS e autorize o envio de dados nas configurações. As recomendações locais continuam funcionando sem internet."
            else "Esta resposta usa dados locais. Consultas online devem ser feitas pelo gateway configurado; ainda não consultei nenhuma fonte externa.")
        }
        return AssistantReply(help(settings))
    }

    private fun compareMarkets(snapshot: AppSnapshot, settings: AISettings, items: List<ShoppingListItem>, query: String): AssistantReply {
        val terms = productTerms(query)
        val matchingProducts = snapshot.products.filter { matches(it, terms) }
        val matchingIds = matchingProducts.map { it.id }.toSet()
        val selectedItems = if (terms.isEmpty()) items.filter { it.status in setOf(ItemStatus.PENDING, ItemStatus.IN_CART) }
            else items.filter { it.productId in matchingIds && it.status in setOf(ItemStatus.PENDING, ItemStatus.IN_CART) }
        if (selectedItems.isNotEmpty()) {
            val comparisons = engine.compareStores(selectedItems, snapshot.products, snapshot.prices, snapshot.stores)
                .filter { it.comparableCount > 0 }.sortedBy { it.knownTotalCents }
            if (comparisons.isEmpty()) return AssistantReply("Não há preços registrados suficientes para comparar os mercados.")
            return AssistantReply(comparisons.joinToString("\n") {
                "${it.store.name}: ${Money.format(it.knownTotalCents)} conhecidos, ${it.comparableCount} produtos comparáveis e ${it.missingCount} sem preço. " +
                    "Registro mais recente: ${it.latestObservation?.let(::date) ?: "não informado"}."
            } + "\nTotais parciais não definem o mercado mais barato. Os registros não garantem preço ou disponibilidade atuais. ${modeText(settings.mode)}")
        }
        val now = nowMillis()
        val known = snapshot.prices.filter { it.productId in matchingIds && it.priceCents >= 0 && it.observedAt > 0 && it.observedAt <= now &&
            (it.validUntil == null || it.validUntil >= now) }
            .groupBy { it.productId to it.storeId }.values.map { group -> group.maxBy { it.observedAt } }
        if (known.isEmpty()) return AssistantReply("Não há preços locais para esse produto; não posso afirmar qual mercado oferece o menor valor.")
        return AssistantReply(known.sortedBy { observation ->
            UnitNormalizer.pricePerStandardUnit(observation.priceCents, matchingProducts.first { it.id == observation.productId })
        }.joinToString("\n") { observation ->
            val product = matchingProducts.first { it.id == observation.productId }
            val store = snapshot.stores.firstOrNull { it.id == observation.storeId }?.name ?: "Mercado #${observation.storeId}"
            val packaging = if (product.saleUnit == MeasurementUnit.UNIT) "embalagem de ${product.packageQuantity} ${product.packageUnit.label}" else product.saleUnit.label
            val normalizedPrice = UnitNormalizer.pricePerStandardUnit(observation.priceCents, product)
                .setScale(2, java.math.RoundingMode.HALF_UP).toPlainString().replace('.', ',')
            "${product.name} — $store: ${Money.format(observation.priceCents)} por $packaging " +
                "(R$ $normalizedPrice/${UnitNormalizer.dimension(product)}); " +
                "${date(observation.observedAt)}, ${sourceText(observation.source)}, ${observation.sourceName}."
        } + "\nEmbalagens diferentes devem ser comparadas por kg, litro ou unidade. Preços registrados não comprovam disponibilidade atual.")
    }

    private fun spending(snapshot: AppSnapshot, query: String): AssistantReply {
        if (Regex("\\b(semana|ano|anos|dia|dias)\\b").containsMatchIn(query)) {
            return AssistantReply("No chat local, consulte os gastos deste mês ou do mês passado. Use os relatórios para filtrar outros períodos.")
        }
        val now = Instant.ofEpochMilli(nowMillis()).atZone(zoneId)
        val startThisMonth = now.withDayOfMonth(1).toLocalDate().atStartOfDay(zoneId)
        val previous = query.contains("ultimo mes") || query.contains("mes passado")
        val start = if (previous) startThisMonth.minusMonths(1) else startThisMonth
        val end = if (previous) startThisMonth else now.plusNanos(1_000_000)
        val history = snapshot.history.filter { it.completedAt >= start.toInstant().toEpochMilli() && it.completedAt < end.toInstant().toEpochMilli() }
        val category = snapshot.history.flatMap { it.items }.map { it.category }.filter(String::isNotBlank).distinct()
            .sortedByDescending(String::length)
            .firstOrNull { normalize(query).contains(normalize(it)) }
        val requestedCategory = Regex("\\bcom\\s+(.+?)(?:\\s+(?:no|neste|nesse|durante|em)\\b|[?!.]|$)")
            .find(query)?.groupValues?.get(1)?.trim()
        if (category == null && requestedCategory != null && requestedCategory !in setOf("compras", "as compras", "mercado", "supermercado")) {
            return AssistantReply("Não há registros da categoria solicitada ($requestedCategory) nas compras locais. Não posso calcular esse gasto com os dados disponíveis.")
        }
        if (history.isEmpty()) return AssistantReply("Não há compras finalizadas registradas ${if (previous) "no último mês" else "neste mês"}.")
        val total = if (category == null) sumCents(history.map { it.totalCents })
            else sumCents(history.flatMap { it.items }.filter { it.category == category }.map { it.totalCents })
        return AssistantReply("Você gastou ${Money.format(total)}${category?.let { " em $it" }.orEmpty()} " +
            "${if (previous) "no último mês" else "neste mês"}, com base nas compras finalizadas de " +
            "${date(start.toInstant().toEpochMilli())} até ${if (previous) date(end.minusDays(1).toInstant().toEpochMilli()) else date(nowMillis())}.")
    }

    private fun taxes(snapshot: AppSnapshot, query: String): AssistantReply {
        val selectedIds = if (query.contains("mes")) {
            val now = Instant.ofEpochMilli(nowMillis()).atZone(zoneId)
            val end = now.withDayOfMonth(1).toLocalDate().atStartOfDay(zoneId)
            val previous = query.contains("ultimo mes") || query.contains("mes passado")
            val start = if (previous) end.minusMonths(1) else end
            snapshot.history.filter { it.completedAt >= start.toInstant().toEpochMilli() &&
                it.completedAt < (if (previous) end else now.plusNanos(1_000_000)).toInstant().toEpochMilli() }.map { it.id }.toSet()
        } else snapshot.history.map { it.id }.toSet()
        val taxes = snapshot.taxes.filter { it.historyId in selectedIds }
        if (taxes.isEmpty()) return AssistantReply("Tributos não informados.")
        val documented = sumCents(taxes.filter { it.documented }.map { it.amountCents })
        val estimated = sumCents(taxes.filterNot { it.documented }.map { it.amountCents })
        return AssistantReply("Tributos documentados: ${Money.format(documented)}. Estimativas identificadas: ${Money.format(estimated)}. " +
            "Valores incluídos no preço não são somados novamente ao total da compra.")
    }

    private fun recurring(snapshot: AppSnapshot): AssistantReply {
        val counts = snapshot.history.flatMap { purchase -> purchase.items.map { it.productName to it.brand }.distinct() }
            .groupBy { it }
            .mapValues { it.value.size }.entries.sortedByDescending { it.value }.take(5)
        return AssistantReply(if (counts.isEmpty()) "Não há compras finalizadas para identificar produtos recorrentes." else
            "Produtos mais recorrentes nos registros locais: " + counts.joinToString {
                "${it.key.first} ${it.key.second} (${it.value} ${if (it.value == 1) "compra" else "compras"})"
            } + ".")
    }

    private fun itemSubtotal(item: ShoppingListItem): Long = Money.subtotal(
        if (item.status == ItemStatus.IN_CART) item.actualPriceCents ?: item.estimatedPriceCents else item.estimatedPriceCents,
        item.quantity, item.discountCents)
    private fun sumCents(values: List<Long>): Long = values.fold(0L, Money::add)
    private fun matches(product: Product, terms: Set<String>): Boolean {
        val words = normalize("${product.name} ${product.brand} ${product.category} ${product.tags.joinToString(" ")}")
        return terms.isEmpty() || terms.all { words.contains(it) }
    }
    private fun productTerms(query: String): Set<String> = query.split(Regex("[^a-z0-9]+"))
        .filter { it.length >= 3 && it !in stopWords }.toSet()
    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    private fun date(value: Long): String = Instant.ofEpochMilli(value).atZone(zoneId).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    private fun sourceText(source: PriceSource) = when (source) {
        PriceSource.USER_CONFIRMED -> "preço informado pelo usuário"
        PriceSource.HISTORICAL -> "preço histórico"
        PriceSource.ADVERTISED -> "preço anunciado"
        PriceSource.ESTIMATED -> "preço estimado"
    }
    private fun modeText(mode: RecommendationMode) = when (mode) {
        RecommendationMode.MAXIMUM_SAVINGS -> "Modo Máxima Economia: priorizo menor custo comparável, respeitando as restrições."
        RecommendationMode.BEST_VALUE -> "Modo Melhor Custo-Benefício: considero custo unitário e preferências objetivamente registradas."
        RecommendationMode.FAVORITE_BRANDS -> "Modo Minhas Marcas Favoritas: priorizo suas marcas favoritas; outras marcas são alternativas opcionais."
    }
    private fun help(settings: AISettings) = "Posso consultar saldo, produtos pendentes, gastos mensais e tributos, comparar mercados e buscar alternativas com dados locais. " +
        modeText(settings.mode) + " Não altero listas sem sua confirmação."
    private companion object {
        val stopWords = setOf("encontre", "encontrar", "procure", "buscar", "pesquise", "pesquisar", "mais", "menos", "barato", "barata", "baratos", "baratas", "alternativa", "alternativas", "equivalente", "equivalentes", "substituir", "substituicao", "produto", "produtos", "qual", "quais", "para", "uma", "por", "com", "meu", "minha", "menor", "preco", "mercado", "mercados", "teve", "tem", "comparar", "compare", "marca", "marcas", "favorita", "favoritas", "compra", "lista", "nesta", "neste", "desta", "deste", "outra", "outras", "outro", "outros", "opcao", "opcoes", "hoje")
    }
}
