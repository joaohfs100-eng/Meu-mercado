package br.com.meumercado.domain

import java.math.BigDecimal
import java.math.RoundingMode

object BudgetCalculator {
    /** Quando as duas margens estão configuradas, ambas são reservadas. */
    fun calculate(items: List<ShoppingListItem>, settings: BudgetSettings): BudgetSummary {
        require(settings.totalCents >= 0 && settings.safetyCents >= 0) { "Orçamento e margem devem ser positivos." }
        require(settings.maximumCents == null || settings.maximumCents >= 0) { "Limite inválido." }
        val percent = Money.decimal(settings.safetyPercent)
        require(percent >= BigDecimal.ZERO && percent <= BigDecimal(100)) { "A margem percentual deve ficar entre 0 e 100%." }
        val percentReserve = Money.exactLong(BigDecimal.valueOf(settings.totalCents).multiply(percent)
            .divide(BigDecimal(100), 0, RoundingMode.HALF_UP))
        // Reserva além do orçamento equivale a limite zero, sem overflow ao somar margens.
        val afterFixedReserve = settings.totalCents - settings.safetyCents.coerceAtMost(settings.totalCents)
        val operational = (afterFixedReserve - percentReserve).coerceAtLeast(0)
            .let { minOf(it, settings.maximumCents ?: it) }
        val current = items.filter { it.listId == settings.listId }
        val cart = current.filter { it.status == ItemStatus.IN_CART }
        val pending = current.filter { it.status == ItemStatus.PENDING }
        val cartTotal = cart.fold(0L) { sum, item -> Money.add(sum, total(item)) }
        val pendingTotal = pending.fold(0L) { sum, item -> Money.add(sum, total(item)) }
        val usedPercent = if (operational == 0L) {
            if (cartTotal == 0L) BigDecimal.ZERO else BigDecimal(100)
        } else BigDecimal.valueOf(cartTotal).multiply(BigDecimal(100))
            .divide(BigDecimal.valueOf(operational), 2, RoundingMode.HALF_UP)
        val alert = if (cartTotal > operational) 101 else settings.alertThresholds
            .filter { it in 1..100 && usedPercent >= BigDecimal(it) }.maxOrNull()
        return BudgetSummary(operational, cartTotal, pendingTotal, Money.add(cartTotal, pendingTotal),
            operational - cartTotal, usedPercent, cart.size, pending.size, alert)
    }

    internal fun total(item: ShoppingListItem): Long = Money.subtotal(
        if (item.status == ItemStatus.IN_CART) item.actualPriceCents ?: item.estimatedPriceCents else item.estimatedPriceCents,
        item.quantity, item.discountCents
    )
}
