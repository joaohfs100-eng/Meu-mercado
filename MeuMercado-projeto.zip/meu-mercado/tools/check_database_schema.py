#!/usr/bin/env python3
"""Exercise SQLite relationships from Room entity metadata without an Android runtime.

This checks SQL integrity and the migration. It does not execute Room/Kotlin or replace
the Android tests. Run: python3 tools/check_database_schema.py
"""

from __future__ import annotations

import json
import re
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENTITY_SOURCE = ROOT / "app/src/main/java/br/com/meumercado/database/Entities.kt"
DATABASE_SOURCE = ROOT / "app/src/main/java/br/com/meumercado/database/MarketDatabase.kt"


def balanced_end(text: str, start: int) -> int:
    depth, quoted, escaped = 0, False, False
    for pos in range(start, len(text)):
        char = text[pos]
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return pos
    raise AssertionError("Unbalanced Kotlin declaration")


def parameters(text: str) -> list[str]:
    result, start, depth, quoted, escaped = [], 0, 0, False, False
    for pos, char in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "([{":
            depth += 1
        elif char in ")]}":
            depth -= 1
        elif char == "," and depth == 0:
            result.append(text[start:pos].strip())
            start = pos + 1
    result.append(text[start:].strip())
    return result


def metadata() -> dict[str, dict]:
    source = ENTITY_SOURCE.read_text()
    entities = {}
    for match in re.finditer(r"@Entity\(", source):
        annotation_end = balanced_end(source, match.end() - 1)
        annotation = source[match.end():annotation_end]
        declaration = re.search(r"data class (\w+)\(", source[annotation_end:])
        assert declaration
        class_start = annotation_end + declaration.end() - 1
        class_end = balanced_end(source, class_start)
        table = re.search(r'tableName\s*=\s*"([^"]+)"', annotation).group(1)
        fields = []
        for parameter in parameters(source[class_start + 1:class_end]):
            field = re.search(r"val\s+(\w+):\s*(\w+\??)", parameter)
            assert field, parameter
            default = re.search(r'@ColumnInfo\(defaultValue\s*=\s*"([^"]+)"\)', parameter)
            fields.append({"name": field.group(1), "type": field.group(2), "primary": "@PrimaryKey" in parameter,
                           "auto": "autoGenerate = true" in parameter, "default": default.group(1) if default else None})
        primary = re.search(r"primaryKeys\s*=\s*\[([^\]]+)\]", annotation)
        primary = re.findall(r'"([^"]+)"', primary.group(1)) if primary else [f["name"] for f in fields if f["primary"]]
        indices = []
        for index in re.finditer(r"Index\((.*?)\)", annotation, re.S):
            indices.append((re.findall(r'"([^"]+)"', index.group(1)), "unique = true" in index.group(1)))
        foreign = []
        for fk in re.finditer(r"ForeignKey\((.*?)\)", annotation, re.S):
            text = fk.group(1)
            parent = re.search(r"entity\s*=\s*(\w+)::class", text).group(1)
            parent_columns = re.findall(r'"([^"]+)"', re.search(r"parentColumns\s*=\s*\[([^\]]+)\]", text).group(1))
            child_columns = re.findall(r'"([^"]+)"', re.search(r"childColumns\s*=\s*\[([^\]]+)\]", text).group(1))
            action = re.search(r"onDelete\s*=\s*ForeignKey\.(\w+)", text).group(1).replace("_", " ")
            foreign.append((parent, parent_columns, child_columns, action))
        entities[declaration.group(1)] = {"table": table, "fields": fields, "primary": primary, "indices": indices, "foreign": foreign}
    return entities


ENTITIES = metadata()
TABLES = list(re.findall(r'"([^"]+)"', DATABASE_SOURCE.read_text().split("val TABLES = listOf(", 1)[1].split(")", 1)[0]))


def create_database(version: int = 2) -> sqlite3.Connection:
    connection = sqlite3.connect(":memory:")
    connection.execute("PRAGMA foreign_keys = ON")
    types = {"Long": "INTEGER", "Int": "INTEGER", "Boolean": "INTEGER", "String": "TEXT"}
    for entity in ENTITIES.values():
        definitions = []
        for field in entity["fields"]:
            if version == 1 and entity["table"] == "products" and field["name"] == "accepted":
                continue
            definition = f'`{field["name"]}` {types[field["type"].rstrip("?")]}'
            if not field["type"].endswith("?"):
                definition += " NOT NULL"
            if field["primary"]:
                definition += " PRIMARY KEY"
                if field["auto"]:
                    definition += " AUTOINCREMENT"
            if field["default"] is not None:
                definition += f' DEFAULT {field["default"]}'
            definitions.append(definition)
        if len(entity["primary"]) > 1:
            definitions.append("PRIMARY KEY (" + ", ".join(f"`{name}`" for name in entity["primary"]) + ")")
        for parent, parent_columns, child_columns, action in entity["foreign"]:
            definitions.append("FOREIGN KEY (" + ", ".join(f"`{name}`" for name in child_columns) + ") REFERENCES `" +
                               ENTITIES[parent]["table"] + "` (" + ", ".join(f"`{name}`" for name in parent_columns) + f") ON DELETE {action}")
        connection.execute(f'CREATE TABLE `{entity["table"]}` (' + ", ".join(definitions) + ")")
        for columns, unique in entity["indices"]:
            name = "index_" + entity["table"] + "_" + "_".join(columns)
            connection.execute(f'CREATE {"UNIQUE " if unique else ""}INDEX `{name}` ON `{entity["table"]}` (' + ", ".join(f"`{column}`" for column in columns) + ")")
    return connection


def insert(connection: sqlite3.Connection, table: str, **overrides):
    entity = next(entity for entity in ENTITIES.values() if entity["table"] == table)
    actual_columns = {row[1] for row in connection.execute(f"PRAGMA table_info(`{table}`)")}
    row = {}
    for field in entity["fields"]:
        if field["name"] not in actual_columns:
            continue
        row[field["name"]] = None if field["type"].endswith("?") else "" if field["type"] == "String" else 0
    row.update(overrides)
    names = list(row)
    connection.execute(f"INSERT INTO `{table}` ({','.join(f'`{name}`' for name in names)}) VALUES ({','.join('?' for _ in names)})", [row[name] for name in names])


def seed(connection: sqlite3.Connection):
    insert(connection, "product_categories", id=1, name="Alimentação")
    insert(connection, "brands", id=1, name="Marca")
    insert(connection, "stores", id=1, name="Mercado")
    insert(connection, "products", id=42, name="Arroz", categoryId=1, brandId=1, barcode="7891234567895",
           saleUnit="UNIT", packageQuantity="1", packageUnit="KG", characteristics="[]", restrictions="[]")
    insert(connection, "shopping_lists", id=10, name="Semana", storeId=1, createdAt=1)
    insert(connection, "shopping_list_items", id=20, listId=10, productId=42, quantity="0.75", estimatedPriceCents=1000,
           actualPriceCents=800, discountCents=50, status="IN_CART")
    insert(connection, "price_observations", id=30, productId=42, storeId=1, priceCents=800, observedAt=1, source="USER_CONFIRMED", sourceName="Usuário")
    insert(connection, "shopping_history", id=40, listName="Semana", storeId=1, storeName="Mercado", completedAt=2,
           totalCents=550, estimatedCents=750)
    insert(connection, "history_items", id=50, historyId=40, productId=42, productName="Arroz", brand="Marca", category="Alimentação",
           unit="UNIT", quantity="0.75", unitPriceCents=800, discountCents=50, totalCents=550, estimatedTotalCents=750)
    connection.commit()


class SQLiteIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.db = create_database()
        seed(self.db)

    def tearDown(self):
        self.db.close()

    def test_all_entities_and_backup_tables_match(self):
        self.assertEqual(24, len(ENTITIES))
        self.assertEqual(set(TABLES), {entity["table"] for entity in ENTITIES.values()})
        self.assertEqual([], self.db.execute("PRAGMA foreign_key_check").fetchall())

    def test_each_foreign_key_is_indexed_and_set_null_is_nullable(self):
        for entity in ENTITIES.values():
            for _, _, children, action in entity["foreign"]:
                indices = [entity["primary"]] + [columns for columns, _ in entity["indices"]]
                self.assertTrue(any(index[:len(children)] == children for index in indices), (entity["table"], children))
                if action == "SET NULL":
                    for child in children:
                        self.assertTrue(next(field["type"].endswith("?") for field in entity["fields"] if field["name"] == child))

    def test_catalogue_edits_and_list_deletion_preserve_historical_snapshot(self):
        self.db.execute("UPDATE products SET name='Renomeado', brandId=NULL WHERE id=42")
        self.db.execute("DELETE FROM shopping_lists WHERE id=10")
        self.assertEqual(0, self.db.execute("SELECT COUNT(*) FROM shopping_list_items").fetchone()[0])
        self.assertEqual(("Arroz", "Marca", 550), self.db.execute("SELECT productName, brand, totalCents FROM history_items WHERE id=50").fetchone())

    def test_deleting_store_detaches_list_and_removes_prices_without_changing_total(self):
        self.db.execute("UPDATE shopping_history SET storeId=NULL WHERE storeId=1")
        self.db.execute("DELETE FROM stores WHERE id=1")
        self.assertIsNone(self.db.execute("SELECT storeId FROM shopping_lists WHERE id=10").fetchone()[0])
        self.assertEqual(0, self.db.execute("SELECT COUNT(*) FROM price_observations").fetchone()[0])
        self.assertEqual(("Mercado", 550), self.db.execute("SELECT storeName, totalCents FROM shopping_history WHERE id=40").fetchone())

    def test_barcode_unique_and_nullable(self):
        with self.assertRaises(sqlite3.IntegrityError):
            insert(self.db, "products", id=43, name="Duplicado", categoryId=1, barcode="7891234567895")
        insert(self.db, "products", id=43, name="Sem código", categoryId=1)
        insert(self.db, "products", id=44, name="Outro sem código", categoryId=1)

    def test_backup_table_order_restores_ids_and_relationships(self):
        backup = {}
        for table in TABLES:
            cursor = self.db.execute(f"SELECT * FROM `{table}`")
            backup[table] = {"columns": [column[0] for column in cursor.description], "rows": cursor.fetchall()}
        backup = json.loads(json.dumps(backup))
        with self.db:
            for table in reversed(TABLES):
                self.db.execute(f"DELETE FROM `{table}`")
            for table in TABLES:
                data = backup[table]
                self.db.executemany(f"INSERT INTO `{table}` ({','.join(data['columns'])}) VALUES ({','.join('?' for _ in data['columns'])})", data["rows"])
        self.assertEqual([], self.db.execute("PRAGMA foreign_key_check").fetchall())
        self.assertEqual((42, "Arroz"), self.db.execute("SELECT id, name FROM products").fetchone())
        self.assertEqual((10, 42), self.db.execute("SELECT listId, productId FROM shopping_list_items").fetchone())

    def test_restore_failure_rolls_back_existing_data(self):
        with self.assertRaises(sqlite3.IntegrityError):
            with self.db:
                for table in reversed(TABLES):
                    self.db.execute(f"DELETE FROM `{table}`")
                insert(self.db, "shopping_list_items", id=1, listId=999, productId=999)
        self.assertEqual((42, "Arroz"), self.db.execute("SELECT id, name FROM products").fetchone())

    def test_actual_one_to_two_migration_preserves_rows_and_adds_default(self):
        old = create_database(version=1)
        try:
            seed(old)
            migration = re.search(r'db\.execSQL\("(ALTER TABLE products[^"\n]+)"\)', DATABASE_SOURCE.read_text()).group(1)
            old.execute(migration)
            self.assertEqual((42, "Arroz", 0), old.execute("SELECT id, name, accepted FROM products").fetchone())
            expected = {row[1]: row[2:] for row in self.db.execute("PRAGMA table_info(products)")}
            actual = {row[1]: row[2:] for row in old.execute("PRAGMA table_info(products)")}
            self.assertEqual(expected, actual)
        finally:
            old.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
