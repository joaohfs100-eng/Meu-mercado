#!/bin/sh
# Reconstrói o bootstrap Java; não compila o aplicativo Android.
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
CLASS_DIR=$(mktemp -d)
trap 'rm -rf "$CLASS_DIR"' EXIT HUP INT TERM
if command -v javac >/dev/null 2>&1; then
    javac --release 17 -d "$CLASS_DIR" "$PROJECT_DIR/gradle/bootstrap/GradleBootstrap.java"
else
    java com.sun.tools.javac.Main -source 17 -target 17 -d "$CLASS_DIR" "$PROJECT_DIR/gradle/bootstrap/GradleBootstrap.java"
fi
java sun.tools.jar.Main --create --file "$PROJECT_DIR/gradle/bootstrap/gradle-bootstrap.jar" --main-class br.com.meumercado.bootstrap.GradleBootstrap -C "$CLASS_DIR" .
