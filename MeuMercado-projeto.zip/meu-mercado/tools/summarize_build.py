#!/usr/bin/env python3
"""Produz resumo legível de um log Gradle sem mudar o resultado da compilação."""
from pathlib import Path
import os
import re

log = Path('meumercado-compilacao.txt')
text = re.sub(r'\x1b\[[0-9;]*m', '', log.read_text(errors='replace') if log.exists() else 'Log indisponível.')
lines = text.splitlines()
status = int(os.environ['MM_BUILD_STATUS'])
if status == 0:
    summary = '## Compilação concluída\n\nBaixe **MeuMercado-APK-debug** na seção **Artifacts** desta execução.\n'
else:
    snippets = []
    for index, line in enumerate(lines):
        if line.strip() in ('* Where:', '* What went wrong:'):
            for following in lines[index:index+25]:
                if following.strip() in ('* Try:', '* Exception is:'):
                    break
                snippets.append(following)
    diagnostics = [line for line in lines if re.search(r'^\s*e:|error:|FAILED|Unresolved reference|Compilation error|Script compilation error', line, re.I)]
    selected = list(dict.fromkeys(snippets + diagnostics))[:45]
    if not selected:
        selected = lines[-35:]
    short = '\n'.join(selected).replace('```', "'''")
    summary = '## Erro principal da compilação\n\nCopie o trecho abaixo e envie nesta conversa.\n\n```text\n' + short + '\n```\n\nO log completo está no arquivo **log-da-compilacao**, em **Artifacts**.\n'
    print('::group::Erro principal da compilação')
    print(short)
    print('::endgroup::')
summary_path = os.environ.get('GITHUB_STEP_SUMMARY')
if summary_path:
    with open(summary_path, 'a', encoding='utf-8') as out:
        out.write(summary)
