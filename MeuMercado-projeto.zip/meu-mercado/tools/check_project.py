#!/usr/bin/env python3
"""Verificação estrutural local. Não compila Kotlin e não substitui testes Android."""
from pathlib import Path
import json
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def consume_quote(source: str, start: int) -> int:
    if source.startswith('"""', start):
        end = source.find('"""', start + 3)
        assert end >= 0, 'String multiline não encerrada'
        return end + 3
    quote = source[start]
    i = start + 1
    while i < len(source):
        if source[i] == '\\':
            i += 2
        elif quote == '"' and source.startswith('${', i):
            i += 2
            depth = 1
            while depth and i < len(source):
                if source[i] in ('"', "'"):
                    i = consume_quote(source, i)
                elif source[i] == '{':
                    depth += 1
                    i += 1
                elif source[i] == '}':
                    depth -= 1
                    i += 1
                else:
                    i += 1
            assert depth == 0, 'Interpolação não encerrada'
        elif source[i] == quote:
            return i + 1
        else:
            i += 1
    raise AssertionError('Literal não encerrado')


def strip_literals(source: str) -> str:
    result = []
    i = 0
    while i < len(source):
        if source.startswith('//', i):
            end = source.find('\n', i)
            i = len(source) if end < 0 else end
        elif source.startswith('/*', i):
            depth = 1
            i += 2
            while depth and i < len(source):
                if source.startswith('/*', i):
                    depth += 1
                    i += 2
                elif source.startswith('*/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            assert depth == 0, 'Comentário não encerrado'
        elif source[i] in ('"', "'"):
            i = consume_quote(source, i)
        else:
            result.append(source[i])
            i += 1
    return ''.join(result)


def main():
    kotlin = sorted(ROOT.glob('**/*.kt')) + sorted(ROOT.glob('**/*.kts'))
    for file in kotlin:
        try:
            clean = strip_literals(file.read_text())
            stack = []
            for char in clean:
                if char in '{([':
                    stack.append(char)
                elif char in '})]':
                    assert stack and stack.pop() == {'}': '{', ')': '(', ']': '['}[char], 'Delimitadores incompatíveis'
            assert not stack, 'Delimitadores não encerrados'
        except AssertionError as error:
            raise AssertionError(f'{file.relative_to(ROOT)}: {error}') from error
    resources = sorted(ROOT.glob('app/src/main/**/*.xml'))
    for file in resources:
        ET.parse(file)
    manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
    android = '{http://schemas.android.com/apk/res/android}'
    application = manifest.find('application')
    assert application.attrib[android + 'allowBackup'] == 'false'
    assert application.attrib[android + 'usesCleartextTraffic'] == 'false'
    assert (ROOT / 'app/src/main/java/br/com/meumercado/MainActivity.kt').exists()
    assert (ROOT / 'app/src/main/java/br/com/meumercado/MeuMercadoApplication.kt').exists()
    assert (ROOT / 'gradle/bootstrap/gradle-bootstrap.jar').stat().st_size > 0
    tests = {}
    for directory in ('domain/src/test', 'app/src/test', 'app/src/androidTest'):
        tests[directory] = sum(len(re.findall(r'@Test\b', file.read_text())) for file in (ROOT / directory).rglob('*.kt'))
    summary = {
        'kotlin_files_structurally_checked': len(kotlin), 'xml_files_parsed': len(resources),
        'test_methods_declared': tests,
        'notice': 'Esta verificação estrutural local não compila Kotlin nem executa testes. Resultados do GitHub estão em docs/RESULTADOS.md.'
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
