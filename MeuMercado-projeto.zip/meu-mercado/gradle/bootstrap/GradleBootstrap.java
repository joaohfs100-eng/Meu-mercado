package br.com.meumercado.bootstrap;

import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.nio.channels.*;
import java.security.*;
import java.time.Duration;
import java.util.*;
import java.util.zip.*;

/**
 * Bootstrap auditável para ambiente sem Gradle instalado. Não é o JAR oficial do Gradle.
 * Resolve exclusivamente a distribuição HTTPS especificada, verifica seu SHA-256,
 * instala no cache e delega todos os argumentos à distribuição real do Gradle.
 * Depois do primeiro download, `./gradlew wrapper` gera o wrapper oficial.
 */
public final class GradleBootstrap {
    public static void main(String[] args) {
        try { System.exit(run(args)); }
        catch (Exception e) {
            System.err.println("Não foi possível iniciar o Gradle: " + e.getMessage());
            System.err.println("Instale Gradle 8.11.1 ou permita HTTPS a services.gradle.org, downloads.gradle.org e GitHub. Consulte README.md.");
            System.exit(1);
        }
    }

    private static int run(String[] args) throws Exception {
        Path project = Path.of(System.getProperty("meumercado.projectDir", ".")).toAbsolutePath().normalize();
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(project.resolve("gradle/wrapper/gradle-wrapper.properties"))) { props.load(in); }
        URI distribution = URI.create(props.getProperty("distributionUrl"));
        if (!"https".equalsIgnoreCase(distribution.getScheme()) || !Set.of("services.gradle.org", "downloads.gradle.org").contains(distribution.getHost()))
            throw new IllegalArgumentException("Distribuição Gradle deve usar um host oficial HTTPS.");
        String fileName = Path.of(distribution.getPath()).getFileName().toString();
        if (!fileName.matches("gradle-[0-9.]+-bin\\.zip")) throw new IllegalArgumentException("Distribuição inválida.");
        String versionDir = fileName.replace("-bin.zip", "");
        String customCache = System.getenv("GRADLE_USER_HOME");
        Path cache = customCache == null || customCache.isBlank() ? Path.of(System.getProperty("user.home"), ".gradle") : Path.of(customCache);
        Path install = cache.resolve("wrapper/dists/meu-mercado-" + versionDir);
        Path executable = install.resolve(versionDir).resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle");
        if (!Files.exists(executable)) {
            if (Arrays.asList(args).contains("--offline")) throw new IOException("Gradle ainda não está no cache; a primeira execução precisa baixar a distribuição.");
            Files.createDirectories(install);
            try (FileChannel channel = FileChannel.open(install.resolve("install.lock"), StandardOpenOption.CREATE, StandardOpenOption.WRITE); FileLock lock = channel.lock()) {
                if (!Files.exists(executable)) installDistribution(distribution, props.getProperty("distributionSha256Sum"), install);
            }
        }
        List<String> command = new ArrayList<>();
        if (isWindows()) { command.add("cmd.exe"); command.add("/c"); }
        command.add(executable.toString()); command.addAll(Arrays.asList(args));
        ProcessBuilder process = new ProcessBuilder(command).directory(project.toFile()).inheritIO();
        return process.start().waitFor();
    }

    private static void installDistribution(URI uri, String configuredHash, Path install) throws Exception {
        HttpClient client = client();
        String expected = configuredHash;
        if (expected == null || expected.isBlank()) {
            HttpResponse<String> hashResponse = client.send(request(URI.create(uri + ".sha256")), HttpResponse.BodyHandlers.ofString());
            if (hashResponse.statusCode() != 200) throw new IOException("Falha ao obter checksum oficial (HTTP " + hashResponse.statusCode() + ").");
            expected = hashResponse.body().trim();
        }
        if (!expected.matches("(?i)[0-9a-f]{64}")) throw new IOException("Checksum oficial inválido.");
        Path archive = Files.createTempFile(install, "distribution-", ".zip");
        Path staging = Files.createTempDirectory(install, "extract-");
        try {
            System.err.println("Baixando a distribuição oficial do Gradle e verificando SHA-256…");
            HttpResponse<InputStream> response = client.send(request(uri), HttpResponse.BodyHandlers.ofInputStream());
            try (InputStream stream = response.body(); OutputStream output = Files.newOutputStream(archive)) {
                if (response.statusCode() != 200) throw new IOException("Download falhou (HTTP " + response.statusCode() + ").");
                byte[] buffer = new byte[65536]; long size = 0; int read;
                while ((read = stream.read(buffer)) != -1) {
                    size += read;
                    if (size > 300L * 1024 * 1024) throw new IOException("Distribuição excede o limite de tamanho.");
                    output.write(buffer, 0, read);
                }
            }
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream in = Files.newInputStream(archive)) { byte[] buffer = new byte[65536]; int read; while ((read = in.read(buffer)) != -1) digest.update(buffer, 0, read); }
            if (!HexFormat.of().formatHex(digest.digest()).equalsIgnoreCase(expected)) throw new IOException("SHA-256 não corresponde à distribuição oficial.");
            try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
                ZipEntry entry;
                long expanded = 0;
                while ((entry = zip.getNextEntry()) != null) {
                    Path target = staging.resolve(entry.getName()).normalize();
                    if (!target.startsWith(staging)) throw new IOException("Entrada inválida no arquivo ZIP.");
                    if (entry.isDirectory()) Files.createDirectories(target);
                    else {
                        Files.createDirectories(target.getParent());
                        try (OutputStream out = Files.newOutputStream(target)) {
                            byte[] buffer = new byte[65536]; int read;
                            while ((read = zip.read(buffer)) != -1) { expanded += read; if (expanded > 700L * 1024 * 1024) throw new IOException("ZIP excede limite expandido."); out.write(buffer, 0, read); }
                        }
                        if (target.getParent().getFileName().toString().equals("bin")) target.toFile().setExecutable(true, true);
                    }
                }
            }
            String versionDir = Path.of(uri.getPath()).getFileName().toString().replace("-bin.zip", "");
            Path stagedDistribution = staging.resolve(versionDir);
            if (!Files.exists(stagedDistribution.resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle")))
                throw new IOException("A distribuição não contém o executável Gradle esperado.");
            try { Files.move(stagedDistribution, install.resolve(versionDir), StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(stagedDistribution, install.resolve(versionDir)); }
        } finally {
            Files.deleteIfExists(archive);
            try (var paths = Files.walk(staging)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }
    private static HttpRequest request(URI uri) { return HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(180)).GET().build(); }
    private static HttpClient client() {
        HttpClient.Builder builder = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).followRedirects(HttpClient.Redirect.NORMAL);
        String proxy = System.getenv("HTTPS_PROXY");
        if (proxy == null || proxy.isBlank()) proxy = System.getenv("https_proxy");
        if (proxy != null && !proxy.isBlank()) {
            URI url = URI.create(proxy);
            builder.proxy(ProxySelector.of(new InetSocketAddress(url.getHost(), url.getPort() > 0 ? url.getPort() : 80)));
        }
        return builder.build();
    }
    private static boolean isWindows() { return System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win"); }
}
