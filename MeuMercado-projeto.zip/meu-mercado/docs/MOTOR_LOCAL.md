# Cálculos e inteligência local

O motor não acessa internet e não gera preços. Cada sugestão usa um produto equivalente
explicitamente cadastrado e uma observação de preço com mercado, data e fonte.

## Dinheiro e orçamento

Preços ficam em centavos `Long`. Quantidades e conversões usam `BigDecimal`.
Valores em reais aceitam vírgula decimal e agrupamento brasileiro (`1.000` significa
mil reais). Quantidades aceitam vírgula ou ponto decimal (`0.125` significa 0,125).
O subtotal de uma linha é arredondado uma vez ao centavo (`HALF_UP`); o desconto
é um valor total da linha e não pode deixar o subtotal negativo. Valores negativos,
quantidades não positivas e operações que ultrapassam `Long` são rejeitados.

As margens em reais e percentual são **somadas** quando ambas estão configuradas.
A reserva percentual é calculada sobre o orçamento total. O limite operacional
é o orçamento menos a reserva, limitado pelo máximo opcional e nunca negativo.
O saldo restante usa somente o carrinho. A projeção soma carrinho e pendentes.
Preços efetivamente encontrados só substituem estimativas nas linhas no carrinho.
Indisponíveis e removidos não entram nos totais. Tributos são registros informativos
separados e não são adicionados ao preço dos produtos.

## Embalagens e equivalência

Produtos vendidos por unidade usam o conteúdo de sua embalagem. Produtos vendidos
por kg, g, L ou ml usam a unidade de venda. O motor converte massa em kg, volume em
L e contagem em unidades, sem converter entre dimensões. Para embalagens fechadas,
a quantidade necessária de pacotes é arredondada para cima. Por exemplo, para
comprar 1 kg usando pacotes de 600 g, são necessários dois pacotes.

A chave de equivalência deve estar preenchida e ser a mesma; categoria e todas
as características essenciais também precisam coincidir. A alternativa precisa
respeitar todas as restrições do produto original. Fórmulas infantis e químicos
sensíveis não recebem substituições. Produtos de limpeza sem especificações
essenciais também não recebem sugestões de outro produto. A opção de não substituir
bloqueia todos os modos.

## Os três modos

- **Máxima Economia:** menor custo para a quantidade necessária, seguido pelo
  preço por unidade padronizada.
- **Melhor Custo-Benefício:** ordena pelo preço por unidade, usando preferência
  registrada: um produto explicitamente aceito recebe peso 0,90 e uma marca favorita
  peso 0,95. Estes pesos são critérios de preferência, não avaliações de qualidade.
- **Minhas Marcas Favoritas:** marcas cadastradas para a categoria vêm primeiro;
  outras aparecem como alternativas opcionais. Se não houver marcas cadastradas,
  mantém a marca do produto original como preferência. Nenhum modo aplica trocas.

A otimização preserva itens no carrinho, identifica possíveis duplicados e calcula
economia somente em itens pendentes. Trocas fora das favoritas não são incorporadas
automaticamente ao total otimizado. A interface exige aprovação das substituições.

## Preços registrados e ausência de dados

Usa-se o último preço registrado por produto/mercado. Promoções vencidas e registros
futuros são excluídos. Valores históricos continuam identificados como históricos;
um registro passado não comprova disponibilidade ou preço atual. Outros mercados
só participam das sugestões quando explicitamente habilitados. A comparação de
mercados informa cobertura e quantidade sem preço, sem declarar um vencedor com
totais incompletos. Não extrapola descontos particulares a outros estabelecimentos.

Sem equivalências ou preços, o resultado é vazio e o assistente explica que faltam
dados. Não existem produtos de demonstração ou respostas externas simuladas.

## OCR e assistente

O OCR gera um rascunho para revisão. Preços condicionais ou ambíguos não são
escolhidos automaticamente. O assistente responde por regras em português usando
dados locais; consultas mensais usam o mês calendário do dispositivo. Ele nunca
muda uma lista e informa a indisponibilidade da IA online quando não configurada.
