# Persistência e integridade

O aplicativo usa Room/SQLite no dispositivo, sem conta e sem servidor obrigatório. O banco `meu_mercado.db` tem versão 2 e exporta o esquema para `app/schemas`. As configurações, incluindo o modo de recomendação, são persistidas no Preferences DataStore `meu_mercado_settings`.

## Estrutura

O catálogo normaliza categorias, marcas e etiquetas em `product_categories`, `brands`, `tags`, `products` e `product_tags`. `favorite_brands` relaciona marcas e categorias. Um índice único impede repetir um código de barras não nulo. O cadastro sem código também procura a combinação de nome, marca, categoria, unidade e tamanho da embalagem para evitar duplicatas idênticas. Cadastrar novamente uma identidade existente reutiliza seu ID sem apagar metadados, restrições ou proteções; para editar seus dados, a ação deve informar explicitamente o ID cadastrado.

`shopping_lists`, `shopping_list_items` e `budget_settings` mantêm o planejamento. Quantidades decimais ficam como texto decimal canônico e valores financeiros ficam em centavos inteiros. `price_observations` associa produto, estabelecimento, data, fonte e condições. Entrar no carrinho exige um preço encontrado confirmado. Uma edição de preço de um item efetivamente colocado no carrinho registra a observação no mercado selecionado; a estimativa de um item pendente não vira observação. Substituições no carrinho recusam preços de outro estabelecimento; substituições pendentes podem usar uma referência externa, identificada nas observações, que deverá ser conferida antes da compra.

`shopping_sessions` e `session_items` registram sessões. Trocar o mercado da mesma lista exige retirar os itens do carrinho ou finalizar a sessão, para evitar atribuir preços de um estabelecimento a outro. É possível manter diferentes listas e alternar entre elas.

`shopping_history` e `history_items` congelam nomes, marcas, categorias, unidades, quantidades, estimativas, descontos e preços pagos na finalização. Os itens históricos não dependem do cadastro mutável do catálogo. Apenas os itens no carrinho entram na compra concluída; pendentes permanecem na lista. Os adquiridos passam para o estado Removido na lista reutilizável. Alterar um produto ou excluir a lista não altera os valores e produtos históricos. Excluir um mercado preserva seu nome no histórico e remove a referência ao cadastro.

Duplicar uma lista copia todos os seus produtos, inclusive os adquiridos ou removidos, para um planejamento pendente novo. Quantidades e estimativas permanecem; descontos e preços encontrados são limpos para que sejam conferidos na nova compra. Isso permite reutilizar listas semanais após a conclusão.

`tax_records` guarda tributos documentados e estimados separadamente. Esses registros informativos não aumentam o total congelado da compra. `receipts` mantém o URI do documento fiscal selecionado ou endereço HTTPS autorizado. Um backup guarda o URI, mas não copia os bytes da foto ou da nota: mover o arquivo ou restaurar em outro dispositivo pode exigir selecioná-lo novamente.

As tabelas `product_alternatives`, `recommendations` e `recommendation_decisions` registram alternativas e decisões de substituição. O repositório revalida a equivalência segura e a quantidade necessária antes de aplicar uma alternativa confirmada. `user_preferences` mantém contagens locais de produtos, marcas por categoria e quantidades habituais. É possível redefinir essas preferências sem excluir compras.

## Transações e desfazer

Mutations de itens, substituições, finalização e importação usam transações Room. `undo_records` guarda a imagem anterior do item e as observações/decisões criadas pela operação. O desfazer permanece disponível depois de reiniciar o aplicativo; ele reverte inserção, edição, remoção ou substituição de itens. Finalizar a compra limpa a pilha, protegendo compras já concluídas. Excluir lista ou mercado também limpa operações que dependeriam dos registros removidos.

A observação Room acompanha todas as tabelas exibidas pelo aplicativo. Alterar preço ou quantidade invalida o fluxo mesmo quando a quantidade de linhas não muda. O ViewModel recalcula carrinho, projeção e recomendações a partir dos dados persistidos.

## Backup JSON

O formato `meu-mercado-backup`, versão 1, declara a versão 2 do banco e inclui configurações e todas as tabelas. A restauração preserva os identificadores e relações, inclusive histórico e observações. Antes da importação são verificados formato, versão, tabelas, colunas e tipos. Dentro de uma única transação são conferidos vínculos, valores financeiros, quantidades, enumerações, valores booleanos e totais históricos. Uma falha reverte o banco e preserva as configurações anteriores. O limite é de 20 MB e 100 mil registros para limitar consumo de recursos em arquivos incorretos.

O backup local contém os dados pessoais registrados pelo usuário e não é criptografado pelo aplicativo. Use o seletor de arquivos do Android e guarde o arquivo em local de sua escolha. Não é necessária permissão ampla de armazenamento.

## Migração

A migração `MIGRATION_1_2` adiciona `products.accepted INTEGER NOT NULL DEFAULT 0` para a preferência de aceitação aprendida localmente. A versão 1 corresponde ao mesmo esquema sem esse campo. O banco usa `addMigrations`; não usa migração destrutiva como fallback. Novas alterações devem manter migrações explícitas e testes com os esquemas exportados.

## Verificação

`RoomMarketRepositoryTest` é um conjunto de testes instrumentados Android, executado com `./gradlew connectedDebugAndroidTest`. Verifica cálculo com carrinho e pendentes, deduplicação de catálogo, preço por mercado, desfazer, equivalência e substituição, histórico congelado, tributos informativos, backup/restauração, rollback de backup inválido, reinicialização do banco, exclusão de mercado e redefinição das preferências.

Sem SDK Android, `python3 tools/check_database_schema.py` executa verificações SQLite da estrutura extraída das entidades: vínculos, índices, comportamento de exclusão, proteção do histórico, código de barras único, ordenação de restauração, preservação de IDs, rollback e SQL da migração. Essa verificação não executa Room nem Kotlin e complementa os testes Android.
