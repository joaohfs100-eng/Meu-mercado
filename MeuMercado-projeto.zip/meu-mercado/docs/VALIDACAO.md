# Plano de validação

## Estado desta entrega

Os testes Kotlin abaixo estão implementados em código-fonte, mas **não executados neste ambiente**. As verificações SQLite executadas estão descritas em uma seção própria ao final deste documento. Não houve compilação Android, execução em emulador/aparelho, medição de desempenho, verificação visual com TalkBack nem geração de APK. A preparação do Gradle/SDK não pôde terminar sem acesso à rede. A revisão estática corrige problemas identificados no código; ela não substitui uma compilação ou um resultado de teste.

Não interpretar a presença de uma tela, de um teste ou de um item marcado como implementado como aprovação do fluxo completo. Em particular, testes de interpretação de texto e validação de GTIN não comprovam a qualidade da câmera, do ML Kit ou do reconhecimento em etiquetas reais.

### Resultado posterior do GitHub

O usuário forneceu o log de `:domain:test`: **57 testes executados, 56 aprovados e uma falha** em `LocalAssistantTest.changingModeChangesRankingAndExplainsPreferences`, linha 46. A explicação de `FAVORITE_BRANDS` foi corrigida para incluir a expressão `marcas favoritas` procurada pela asserção. Nenhum teste foi removido ou ignorado. A nova execução está pendente; ainda não há resultado dos testes do app ou APK. Veja [RESULTADOS.md](RESULTADOS.md).

## Como executar

Em uma máquina com JDK 21, SDK Android 35, Gradle Wrapper funcional e dependências disponíveis:

```bash
./gradlew :domain:test :app:testDebugUnitTest
./gradlew :app:lintDebug :app:assembleDebug
./gradlew :app:connectedDebugAndroidTest
```

O último comando exige aparelho/emulador conectado. Os resultados ficam em `domain/build/reports/tests/test`, `app/build/reports/tests/testDebugUnitTest`, `app/build/reports/androidTests/connected` e no relatório de lint. Só depois de executar os comandos e revisar os resultados deve-se alterar os estados deste documento. Veja o README para preparar o Wrapper e instalar o APK quando a compilação for possível.

## Checklist dos 20 casos obrigatórios

Os estados da tabela abaixo registram a **validação local inicial**. A execução posterior do domínio no GitHub está documentada acima; os critérios que dependem do app ou de aparelho continuam pendentes. As classes de domínio estão em `domain/src/test/kotlin/br/com/meumercado/domain`; os testes locais do aplicativo estão em `app/src/test/java/br/com/meumercado`; os testes instrumentados estão em `app/src/androidTest/java/br/com/meumercado`.

| Nº | Caso e resultado esperado | Teste automatizado implementado | Estado |
|---|---|---|---|
| 1 | Orçamento de R$ 500,00, reserva de R$ 50,00 e carrinho de R$ 300,00 devem produzir limite de R$ 450,00 e saldo de R$ 150,00, separando pendentes. | `MoneyBudgetTest`: `orcamento reserva margem fixa`, `carrinho prefere preco real e mantem previsao pendente separada`; `LocalAssistantTest.budgetReplySeparatesCartAndPendingProjection`. | Não executado |
| 2 | Reservas fixa e percentual devem reduzir corretamente o limite, respeitando o máximo configurado e sem saldo de reserva negativo. | `MoneyBudgetTest`: `margens percentual e fixa sao somadas e limite maximo respeitado`, `limite zero nao divide por zero e reserva nunca fica negativa`. | Não executado |
| 3 | Quantidades como 0,750 kg devem preservar a precisão e arredondar somente o subtotal em centavos. | `MoneyBudgetTest`: `quantidade fracionaria preserva todas as casas`, `arredondamento ocorre somente no subtotal por linha`. | Não executado |
| 4 | Desconto por linha deve ser aplicado uma vez e não gerar subtotal negativo. | `MoneyBudgetTest`: `desconto e por linha e nao multiplicado pela quantidade`; `RoomMarketRepositoryTest.itemUpdatesRecordStorePriceAndUndoRestoresPreviousState`. | Não executado |
| 5 | Comparar kg/g e L/ml corretamente; recusar equivalência entre massa e volume. | `RecommendationEngineTest`: `quilogramas e gramas tem comparacao normalizada correta`, `litros e mililitros tem comparacao normalizada correta`, `massa nao e convertida em volume`, `produtos por peso aceitam quantidades fracionarias na alternativa`. | Não executado |
| 6 | Substituição compatível só deve persistir após confirmação; desfazer deve restaurar produto, quantidade e preços. | `RoomMarketRepositoryTest.substitutionRequiresCompatibilityAndCanBeUndone`; `RecommendationEngineTest`: `recomendacao e visualizacao imutavel sem substituir lista`. | Não executado |
| 7 | Preço unitário padronizado e custo da quantidade necessária devem considerar tamanho de embalagem e arredondamento de pacotes. | `RecommendationEngineTest`: `embalagens sao arredondadas para cima conforme quantidade necessaria`, testes de normalização kg/g e L/ml; `LocalAssistantTest.catalogComparisonReportsNormalizedPackagePriceAndSource`. | Não executado |
| 8 | Os três modos devem ordenar dados adequados de maneiras diferentes; trocar o modo deve recalcular as respostas. | `RecommendationEngineTest`: `tres modos produzem ordens diferentes usando preferencias reais`; `LocalAssistantTest.changingModeChangesRankingAndExplainsPreferences`. | Não executado |
| 9 | Marcas externas às favoritas devem ser opcionais; produtos protegidos, restrições e equivalências inseguras devem bloquear trocas. | `RecommendationEngineTest`: `marcas diferentes sao opcionais no modo favoritas`, `produto que nao pode ser substituido e protegido em todos os modos`, `caracteristicas essenciais e restricoes impedem equivalencia insegura`, `formula infantil e quimico sem composicao explicita nao sao substituidos`. | Não executado |
| 10 | Colocar, retirar ou editar item deve atualizar imediatamente carrinho, saldo e projeção sem misturá-los. | `MoneyBudgetTest`: `recalculo reage a atualizacao do carrinho sem cache`; `RoomMarketRepositoryTest.savedItemsEmitActualCartAndEstimatedPending`; `NavigationAndCartTest.cartUpdatesImmediatelyAndNavigationKeepsPurchaseData`. | Não executado |
| 11 | Backup deve restaurar IDs, relações, histórico e DataStore; arquivo inválido deve preservar o banco anterior. | `RoomMarketRepositoryTest.backupRestoresIdsRelationshipsHistoryAndDataStoreSettings`, `invalidBackupRollsBackAllTablesAndSettings`; `HistoryCsvExporterTest` cobre exportação CSV e neutralização de fórmulas. | Não executado |
| 12 | Editar catálogo ou excluir lista/mercado não deve modificar os produtos e preços de compras concluídas. | `RoomMarketRepositoryTest.historyFreezesOnlyBoughtProductsAndSurvivesCatalogueChangesAndListDeletion`, `deletingStorePreservesHistoricalNameAndDetachesLiveReferences`. | Não executado |
| 13 | GTIN válido deve ser reconhecido; checksum inválido deve ser recusado; busca local deve funcionar offline. | `BarcodeValidatorTest.validatesCommonGtinLengths`, `rejectsIncorrectChecksumsAndUnsupportedInput`, `readsValidatedBarcodeFromLocalOcrWithoutInternet`; `RoomMarketRepositoryTest.barcodeDeduplicatesAndPreservesRelationships`. São testes de validação/extração, não da câmera física. | Não executado; leitura real com CameraX/ML Kit pendente |
| 14 | Texto OCR vazio, danificado ou com preços ambíguos deve exigir correção sem inventar preço. | `LabelParserTest.damagedOrEmptyOcrNeverInventsPrice`, `refusesAmbiguousPricesAndConditionalDiscounts`, `keepsPackagePriceSeparateFromPricePerLiter`, `detectsUnconditionalDePorPromotionButStillRequiresReview`. | Não executado; etiquetas reais pendentes |
| 15 | Com modo avião, persistência, orçamento, histórico, scanner local e recomendações locais devem continuar utilizáveis. | `LocalAssistantTest.recommendationIsLocalAndRequiresConfirmation`; testes de domínio não dependem de rede; `BarcodeValidatorTest.readsValidatedBarcodeFromLocalOcrWithoutInternet`. Ensaio completo em modo avião ainda necessário. | Não executado |
| 16 | Falta de consentimento/configuração/conexão deve informar indisponibilidade online mantendo o fallback local. | `OnlineConfigurationTest.absentConsentNeverConnectsAndMissingConfigurationIsExplicit`, `invalidQueryIsRejectedBeforeNetworkOrAndroidJson`; `LocalAssistantTest.unavailablePricesAndOnlineAreExplicit`. Falha real de rede ainda deve ser ensaiada. | Não executado |
| 17 | Catálogo sem preços não deve fabricar alternativas; comparação parcial deve revelar cobertura e datas. | `RecommendationEngineTest`: `nenhum preco ou equivalencia desconhecida nao gera resultado ficticio`, `comparacao informa cobertura e nao aplica descontos de outro mercado`, `historico e identificado e nao apresentado como preco atual`; `LocalAssistantTest.storeComparisonWarnsAboutCoverageAndHistoricalPrices`. | Não executado |
| 18 | Compra sem tributos deve permanecer sem registros e exibir “Tributos não informados.”. | `RoomMarketRepositoryTest.includedTaxesNeverIncreasePurchaseTotalAndMissingTaxStaysMissing`; UI de histórico/relatórios possui estado vazio explícito. Texto visual exige verificação no aparelho. | Não executado |
| 19 | Tributos incluídos no preço devem ser documentados separadamente, mantendo total pago, orçamento e relatórios. | `MoneyBudgetTest`: `tributos incluidos nao sao somados novamente ao carrinho`; `LocalAssistantTest.taxesRemainSeparateAndIncludedTaxesNeverIncreaseSpending`; `RoomMarketRepositoryTest.includedTaxesNeverIncreasePurchaseTotalAndMissingTaxStaysMissing`; `HistoryCsvExporterTest.preservesExactPaidTotalAndSeparatesDocumentedAndEstimatedTaxes`. | Não executado |
| 20 | Navegar pelas cinco abas e reabrir banco/aplicativo deve preservar a compra; mudanças de orientação devem manter formulários e operações. | `NavigationAndCartTest.cartUpdatesImmediatelyAndNavigationKeepsPurchaseData`; `RoomMarketRepositoryTest.dataAndModePersistAfterDatabaseReopens`; `DatabaseMigrationTest.migrationOneToTwoPreservesCatalogueAndInitializesAcceptance`. Recriação física de Activity, processo e fluxo SAF ainda precisam de ensaio. | Não executado |

## Validações adicionais implementadas

- `PeriodSelectionTest.brazilianDatesIncludeBothBoundaryDays`, `rejectsImpossibleAndReversedDates`, `acceptsIsoDatesFromPreviouslySavedFilters`: período personalizado inclusivo, calendário estrito e compatibilidade com formato ISO previamente salvo.
- `HistoryCsvExporterTest.neutralizesSpreadsheetFormulaAndEscapesQuotedNames`, `exportsHeaderWhenHistoryIsEmpty`: exportações seguras e estado vazio.
- `OnlineConfigurationTest.requiresHttpsAndDoesNotAcceptInlineCredentials`, `neverFollowsRedirectsToDifferentHostsOrHttp`, `rejectsInvalidAndFutureExternalPrices`: parâmetros externos e comportamento HTTPS.
- `OnlineResponseInstrumentedTest.validatesActualJsonAnswers`, `refusesFractionalCentsAndInvalidPriceMetadata`: respostas reais em JSON e metadados de preços.
- `FiscalQrValidatorTest.acceptsOnlyOfficialHttpsUrlsForConfirmation`: validação do endereço fiscal antes de abrir navegador.
- `RoomMarketRepositoryTest.learnedPreferencesCanBeResetWithoutDeletingPurchases`: redefinição do aprendizado local preservando compras.
- `RoomMarketRepositoryTest.cartRequiresConfirmedActualPriceAndRejectsOnlyAnEstimate`, `cartSubstitutionCannotTurnAnotherStoresPriceIntoPaidPrice`: exigência de preço confirmado no carrinho e proteção da procedência do preço.
- `RoomMarketRepositoryTest.duplicatingCompletedListCreatesReusablePendingPlan`: reutilização da lista concluída com orçamento/estimativas preservados e preços encontrados/descontos reiniciados.

**Estado desses testes adicionais: não executado.**

## Ensaio manual antes de considerar o aplicativo utilizável

1. Instalar o APK compilado em aparelho Android 8+ e em um aparelho com Android 13+; repetir o fluxo de aceitação sem login e com modo avião.
2. Criar mercado, lista, orçamento de R$ 500,00 e reserva de R$ 50,00; cadastrar pelo menos um item por unidade e outro por peso; verificar projeção separada do carrinho.
3. Registrar duas marcas equivalentes com características explícitas e preços observados; alternar os três modos; revisar cada alternativa, fonte, data e proteção de favoritos antes de confirmar e desfazer uma troca.
4. Conceder câmera quando solicitada; testar GTIN conhecido e desconhecido, iluminação ruim, etiqueta promocional, preço por kg e OCR inválido. Corrigir os campos antes de salvar e verificar o produto ao qual o preço foi atribuído.
5. Finalizar compra com pendentes; conferir snapshots, descontos e totais; alterar o catálogo e confirmar que a compra concluída permanece intacta.
6. Registrar tributos documentados e uma simulação percentual mediante revisão; conferir que o total pago e os gráficos não aumentam. Ler QR de NFC-e, cancelar e confirmar abertura HTTPS, sem tentar contornar bloqueios do portal.
7. Exportar JSON/CSV pelo seletor; restaurar um backup válido; rejeitar JSON inválido e arquivo acima de 16 MB. Cancelar o seletor, revogar autorização, excluir o arquivo e verificar mensagens de erro. Girar o aparelho durante exportação/restauração e na confirmação: a URI deve permanecer selecionada e a operação deve continuar sem armazenar o JSON em um Bundle.
8. Testar Back, navegação por gestos, teclado visível, fontes ampliadas, tema claro/escuro, orientação retrato/paisagem e TalkBack. Os modos de IA devem ser anunciados como um grupo de escolha única; gráficos têm descrições e valores textuais.
9. Agendar/cancelar lembrete; negar e conceder notificações sob demanda; confirmar comportamento após reiniciar o aparelho. O horário pode ser ajustado pelo Android.
10. Fechar/reabrir aplicativo, reiniciar aparelho e atualizar o APK preservando a base; executar migração e revisar os relatórios. Somente depois registrar versão do aparelho, API Android, versão do APK, resultados e falhas.

Todas as etapas manuais estão **não executadas** nesta entrega. Serviços online dependem de gateway autorizado e configurado; nenhum preço externo ou portal fiscal foi consultado como parte desta validação.

## SQLite: verificações executadas neste ambiente

Comando executado em 10/10/2026:

```bash
python3 tools/check_database_schema.py
```

**Resultado: 8 testes passaram, 0 falhas.** O script extrai tabelas, colunas, índices e relações das annotations das entidades Kotlin e exercita esse esquema com o SQLite do Python. Os testes verificam:

1. Correspondência das 24 entidades com as tabelas usadas pelo backup e ausência de violações de chaves estrangeiras.
2. Índices para todas as chaves estrangeiras e nulabilidade das relações com `SET NULL`.
3. Preservação de nome, marca e total dos snapshots históricos após editar o catálogo e excluir a lista.
4. Exclusão de estabelecimento removendo seus preços e destacando listas, sem alterar o nome histórico ou total da compra.
5. Unicidade do código de barras com suporte a vários produtos sem código.
6. Restauração na ordem usada pelo repositório, preservando IDs e relacionamentos.
7. Rollback completo dos dados anteriores diante de uma restauração com referências inválidas.
8. Execução do SQL real da migração v1→v2, preservando registros e inicializando `accepted` com zero.

Esses resultados comprovam apenas os comportamentos SQLite exercitados. **Não houve execução de Room, DataStore, Hilt, Kotlin, Compose ou dos testes instrumentados Android.** A compilação e os 20 critérios completos continuam pendentes de verificação em ambiente Android.
