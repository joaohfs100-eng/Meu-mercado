# Contratos de integração

Projeto: app Android em `app`, domínio JVM em `domain`, pacote `br.com.meumercado`.
Os modelos e MarketRepository em domain são o contrato compartilhado. Não modificar esses arquivos sem coordenar com root.

Money: objeto com `parseCents(String): Long`, `format(Long): String`, `parseQuantity(String): BigDecimal`, `subtotal(Long, String, Long = 0): Long` (preço, quantidade, desconto total por linha). Entradas inválidas lançam IllegalArgumentException. Quantidades positivas, monetário não negativo.
BudgetCalculator: objeto `calculate(items: List<ShoppingListItem>, settings: BudgetSettings): BudgetSummary`.
RecommendationEngine: classe com `alternatives(item, products, prices, settings, storeId: Long?, allowOtherStores: Boolean = false): List<Alternative>`, `optimize(items, products, prices, settings, storeId, allowOtherStores = false): Optimization`, `compareStores(items, products, prices, stores): List<StoreComparison>`.
LocalAssistant: classe `reply(query: String, snapshot: AppSnapshot, settings: AISettings): AssistantReply`.
LabelParser: objeto `parse(text: String): OcrDraft`; BarcodeValidator: objeto `isValid(value: String): Boolean`.

Persistência: `br.com.meumercado.data.RoomMarketRepository` implementa MarketRepository. Hilt DatabaseModule fornece MarketRepository. `br.com.meumercado.data.SettingsStore` DataStore. Room banco normalizado com snapshots históricos imutáveis e backup transacional validado.

UI principal: `br.com.meumercado.ui.MarketApp()` sem parâmetros; Hilt `MarketViewModel`. Expõe `state: StateFlow<MarketUiState>` com `snapshot`, `settings`, `loading`, `error`; ações `saveProduct`, `saveStore`, `saveList`, `saveItem`, `saveBudget`, `saveSettings`, `deleteList`, `duplicateList`, `activateList`, `substitute`, `undo`, `finishPurchase`, `saveTax`, `saveReceipt`, `rememberSearch`, `eraseAll`, `clearLearnedPreferences`, e funs suspend exportBackup/restoreBackup. Todos chamam repositório e tratam erros. Cada save retorna via callback opcional? Para integração usar ações `(model)` sem retorno; adicionar produto+item com `addProductToActiveList(product,quantity,priceCents)`.

Telas extras `br.com.meumercado.features`: `HistoryScreen(state: MarketUiState, vm: MarketViewModel)`, `SettingsScreen(state,vm)`, `StoresScreen(state,vm)`, `ReportsScreen(state)`.
Scanner `br.com.meumercado.features.scanner.ScannerScreen(onConfirm: (OcrDraft) -> Unit, onBack: () -> Unit)`. Câmera fornece revisão dos campos antes de onConfirm. Inclui modo código/OCR/QR fiscal; QR fiscal abre Intent HTTPS confirmado, sem presumir parser fiscal. UI principal usa draft para edição de produto antes de persistir.
Online: `br.com.meumercado.data.online.OnlineAiGateway` com suspend ask(url,query,consent): resultado explícito; provedores extensíveis.
