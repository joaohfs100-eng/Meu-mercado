# Baixar e gerar o APK usando somente um celular Android

O arquivo `MeuMercado-projeto.zip` contém o código-fonte. **Ele não é um APK e não pode ser instalado como aplicativo.** Ainda não existe um APK desta entrega: a compilação ficou pendente no ambiente de desenvolvimento.

O caminho abaixo usa o navegador do celular e GitHub Actions para compilar em um computador na nuvem. Você não precisa de um PC, Android Studio no celular ou Termux. Precisa de internet e uma conta GitHub. O aplicativo, depois de compilado e instalado, continua usando seus dados locais sem login.

## Arquivos necessários

1. `MeuMercado-projeto.zip`: projeto inteiro, mantendo esse nome.
2. `gerar-apk-pelo-celular.yml`: configuração pronta para compilar o ZIP.

Salve ambos na pasta Downloads do celular. Caso o Android acrescente `(1)` ao nome do ZIP, renomeie para `MeuMercado-projeto.zip` antes de enviar ao GitHub. Não é necessário descompactar os arquivos do projeto no celular.

## Preparar o repositório pelo navegador

1. Abra `https://github.com`, entre na sua conta ou crie uma.
2. Crie um repositório chamado `meu-mercado`. Ele pode ser privado. Marque a opção de criar um README para já ter uma primeira versão.
3. Na página do repositório, toque em **Add file → Upload files**. Se o menu não aparecer, ative **Versão para computador / Site para computador** no navegador.
4. Selecione o ZIP `MeuMercado-projeto.zip` pelo seletor de arquivos Android. Toque em **Commit changes** para salvar. O ZIP deve ficar na página principal dos arquivos, ao lado do README.

Não envie apenas o ZIP dentro de outra pasta. O fluxo procura esse nome na raiz do repositório.

## Adicionar a configuração de compilação

1. No repositório, toque em **Add file → Create new file**.
2. No campo do nome, escreva exatamente `.github/workflows/gerar-apk.yml`.
3. Abra o arquivo baixado `gerar-apk-pelo-celular.yml` em um leitor/editor de texto, selecione todo o conteúdo e copie.
4. Cole o conteúdo no editor do GitHub, preservando espaços e quebras de linha. Não cole marcadores Markdown como três crases.
5. Toque em **Commit changes** e salve na branch principal.

Se o seu celular não abrir arquivos `.yml`, use um editor de texto que abra arquivos locais. Você também pode consultar o conteúdo fornecido nesta conversa e copiá-lo. A configuração não contém senha, token ou chave de API.

## Gerar e baixar o APK

1. Abra a aba **Actions** do repositório.
2. Se houver uma tela pedindo para habilitar Actions, habilite para esse repositório.
3. Selecione **Gerar APK do Meu Mercado** e toque em **Run workflow → Run workflow**.
4. Aguarde a execução. A primeira compilação pode demorar vários minutos porque baixa SDK e dependências. Limites e disponibilidade do GitHub dependem da sua conta.
5. Quando a execução tiver o indicador verde, abra seus detalhes e encontre **Artifacts**.
6. Baixe **MeuMercado-APK-debug**. O GitHub entrega esse resultado como outro ZIP; descompacte esse ZIP pelo aplicativo Arquivos do Android.
7. Dentro dele haverá `app-debug.apk`. Toque no APK, autorize a instalação pela aplicação que abriu o arquivo quando o Android solicitar e confirme a instalação.

Android mínimo: 8.0. O APK usa assinatura de desenvolvimento e serve para instalação direta. Não é um pacote assinado para publicação na Play Store.

## Se a execução falhar

Não foi possível executar este fluxo cloud nesta sessão. **O código Android ainda não foi compilado ou validado em dispositivo, portanto pode exigir correções.** O fluxo faz os testes antes de liberar o APK; indicador vermelho significa que houve falha de preparação, teste ou compilação.

Abra a etapa vermelha, copie o erro e compartilhe-o nesta conversa. O arquivo `resultados-dos-testes` também pode estar disponível nos Artifacts. Não envie senhas nem tokens. Sem execução bem-sucedida, não haverá APK para baixar.

## Atualizações futuras

Substitua `MeuMercado-projeto.zip` no mesmo repositório e execute o fluxo novamente. Conserve a assinatura debug utilizada para atualizar preservando dados; mudanças na assinatura podem exigir desinstalação. Faça backup dos dados pelo aplicativo antes de desinstalar.

Nenhum repositório foi criado e nenhum arquivo foi publicado automaticamente. Você controla a conta e os envios ao GitHub.
