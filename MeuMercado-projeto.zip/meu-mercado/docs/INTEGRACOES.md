# Integrações opcionais

O scanner usa os modelos embarcados do ML Kit (código de barras e texto latino). A câmera é solicitada somente ao abrir o scanner, e o cadastro manual continua disponível quando a permissão é negada ou o aparelho não possui câmera. O preço de uma etiqueta nunca é salvo sem revisão. Códigos EAN/GTIN passam por validação de dígito verificador; CODE_128, CODE_39, ITF e Data Matrix são apresentados para revisão do cadastro.

O QR fiscal abre apenas uma URL HTTPS de domínio oficial `.gov.br`, após confirmação, no navegador escolhido pelo usuário. O aplicativo não coleta páginas fiscais, não contorna CAPTCHA e não presume que o portal disponibiliza tributos estruturados. O usuário deve registrar os valores documentados na nota no histórico da compra.

## Gateway de IA

`OnlineAiGateway.ask(url, query, consent)` conecta somente com consentimento e uma URL HTTPS. O endereço configurado deve apontar para um backend sob responsabilidade do usuário; não há API key no APK. Quando a URL aponta para uma base, acrescenta-se `/chat`. Se ela já terminar em `/chat`, é usada diretamente. Para consulta de preços, um sufixo `/chat` é substituído por `/prices`, preservando o caminho-base. Barras finais são normalizadas. Redirecionamentos e URLs com credenciais ou parâmetros são rejeitados. O aplicativo não envia o banco, histórico, localização ou notas: somente a pergunta escrita e o idioma.

Requisição POST JSON:

```json
{"query":"Quanto custa o produto consultado?","locale":"pt-BR"}
```

Resposta JSON:

```json
{"answer":"Texto retornado pelo backend e identificado como resposta online."}
```

O backend deve manter chaves privadas no servidor, aplicar seus mecanismos de autenticação, autorização, limites de uso e exclusão de dados, e responder sem inventar preços. Não há backend pré-conectado. Desativação, ausência de configuração, falhas de conexão e respostas inválidas retornam estados explícitos; o assistente local permanece disponível. Perguntas com dados pessoais são enviadas somente quando o usuário habilita o consentimento e escolhe a consulta online.

## Fontes de preços

`PriceProvider` permite adicionar integrações autorizadas. `LocalOnlyPriceProvider` informa que nenhuma fonte externa foi configurada. `GatewayPriceProvider` é um cliente opcional real para um backend configurado; não representa integração com redes de supermercados. POST `/prices` recebe `query`, `barcode` opcional e `locale`. A resposta deve conter um array `prices` com os campos `productName`, `barcode`, `storeName`, `priceCents` (centavos inteiros), `quantity` (string decimal positiva), `unit` (`UNIT`, `KG`, `G`, `L` ou `ML`), `observedAt` (Unix em milissegundos), `sourceUrl` (HTTPS), `sourceName`, `kind` (`ADVERTISED`, `HISTORICAL`, `USER_CONFIRMED` ou `ESTIMATED`) e `promotionConditions`.

Até 100 registros são aceitos por resposta. Valores negativos, datas futuras, fontes inválidas, unidades desconhecidas e quantidades inválidas são descartados e contados como rejeitados. Nenhum preço externo entra automaticamente no catálogo nem é apresentado como disponibilidade confirmada na loja atual. A interface deve apresentar fonte, data, condições e tipo antes de qualquer importação confirmada.

Os testes JVM de configuração/consentimento validam caminhos anteriores à conexão e não usam os stubs Android de `org.json`. Os testes `OnlineResponseInstrumentedTest` usam `org.json` real em aparelho ou emulador e verificam respostas JSON, metadados e rejeição de centavos fracionários. Leitura óptica e integração com o backend configurado precisam ser verificadas em dispositivo; nenhum resultado desses testes é presumido quando não há SDK/emulador disponível.
