@echo off
setlocal
set APP_DIR=%~dp0
if defined JAVA_HOME (set "JAVA_COMMAND=%JAVA_HOME%\bin\java.exe") else (set "JAVA_COMMAND=java.exe")
if exist "%APP_DIR%gradle\wrapper\gradle-wrapper.jar" (
  "%JAVA_COMMAND%" "-Dorg.gradle.appname=gradlew" -classpath "%APP_DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
) else (
  "%JAVA_COMMAND%" "-Dmeumercado.projectDir=%APP_DIR%." -jar "%APP_DIR%gradle\bootstrap\gradle-bootstrap.jar" %*
)
endlocal & exit /b %ERRORLEVEL%
